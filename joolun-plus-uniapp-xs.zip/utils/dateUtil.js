//时间工具
var dateUtil = {
  getOutTime: function (date) {
	  if(date){
		  //获取某个时间点到当前时间的差（秒）
		  var nowDate = new Date();
		  var endDate = new Date(date.replace(new RegExp('-', 'g'), '/'));
		  return endDate.getTime() - nowDate.getTime();
	  }
    return '';
  }
};
module.exports = {
  //暴露接口调用
  getOutTime: dateUtil.getOutTime
};