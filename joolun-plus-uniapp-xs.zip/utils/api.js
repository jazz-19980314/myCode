/**
 * Copyright (C) 2018-2019
 * All rights reserved, Designed By www.joolun.com
 * 注意：
 * 本软件为www.joolun.com开发研制，未经购买不得使用
 * 购买后可获得全部源代码（禁止转卖、分享、上传到码云、github等开源平台）
 * 一经发现盗用、分享等行为，将追究法律责任，后果自负
 */
import __config from 'config/env';
import util from 'utils/util';

const request = (url, method, data, showLoading) => {
	let _url = url;
	//#ifndef H5
	_url =  __config.basePath + url
	//#endif
	return new Promise((resolve, reject) => {
		if (showLoading) {
			uni.showLoading({
				title: '加载中'
			});
		}
		uni.request({
			url: _url,
			method: method,
			data: data,
			withCredentials: true,
			header: {
				//#ifdef H5
				'client-type': util.isWeiXinBrowser() ? 'H5-WX' : 'H5',//客户端类型普通H5或微信H5
				'tenant-id': getApp().globalData.tenantId,
				'app-id': getApp().globalData.appId ? getApp().globalData.appId : '', //微信h5有appId
				//#endif
				//#ifdef MP-WEIXIN
				'client-type': 'MA',//客户端类型小程序
				'app-id': uni.getAccountInfoSync().miniProgram.appId, //小程序appId
				//#endif
				//#ifdef APP-PLUS
				'client-type': 'APP',//客户端类型APP
				'tenant-id': getApp().globalData.tenantId,
				//#endif
				'third-session': uni.getStorageSync('third_session') ? uni.getStorageSync('third_session') : '',
			},
			success(res) {
				if (res.statusCode == 200) {
					if (res.data.code != 0) {
						if (res.data.code == 60001) {
							//session过期，则清除过期session，并重新加载当前页
							if(!getApp().globalData.logining){
								getApp().globalData.logining = true//防止同时多个接口触发登录
								uni.removeStorageSync('third_session');
								setTimeout(function() {
									getApp().globalData.logining = false;
								}, 5000);
								getApp().initPage().then(res => {
									var pages = getCurrentPages(); // 获取页面栈
									var currPage = pages[pages.length - 1]; // 当前页面
									currPage.onLoad(currPage.options)
									currPage.onShow()
								});
							}
							reject("session过期重新登录");
						}else if (res.data.code == 60002 || res.data.code == 60003) {
							uni.reLaunch({
							    url: '/pages/login/index'
							});
							reject("请先登录商城");
						}else{
							uni.showModal({
								title: '提示',
								content: res.data.msg + '',
								success() {},
								complete() {

								}
							});
							reject(res.data.msg);
						}
					}
					resolve(res.data);
				} else if (res.statusCode == 404) {
					uni.showModal({
						title: '提示',
						content: '接口请求出错，请检查手机网络',
						success(res) {}
					});
					reject();
				} else {
					console.log(res);
					uni.showModal({
						title: '提示',
						content: '错误：'+res.data.msg,
						success(res) {}
					});
					reject();
				}
			},
			fail(error) {
				console.log(error);
				uni.showModal({
					title: '提示',
					content: '接口请求出错：' + error.errMsg,
					success(res) {}
				});
				reject(error);
			},
			complete(res) {
				uni.hideLoading();
			}
		});
	});
};

module.exports = {
	request,
	loginWxMa: data => {
		//微信小程序登录接口
		return request('/mallapi/wxuser/loginma', 'post', data, false);
	},
	loginWxMp: data => {
		//微信公众号登录接口
		return request('/mallapi/wxuser/loginmp', 'post', data, false);
	},
	loginByPhoneMa: data => {
		//商城通过小程序授权手机号一键登录商城
		return request('/mallapi/userinfo/ma/phone/login', 'post', data, true);
	},
	loginByPhone: data => {
		//商城手机验证码登录商城
		return request('/mallapi/userinfo/phone/login', 'post', data, true);
	},
	login: data => {
		//商城账号登录
		return request('/mallapi/userinfo/login', 'post', data, true);
	},
	logout: data => {
		//商城退出登录
		return request('/mallapi/userinfo/logout', 'post', data, true);
	},
	getPhoneCode: data => {
		//获取手机验证码
		return request('/mallapi/phone/code', 'get', data, true);
	},
	register: data => {
		//账号注册
		return request('/mallapi/userinfo/register', 'post', data, true);
	},
	getJsSdkConfig: data => {
		//获取jssdk config参数
		return request('/mallapi/wxjssdk/config', 'post', data, false);
	},
	themeMobileGet: () => {
		//获取商城主题装修配置
		return request('/mallapi/thememobile', 'get', null, false);
	},
	shopInfoPage: data => {
		//店铺列表
		return request('/mallapi/shopinfo/page', 'get', data, false);
	},
	shopInfoList: data => {
		//定位获取店铺列表
		return request('/mallapi/shopinfo/list', 'get', data, false);
	},
	shopInfoPageWithSpu: data => {
		//店铺列表带商品
		return request('/mallapi/shopinfo/pagewithspu', 'get', data, false);
	},
	shopInfoGet: id => {
		//店铺查询
		return request('/mallapi/shopinfo/' + id, 'get', null, false);
	},
	userInfoUpdateByMa: data => {
		//通过微信小程序更新用户信息
		return request('/mallapi/userinfo/ma', 'put', data, true);
	},
	userInfoUpdateByMp: data => {
		//通过微信公众号网页授权更新用户信息
		return request('/mallapi/userinfo/mp', 'put', data, true);
	},
	goodsCategoryTree: data => {
		//商城商品分类tree查询
		return request('/mallapi/goodscategory/tree', 'get', data, true);
	},
	goodsCategoryPage: data => {
		//商城商品分类list查询
		return request('/mallapi/goodscategory/page', 'get', data, true);
	},
	goodsCategoryShopTree: data => {
		//店铺商品分类tree查询
		return request('/mallapi/goodscategoryshop/tree', 'get', data, true);
	},
	goodsPage: data => {
		//商品列表
		return request('/mallapi/goodsspu/page', 'get', data, false);
	},
	goodsGet: id => {
		//商品查询
		return request('/mallapi/goodsspu/' + id, 'get', null, false);
	},
	goodsSpecGet: data => {
		//商品规格查询
		return request('/mallapi/goodsspuspec/tree', 'get', data, true);
	},
	shoppingCartPage: data => {
		//购物车列表
		return request('/mallapi/shoppingcart/page', 'get', data, false);
	},
	shoppingCartAdd: data => {
		//购物车新增
		return request('/mallapi/shoppingcart', 'post', data, true);
	},
	shoppingCartEdit: data => {
		//购物车修改
		return request('/mallapi/shoppingcart', 'put', data, true);
	},
	shoppingCartDel: data => {
		//购物车删除
		return request('/mallapi/shoppingcart/del', 'post', data, false);
	},
	shoppingCartCount: data => {
		//购物车数量
		return request('/mallapi/shoppingcart/count', 'get', data, false);
	},
	orderSub: data => {
		//订单提交
		return request('/mallapi/orderinfo', 'post', data, true);
	},
	orderPage: data => {
		//订单列表
		return request('/mallapi/orderinfo/page', 'get', data, false);
	},
	orderGet: id => {
		//订单详情查询
		return request('/mallapi/orderinfo/' + id, 'get', null, false);
	},
	orderCancel: id => {
		//订单确认取消
		return request('/mallapi/orderinfo/cancel/' + id, 'put', null, true);
	},
	orderReceive: id => {
		//订单确认收货
		return request('/mallapi/orderinfo/receive/' + id, 'put', null, true);
	},
	orderDel: id => {
		//订单删除
		return request('/mallapi/orderinfo/' + id, 'delete', null, false);
	},
	orderCountAll: data => {
		//订单计数
		return request('/mallapi/orderinfo/countAll', 'get', data, false);
	},
	orderLogisticsGet: logisticsId => {
		//订单物流查询
		return request('/mallapi/orderinfo/orderlogistics/' + logisticsId, 'get', null, false);
	},
	unifiedOrder: data => {
		//下单接口
		return request('/mallapi/orderinfo/unifiedOrder', 'post', data, true);
	},
	userAddressPage: data => {
		//用户收货地址列表
		return request('/mallapi/useraddress/page', 'get', data, false);
	},
	userAddressSave: data => {
		//用户收货地址新增
		return request('/mallapi/useraddress', 'post', data, true);
	},
	userAddressDel: id => {
		//用户收货地址删除
		return request('/mallapi/useraddress/' + id, 'delete', null, false);
	},
	userCollectAdd: data => {
		//用户收藏新增
		return request('/mallapi/usercollect', 'post', data, true);
	},
	userCollectDel: id => {
		//用户收藏删除
		return request('/mallapi/usercollect/' + id, 'delete', null, false);
	},
	userCollectPage: data => {
		//用户收藏列表
		return request('/mallapi/usercollect/page', 'get', data, false);
	},
	goodsAppraisesAdd: data => {
		//商品评价新增
		return request('/mallapi/goodsappraises', 'post', data, true);
	},
	goodsAppraisesPage: data => {
		//商品评价列表
		return request('/mallapi/goodsappraises/page', 'get', data, false);
	},
	qrCodeUnlimited: data => {
		//获取小程序二维码
		return request('/mallapi/wxqrcode/unlimited', 'post', data, true);
	},
	noticeGet: data => {
		//查询商城通知
		return request('/mallapi/notice', 'get', data, true);
	},
	orderItemGet: id => {
		//查询订单详情
		return request('/mallapi/orderitem/' + id, 'get', null, false);
	},
	orderRefundsSave: data => {
		//发起退款
		return request('/mallapi/orderrefunds', 'post', data, true);
	},
	userInfoGet: () => {
		//查询商城用户信息
		return request('/mallapi/userinfo', 'get', null, false);
	},
	pointsRecordPage: data => {
		//查询积分记录
		return request('/mallapi/pointsrecord/page', 'get', data, false);
	},
	pointsConfigGet: () => {
		//查询积分配置
		return request('/mallapi/pointsconfig', 'get', null, false);
	},
	couponUserSave: data => {
		//电子券用户领取
		return request('/mallapi/couponuser', 'post', data, true);
	},
	couponUserPage: data => {
		//电子券用户列表
		return request('/mallapi/couponuser/page', 'get', data, false);
	},
	couponInfoPage: data => {
		//电子券列表
		return request('/mallapi/couponinfo/page', 'get', data, false);
	},
	bargainInfoPage: data => {
		//砍价列表
		return request('/mallapi/bargaininfo/page', 'get', data, false);
	},
	bargainInfoGet: data => {
		//砍价详情
		return request('/mallapi/bargaininfo', 'get', data, true);
	},
	bargainUserSave: data => {
		//发起砍价
		return request('/mallapi/bargainuser', 'post', data, true);
	},
	bargainCutPage: data => {
		//帮砍记录
		return request('/mallapi/bargaincut/page', 'get', data, true);
	},
	bargainUserGet: id => {
		//砍价记录详情
		return request('/mallapi/bargainuser/' + id, 'get', null, false);
	},
	bargainUserPage: data => {
		//砍价记录列表
		return request('/mallapi/bargainuser/page', 'get', data, true);
	},
	bargainCutSave: data => {
		//砍一刀
		return request('/mallapi/bargaincut', 'post', data, true);
	},
	listEnsureBySpuId: data => {
		//通过spuID，查询商品保障
		return request('/mallapi/ensuregoods/listEnsureBySpuId', 'get', data, true);
	},
	grouponInfoPage: data => {
		//拼团列表
		return request('/mallapi/grouponinfo/page', 'get', data, false);
	},
	grouponInfoGet: id => {
		//拼团详情
		return request('/mallapi/grouponinfo/' + id, 'get', null, true);
	},
	grouponUserPageGrouponing: data => {
		//拼团中分页列表
		return request('/mallapi/grouponuser/page/grouponing', 'get', data, true);
	},
	grouponUserPage: data => {
		//拼团记录列表
		return request('/mallapi/grouponuser/page', 'get', data, true);
	},
	grouponUserGet: id => {
		//拼团记录详情
		return request('/mallapi/grouponuser/' + id, 'get', null, false);
	},

	seckillhallList: date => {
		//秒杀会场时间列表
		return request('/mallapi/seckillhall/list?hallDate='+date, 'get', null, false);
	},
	seckillinfoPage: data => {
		//秒杀列表
		return request('/mallapi/seckillinfo/page', 'get', data, false);
	},
	seckillInfoGet: (seckillHallInfoId) => {
		//秒杀详情
		return request('/mallapi/seckillinfo/' + seckillHallInfoId, 'get', null, true);
	},
	wxTemplateMsgList: data => {
		//订阅消息列表
		return request('/mallapi/wxtemplatemsg/list', 'post', data, false);
	},
	liveRoomInfoList: data => {
		//获取直播房间列表
		return request('/mallapi/wxmalive/roominfo/list', 'get', data, true);
	},
	customerServiceList: shopId => {
		//客服列表
		return request('/mallapi/customerservice/list/' + shopId, 'get', null, false);
	},
	getJiguangConfig: data => {
		//获取极光参数
		return request('/mallapi/jiguang/config', 'get', data, false);
	},
	getJiguangMessages: data => {
		//获取极光消息
		return request('/mallapi/jiguang/messages?userName='+data.userName+'&beginTime='+data.beginTime+'&endTime='+data.endTime, 'get', null, false);
	},
};
