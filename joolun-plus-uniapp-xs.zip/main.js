import Vue from 'vue';
import App from './App';
import cuCustom from '@/public/colorui/components/cu-custom.vue'
Vue.component('cu-custom',cuCustom)
//时间插件
import moment from './public/moment/moment.js'
Vue.prototype.$moment = moment//赋值使用
// #ifdef H5
// 路由API： http://hhyang.cn/src/router/start/quickstart.html
import Router, {RouterMount} from 'uni-simple-router';
Vue.use(Router)
//初始化
const router = new Router({
	encodeURI: false, //不编码传输
    routes: ROUTES //路由表
});

// 
router.afterEach((to, from)=>{// 页面跳转后做的处理操作
	if(history){
		let query = to.query
		delete query.detail
		//H5会自动给每个跳转url自动加上tenant_id、app_id，以便链接的复制
		if(!query.tenant_id){
			query.tenant_id =  App.globalData.tenantId
		}
		if(!query.app_id){
			query.app_id =  App.globalData.appId
		}
		var ary = [];
		for (var p in query){
			if (query.hasOwnProperty(p) && query[p]) {
				ary.push(encodeURIComponent(p) + '=' + encodeURIComponent(query[p]));
			}
		}
		if(ary.length > 0){
			let url = "?" + ary.join('&');
			// history.replaceState(null, null, url);//替换页面显示url
			setTimeout(()=>{
				history.replaceState(history.state, null, url); // uni-simple-router 组件中应该做了什么处理操作，这里延迟替换路由页面
			},100);
		}
	}
})
import 'utils/ican-H5Api';// 对齐H5的部分API，保持API通用跨平台；文档：https://ext.dcloud.net.cn/plugin?id=415
// #endif

Vue.config.productionTip = false;
App.mpType = 'app';

const app = new Vue({
    ...App
});

//v1.3.5起 H5端 你应该去除原有的app.$mount();使用路由自带的渲染方式
// #ifdef H5
	RouterMount(app,'#app');
// #endif

// #ifndef H5
	app.$mount(); //为了兼容小程序及app端必须这样写才有效果
// #endif
