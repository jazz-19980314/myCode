<!--
  - Copyright (C) 2018-2019
  - All rights reserved, Designed By www.joolun.com
  - 注意：
  - 本软件为www.joolun.com开发研制，未经购买不得使用
  - 购买后可获得全部源代码（禁止转卖、分享、上传到码云、github等开源平台）
  - 一经发现盗用、分享等行为，将追究法律责任，后果自负
-->
<template>
	<view class="flex justify-end" v-if="orderInfo">
		<navigator class="cu-btn round line-green margin-right" open-type="navigate"
			:url="'/pages/customer-service/customer-service-list/index?shopId='+orderInfo.shopId+ '&orderInfoId='+ orderInfo.id" >
			<view class="cuIcon-servicefill">客服</view>
		</navigator>
		<button class="cu-btn round line-grey margin-right" @tap="orderDel" :loading="loading" :disabled="loading" type v-if="orderInfo.status == '5' && orderInfo.isPay == '0'">删除订单</button>
		<button class="cu-btn round line-grey margin-right" @tap="orderCancel" :loading="loading" :disabled="loading" type
		 v-if="orderInfo.isPay == '0' && !orderInfo.status">取消订单</button>
		<button class="cu-btn round line-grey margin-right" @tap="orderLogistics" :loading="loading" :disabled="loading" type
		 v-if="orderInfo.deliveryWay == '1' && (orderInfo.status == '2' || orderInfo.status == '3' || orderInfo.status == '4')">查看物流</button>
		<button class="cu-btn round line-red margin-right" @tap="unifiedOrder" :loading="loading" :disabled="loading" type
		 v-if="orderInfo.isPay == '0' && !orderInfo.status">付款</button>
		<!-- <button class="cu-btn round line-red margin-right" bindtap="urgeOrder" loading="{{loading}}" 
  disabled="{{loading}}" type="" wx:if="{{orderInfo.status == '1'}}">
    提醒卖家发货
  </button> -->
		<button class="cu-btn round line-red margin-right" @tap="orderReceive" :loading="loading" :disabled="loading" type
		 v-if="orderInfo.status == '2'">确认收货</button>
		<button class="cu-btn round line-red margin-right" @tap="orderAppraise" :loading="loading" :disabled="loading" type
		 v-if="orderInfo.status == '3' && orderInfo.appraisesStatus == '0'">评价</button>
	</view>
</template>

<script>
	/**
	 * Copyright (C) 2018-2019
	 * All rights reserved, Designed By www.joolun.com
	 * 注意：
	 * 本软件为www.joolun.com开发研制，未经购买不得使用
	 * 购买后可获得全部源代码（禁止转卖、分享、上传到码云、github等开源平台）
	 * 一经发现盗用、分享等行为，将追究法律责任，后果自负
	 */
	import api from 'utils/api'
	import util from 'utils/util'
	import jweixin from '@/utils/jweixin'
	
	export default {
		data() {
			return {
				loading: false
			};
		},

		components: {},
		props: {
			orderInfo: {
				type: Object,
				default: () => ({})
			},
			callPay: {
				type: Boolean,
				default: false
			},
			contact: {
				type: Boolean,
				default: false
			}
		},

		mounted() {
			let that = this;
			setTimeout(function() {
				if (that.callPay) {
					that.unifiedOrder();
				}
			}, 1000);
		},

		methods: {
			orderReceive() {
				let that = this;
				uni.showModal({
					content: '是否确认收货吗？',
					cancelText: '我再想想',
					confirmColor: '#ff0000',
					success(res) {
						if (res.confirm) {
							let id = that.orderInfo.id;
							api.orderReceive(id).then(res => {
								that.$emit('orderReceive', res);
							});
						}
					}
				});
			},

			orderCancel() {
				let that = this;
				uni.showModal({
					content: '确认取消该订单吗？',
					cancelText: '我再想想',
					confirmColor: '#ff0000',
					success(res) {
						if (res.confirm) {
							let id = that.orderInfo.id;
							api.orderCancel(id).then(res => {
								that.$emit('orderCancel', res);
							});
						}
					}
				});
			},

			orderDel() {
				let that = this;
				uni.showModal({
					content: '确认删除该订单吗？',
					cancelText: '我再想想',
					confirmColor: '#ff0000',
					success(res) {
						if (res.confirm) {
							let id = that.orderInfo.id;
							api.orderDel(id).then(res => {
								that.$emit('orderDel', res);
							});
						}
					}

				});
			},

			unifiedOrder() {
				this.loading = true;
				var that = this;
				let orderInfo = this.orderInfo;
				api.unifiedOrder({
					id: orderInfo.id,
					// #ifdef MP-WEIXIN
					tradeType: 'JSAPI',
					// #endif
					// #ifdef H5
					tradeType: util.isWeiXinBrowser() ? 'JSAPI' : 'MWEB',
					// #endif
					// #ifdef APP-PLUS
					tradeType: 'APP',
					// #endif
				}).then(res => {
					console.log(res)
					this.loading = false;
					if (orderInfo.paymentPrice <= 0) {
						//0元付款
						that.$emit('unifiedOrder', res);
					} else {
						let payData = res.data;
						// #ifdef MP-WEIXIN
						//微信小程序
						uni.requestPayment({
							provider: 'wxpay',
							timeStamp: payData.timeStamp,
							nonceStr: payData.nonceStr,
							package: payData.packageValue,
							signType: payData.signType,
							paySign: payData.paySign,
							success: function(res) {
								that.$emit('unifiedOrder', res);
							},
							fail: function(res) {
								console.log('fail:' + JSON.stringify(res));
							},
							complete: function(res) {
								console.log(res);
							}
						});
						// #endif
						// #ifdef APP-PLUS
						//app支付
						let orderInfo = {
							"appid": payData.appId,
							"noncestr": payData.nonceStr,
							"package": payData.packageValue,
							"partnerid": payData.partnerId,
							"prepayid": payData.prepayId,
							"timestamp": payData.timeStamp,
							"sign": payData.sign
						}
						uni.requestPayment({
							provider: 'wxpay',
							orderInfo: orderInfo,
							success: function(res) {
								that.$emit('unifiedOrder', res);
							},
							fail: function(res) {
								console.log('fail:' + JSON.stringify(res));
							},
							complete: function(res) {
								console.log(res);
							}
						});
						// #endif
						// #ifdef H5
						if(util.isWeiXinBrowser()){
							//公众号H5
							jweixin.payRequest(payData, res => {
								that.$emit('unifiedOrder', res);
							}, e => {
								
							})
						}
						// #endif
					}
				}).catch(() => {
					this.loading = false;
				});
			},

			urgeOrder() {
				uni.showToast({
					title: '已提醒卖家发货',
					icon: 'success',
					duration: 2000
				});
			},

			orderLogistics() {
				uni.navigateTo({
					url: '/pages/order/order-logistics/index?id=' + this.orderInfo.orderLogistics.id
				});
			},

			orderAppraise() {
				uni.navigateTo({
					url: '/pages/appraises/form/index?orderId=' + this.orderInfo.id
				});
			}
		}
	};
</script>
<style>
</style>
