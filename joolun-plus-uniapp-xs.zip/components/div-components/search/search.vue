<template>
	<view class="cu-bar search fixed" :style="[{top:CustomBar+19 + 'px'}]" :class="'bg-'+theme.backgroundColor" style="">
		<view class="search-form round" :style="{backgroundColor: newData.color, borderRadius: `${newData.radius}rpx`,color: `${newData.textColor}`}">
			<text class="cuIcon-search" style="position:fixed;"></text>
			<navigator class="response" hover-class="none" url="/pages/base/search/index">
				<view :style="{color: newData.textColor, 'text-align':newData.textPosition == 'center'?'center':'left'}">{{newData.placeholder}}</view>
			</navigator>
		</view>
	</view>
</template>

<script>
	const app = getApp();
	export default {
		name: 'basic-search',
		props: {
			value: {
				type: Object,
				default: function() {
					return {
						background: `#efeff4`,
						color: '#ffffff',
						placeholder: '请输入关键字',
						radius: 38,
						textColor: '#999999',
						textPosition: `center`,
					}
				}
			}
		},
		components: {},
		data() {
			return {
				theme: app.globalData.theme, //全局颜色变量
				newData: this.value,
				CustomBar: this.CustomBar,
			};
		},
		methods: {}
	}
</script>

<style scoped lang="scss">
	.fixed {
		position: fixed;
		width: 100%;
		top: 20px;
		z-index: 1024;
		box-shadow: 0 1rpx 6rpx rgba(0, 0, 0, 0.1)
	}
</style>
