<script>
	/**
	 * Copyright (C) 2018-2019
	 * All rights reserved, Designed By www.joolun.com
	 * 注意：
	 * 本软件为www.joolun.com开发研制，未经购买不得使用
	 * 购买后可获得全部源代码（禁止转卖、分享、上传到码云、github等开源平台）
	 * 一经发现盗用、分享等行为，将追究法律责任，后果自负
	 */
	import Vue from 'vue'
	import api from 'utils/api'
	import util from 'utils/util'
	import __config from 'config/env';
	import JMessage from 'public/jmessage-wxapplet-sdk/jmessage-wxapplet-sdk-1.4.0.min.js'

	// #ifdef APP-PLUS
	import APPUpdate from "@/public/APPUpdate/index.js";//App版本更新
	// #endif

	export default {
		globalData: {
			shoppingCartCount: 0,//购物车数量
			tenantId: null,//租户Id
			appId: null,//公众号appId
			theme: { //主题定义
				backgroundColor: null, //背景颜色,支持渐变色
				themeColor: null, //主题颜色
				tabbarBackgroundColor: null,//tabbar背景颜色
				tabbarColor: null,//tabBar上的文字默认颜色
				tabbarSelectedColor: null,//tabBar上的文字选中时的颜色
				tabbarBorderStyle: null,//tabBar上边框的颜色
				tabbarItem: []//tabBar明细设置
			},
			navButton: [],//导航按钮
            JIM: null,//极光JMessage
		},
		onLaunch: function() {
			// #ifdef MP
			//小程序平台检测新版本
			this.updateManager();
			// #endif
			// 原生app版本更新检测
			// #ifdef APP-PLUS
			APPUpdate();
			// #endif

			// #ifdef H5
			// H5平台获取参数中的租户ID、公众号appID,并存入globalData
			let local = location.href
			let tenantId = util.getUrlParam(local, "tenant_id");
			let appId = util.getUrlParam(local, "app_id");
			this.globalData.tenantId = tenantId;
			this.globalData.appId = appId;
			// #endif

			// #ifdef APP-PLUS
			// APP平台需要从配置文件中获取租户ID
			let tenantId = __config.tenantId;
			this.globalData.tenantId = tenantId;
			// #endif

			//设置全局样式
			this.setGlobalStyle();
			//获取购物车数量
			if(uni.getStorageSync('third_session')){
				this.shoppingCartCount();
			}
		},

		methods: {
			//设置全局样式
			setGlobalStyle() {
				uni.getSystemInfo({
					success: function(e) {
					    // [2020-08-01]更新ColorUI 修复ios 状态栏错位
                        // #ifndef MP
                        Vue.prototype.StatusBar = e.statusBarHeight;
                        if (e.platform == 'android') {
                            Vue.prototype.CustomBar = e.statusBarHeight + 50;
                        } else {
                            Vue.prototype.CustomBar = e.statusBarHeight + 45;
                        };
                        // #endif
                        // #ifdef MP-WEIXIN || MP-QQ
                        Vue.prototype.StatusBar = e.statusBarHeight;
                        let capsule = wx.getMenuButtonBoundingClientRect();
                        if (capsule) {
                            Vue.prototype.Custom = capsule;
                            // Vue.prototype.capsuleSafe = uni.upx2px(750) - capsule.left + uni.upx2px(750) - capsule.right;
                            Vue.prototype.CustomBar = capsule.bottom + capsule.top - e.statusBarHeight;
                        } else {
                            Vue.prototype.CustomBar = e.statusBarHeight + 50;
                        }
                        // #endif
                        // #ifdef MP-ALIPAY
                        Vue.prototype.StatusBar = e.statusBarHeight;
                        Vue.prototype.CustomBar = e.statusBarHeight + e.titleBarHeight;
                        // #endif
					}
				})
				//获取主题装修配置
				api.themeMobileGet().then(res => {
					let themeMobile = res.data;
					//设置导航按钮
					if(themeMobile && themeMobile.navButton && themeMobile.navButton.info && themeMobile.navButton.info.length > 0){
						uni.$emit('navButton',themeMobile.navButton.info)
						this.globalData.navButton = themeMobile.navButton.info
					}
					//定义默认配置
					let backgroundColor = 'gradual-scarlet';
					let themeColor = 'red';
					let tabbarBackgroundColor = '#ffffff';
					let tabbarColor = '#666666';
					let tabbarSelectedColor = '#e53c43';
					let tabbarBorderStyle = '#black';
					let tabbarItem = [
						{
							index: 0,
							text: '首页',
							iconPath: '/static/public/img/icon-1/1-001.png',
							selectedIconPath: '/static/public/img/icon-1/1-002.png'
						},
						{
							index: 1,
							text: '分类',
							iconPath: '/static/public/img/icon-1/2-001.png',
							selectedIconPath: '/static/public/img/icon-1/2-002.png'
						},
						{
							index: 2,
							text: '消息',
							iconPath: '/static/public/img/icon-1/3-001.png',
							selectedIconPath: '/static/public/img/icon-1/3-002.png'
						},
						{
							index: 3,
							text: '购物车',
							iconPath: '/static/public/img/icon-1/4-001.png',
							selectedIconPath: '/static/public/img/icon-1/4-002.png'
						},
						{
							index: 4,
							text: '我的',
							iconPath: '/static/public/img/icon-1/5-001.png',
							selectedIconPath: '/static/public/img/icon-1/5-002.png'
						}
					]
					//将默认配置换成后台数据
					if(themeMobile){
						themeColor = themeMobile.themeColor
						backgroundColor = themeMobile.backgroundColor
						tabbarBackgroundColor = themeMobile.tabbarBackgroundColor
						tabbarColor = themeMobile.tabbarColor
						tabbarSelectedColor = themeMobile.tabbarSelectedColor
						tabbarBorderStyle = themeMobile.tabbarBorderStyle
					}
					this.globalData.theme.backgroundColor = backgroundColor
					this.globalData.theme.themeColor = themeColor
					this.globalData.theme.tabbarBackgroundColor = tabbarBackgroundColor
					this.globalData.theme.tabbarColor = tabbarColor
					this.globalData.theme.tabbarSelectedColor = tabbarSelectedColor
					this.globalData.theme.tabbarBorderStyle = tabbarBorderStyle
					this.globalData.theme.tabbarItem = tabbarItem
					if(themeMobile && themeMobile.tabbarItem && themeMobile.tabbarItem.info.length > 0){
						let tabbarItemInfo = themeMobile.tabbarItem.info
						tabbarItemInfo.forEach(item => {
							if(item.text)tabbarItem[item.index].text = item.text
							if(item.iconPath)tabbarItem[item.index].iconPath = item.iconPath
							if(item.selectedIconPath)tabbarItem[item.index].selectedIconPath = item.selectedIconPath
						})
						this.globalData.theme.tabbarItem = tabbarItem
					}
					this.setTabBar()
				});
			},

			// #ifdef MP
			//小程序平台检测新版本
			updateManager() {
				const updateManager = uni.getUpdateManager();
				updateManager.onUpdateReady(function() {
					uni.showModal({
						title: '更新提示',
						content: '新版本已经准备好，是否重启应用？',
						success(res) {
							if (res.confirm) {
								updateManager.applyUpdate();
							}
						}
					});
				});
			},
			// #endif

			//设置tabbar
			setTabBar(){
				let themeMobile = this.globalData.theme
				if(themeMobile.tabbarBackgroundColor){
					//动态设置 tabBar 的整体样式
					uni.setTabBarStyle({
						backgroundColor: themeMobile.tabbarBackgroundColor,
						color: themeMobile.tabbarColor,
						selectedColor: themeMobile.tabbarSelectedColor,
						borderStyle: themeMobile.tabbarBorderStyle
					});
					let tabbarItem = themeMobile.tabbarItem;
					tabbarItem.forEach(item => {
						//动态设置 tabBar 某一项的内容
						let iconPath = item.iconPath;
						let selectedIconPath = item.selectedIconPath;
						// #ifdef H5
						//uni tabBar H5不支持http的图片,但是修改一下可以支持
						if(selectedIconPath.indexOf('http')!=-1){ // 此判断包括 http 和 https
							let indexTemp = selectedIconPath.indexOf(':/')+1;
							selectedIconPath = selectedIconPath.substring(indexTemp, selectedIconPath.length);
						}
						if(iconPath.indexOf('http')!=-1){
							let indexTemp = iconPath.indexOf(':/')+1;
							iconPath = iconPath.substring(indexTemp, iconPath.length);
						}
						// #endif
						uni.setTabBarItem({
							index: item.index,
							text: item.text,
							iconPath: iconPath,
						    selectedIconPath: selectedIconPath
						});
					})
				}
			},

			//获取购物车数量
			shoppingCartCount(){
				api.shoppingCartCount().then(res => {
					let shoppingCartCount = res.data;
					this.globalData.shoppingCartCount = shoppingCartCount + '';
					uni.setTabBarBadge({
						index: 3,
						text: this.globalData.shoppingCartCount + ''
					});
				});
			},
			//页面初始化方法，供每个页面调用
			initPage() {
				let that = this;
				return new Promise((resolve, reject) => {
					that.setTabBar()
					//小程序或公众号H5，每个页面都进行登录校验
					if(util.isMiniPg() || (that.globalData.appId && util.isWeiXinBrowser())){
						if (!uni.getStorageSync('third_session')) {
							//无thirdSession，进行登录
							that.doLogin().then(res => {
								//初始化极光IM
								that.initJIM();
								resolve("success");
							});
						} else {
							//初始化极光IM
							that.initJIM();
							resolve("success");
						}
					}else{
						//初始化极光IM
						that.initJIM();
						resolve("success");
					}
				});
			},

			//登录操作
			doLogin() {
				uni.showLoading({
					title: '登录中'
				});
				return new Promise((resolve, reject) => {
					// #ifdef MP-WEIXIN
					//微信小程序登录
					this.loginWxMa().then(res => {
						resolve("success");
					});
					// #endif
					// #ifdef H5
					//微信公众号H5
					if(util.isWeiXinBrowser()){
						let local = location.href
						let code = util.getUrlParam(local, "code");
						let state = util.getUrlParam(local, "state");
						//授权code登录
						if(code){//有code
							if(state == 'snsapi_base'){//登录授权
								this.loginWxMp(code).then(res => {
									resolve("success");
								});
							}
						}else{//无code则发起网页授权
							//微信公众号H5，页面授权登录
							let appId = this.globalData.appId;
							let pages = getCurrentPages();
							let currentPage = pages[pages.length - 1];
							let route = currentPage.route;
							let redirectUri = location.href;
							redirectUri = encodeURIComponent(redirectUri);
							let wx_url = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid='+appId+
								'&redirect_uri='+redirectUri+
								'&response_type=code&scope=snsapi_base&state=snsapi_base#wechat_redirect';
							location.href = wx_url;
						}
					}
					// #endif
				});
			},
			//微信小程序登录
			// #ifdef MP-WEIXIN
			loginWxMa(){
				return new Promise((resolve, reject) => {
					let that = this;
					uni.login({
						success: function(res) {
							if (res.code) {
								api.loginWxMa({
									jsCode: res.code
								}).then(res => {
									uni.hideLoading();
									let userInfo = res.data;
									uni.setStorageSync('third_session', userInfo.thirdSession);
									uni.setStorageSync('user_info', userInfo);
									// 获取购物车数量
									that.shoppingCartCount();
									resolve("success");
								});
							}
						}
					});
				});
			},
			// #endif
			//公众号登录
			// #ifdef H5
			loginWxMp(code) {
				let that = this;
				return new Promise((resolve, reject) => {
					let that = this
					api.loginWxMp({
						jsCode: code
					}).then(res => {
						//公众号h5网页授权时url会产生code、state参数，防止code、state被复制，需自动剔除
						let query = that.$Route.query;
						delete query.code;
						delete query.state;
						util.resetPageUrl(query);
						let userInfo = res.data;
						uni.setStorageSync('third_session', userInfo.thirdSession);
						uni.setStorageSync('user_info', userInfo);
						//获取购物车数量
						that.shoppingCartCount();
						resolve("success");
					}).catch(res=>{

					});
				});
			},
			// #endif
			//初始化极光IM
			initJIM(){
				let that = this
				if(!this.globalData.JIM){
					try {
						this.globalData.JIM = new JMessage({})
					} catch(e) {
						console.log(e)
					}
				} 
				return new Promise((resolve, reject) => {
					//获取用户信息
					let userInfo = uni.getStorageSync('user_info')
					let thirdSession = uni.getStorageSync('third_session')
					//还不是商城用户，不登录极光
					if(!userInfo || !userInfo.id || !thirdSession){
						console.log("还不是商城用户，不登录极光")
						resolve("success");
						return
					}
					let JIM = that.globalData.JIM
					if(JIM.isInit()){//极光IM已经初始化，直接登录
						console.log("极光IM已经初始化，直接登录")
						that.loginJIM(userInfo).then(res => {
							resolve("success");
						});
					}else{
						api.getJiguangConfig().then(res => {
							//初始化
							JIM.init({
								"appkey"    : res.data.appkey,
								"random_str": res.data.random_str,
								"signature" : res.data.signature,
								"timestamp" : res.data.timestamp,
								"flag": res.data.flag
							}).onSuccess(function(data) {
								console.log('JIMInitSuccess')
								that.loginJIM(userInfo).then(res => {
									resolve("success");
								});
							}).onFail(function(data) {
								console.log('JIMInitFail')
								console.log(data)
								uni.showModal({
									title: '极光初始化失败',
									content: data.message,
									success() {},
									complete() {

									}
								});
								resolve("success");
							});
							//
							JIM.onDisconnect(function(){
								console.log('JIM断开链接')
							});

							JIM.onMsgReceive(function(data) {
								// 接受在线消息
								console.log('在线接受消息')
								console.log(data)
								//更新消息未读数
								that.getJIMUnreadMsgCnt()
								uni.$emit('msg_ol',data.messages[0].content)
							});

							//JIM.isInit();// 无回调函数，调用则成功
							Vue.prototype.onSyncConversation=null
							uni.$once('onSyncConversation',function(data){
								that.onSyncConversation=data
								console.log('离线传递：')
								console.log(data)
								uni.$off()
							})
						});
					}
				});
			},
			//极光登录
			loginJIM(userInfo){
				let that = this
				let username = userInfo.id
				let password = userInfo.id
				return new Promise((resolve, reject) => {
					let JIM = that.globalData.JIM
					if(JIM.isLogin()){
						console.log("极光IM已经登录，无需再登录");
						resolve("success");
						return
					};
					//登录
					JIM.login({
						'username': username,
						'password': password
					}).onSuccess(function(data){
						console.log("极光IM登录成功");
						that.updataJIMUserInfo(userInfo).then(res => {
							resolve("success");
						});
						//更新消息未读数
						that.getJIMUnreadMsgCnt()
					}).onFail(function(data){
						//如果用户不存在，则注册账号
						if(data.code == 880103){
							let nickname = userInfo.nickName
							JIM.register({
								'username' : username,
								'password' : password,
								'nickname' : nickname,
								'extras': {
									'avatar': userInfo.headimgUrl
								}
							}).onSuccess(function(data) {
								console.log("极光IM注册成功");
								//登录
								JIM.login({
									'username': username,
									'password': password
								}).onSuccess(function(data){
									console.log("极光IM登录成功");
									that.updataJIMUserInfo(userInfo).then(res => {
										resolve("success");
									});
									//更新消息未读数
									that.getJIMUnreadMsgCnt()
								}).onFail(function(data){
									uni.showModal({
										title: '极光IM登录失败',
										content: data.message,
										success() {},
										complete() {

										}
									});
									console.log(data)
									resolve("success");
								});
							  }).onFail(function(data) {
								console.log('JIM -注册失败')
								console.log(data)
								uni.showModal({
									title: '极光IM注册失败',
									content: data.message,
									success() {},
									complete() {

									}
								});
								resolve("success");
							});
						}else if(data.code == 880109 || data.code == 880107){
							console.log(data)
						} else{
							// uni.showModal({
							// 	title: '极光IM登录失败',
							// 	content: data.message,
							// 	success() {},
							// 	complete() {

							// 	}
							// });
							console.log('极光IM登录失败')
							console.log(data)
							console.log('username,password：' + username + ',' + password)
							resolve("success");
						}
					});
				});
			},
			//获取极光未读数
			getJIMUnreadMsgCnt(){
				let JIM = this.globalData.JIM
				JIM.getConversation().onSuccess(function(data) {
					let conversation = data.conversations.reverse()
					let count = 0
					for (var i = 0; i < conversation.length; i++) {
						count = count + conversation[i].unread_msg_count
					}
					if(count>0){
                        //设置tabbar未读数量
                        uni.setTabBarBadge({
                            index: 2,
                            text: count + ''
                        });
                    }
				}).onFail(function(data) {
					console.log('JIM fail:' + data )
				});
			},
			//更新极光IM用户信息
			updataJIMUserInfo(userInfo) {
				let that = this
				let username = userInfo.id
				return new Promise((resolve, reject) => {
					let JIM = that.globalData.JIM;
					JIM.getUserInfo({
						'username': username,
					}).onSuccess(function(data) {
						//data.code 返回码
						//data.message 描述
						//data.user_info.username
						//data.user_info.appkey
						//data.user_info.nickname
						//data.user_info.avatar 头像
						//data.user_info.birthday 生日，默认空
						//data.user_info.gender 性别 0 - 未知， 1 - 男 ，2 - 女
						//data.user_info.signature 用户签名
						//data.user_info.region 用户所属地区
						//data.user_info.address 用户地址
						//data.user_info.mtime 用户信息最后修改时间
						//data.extras 自定义json字段
						console.log('获取IM用户信息成功')
						let nickname = userInfo.nickName
						if(data.user_info.nickname != nickname || data.user_info.extras.avatar != userInfo.headimgUrl){
							console.log('更新JIM用户信息')
							JIM.updateSelfInfo({
								'nickname': nickname,
								'extras': {
									'avatar': userInfo.headimgUrl
								}
							}).onSuccess(function(data) {
								//data.code 返回码
								//data.message 描述
								resolve("success");
							}).onFail(function(data) {
								console.log('updataJIMUserInfo fail:' + data)
								resolve("success");
							});
						}else{
							resolve("success");
						}
					}).onFail(function(data) {
						//data.code 返回码
						//data.message 描述
						resolve("success");
					});
				});
			}
		}
	};
</script>
<style>
	@import "./app.css";
</style>
