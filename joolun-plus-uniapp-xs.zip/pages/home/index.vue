<!--
  - Copyright (C) 2018-2019
  - All rights reserved, Designed By www.joolun.com
  - 注意：
  - 本软件为www.joolun.com开发研制，未经购买不得使用
  - 购买后可获得全部源代码（禁止转卖、分享、上传到码云、github等开源平台）
  - 一经发现盗用、分享等行为，将追究法律责任，后果自负
-->
<template>
	<view>
		<cu-custom :bgColor="'bg-'+theme.backgroundColor" :isBack="false">
			<block slot="content">首页</block>
		</cu-custom>
		<view class="location text-white" :style="[{top:CustomBar + 'px'}]" :class="'bg-'+theme.backgroundColor" @tap="getLocation">
			<text class="cuIcon-locationfill"></text>
			<view>送至:{{location}}</view>
			<text class="cuIcon-unfold"></text>
		</view>
		<!-- <view class="fixed" style="top: 40rpx;width: 100%;">
			<div-search></div-search>
		</view> -->
		<div-search></div-search>
		<view class="cu-bar fixed flex top-home classification" :class="'bg-'+theme.backgroundColor" style="margin-top: 132rpx;">
			<view class="classification-width">
				<scroll-view scroll-x class="nav text-white text-sm" scroll-with-animation :scroll-left="scrollLeft">
					<view class="cu-item" :class="index==TabCur ? 'cur text-bold text-white text-lg' : ''" v-for="(item,index) in firstCategoryData"
					 :key="index" @tap="tabSelect" :data-index="index">
						{{item.name}}
					</view>
				</scroll-view>
			</view>
			<view class="action">
				<navigator url="/pages/goods/goods-category/index" open-type="switchTab" hover-class="none" class="cuIcon-moreandroid text-white"></navigator>
			</view>
		</view>

		<!-- 首页内容 -->
		<view class="margin-top-bar" v-if="TabCur == 0">
			<!-- 首页轮播图-->
			<view class="swiper-bg" :class="'bg-'+theme.backgroundColor"></view>
			<swiper class="card-swiper square-dot banners" indicator-dots="true" circular="true" autoplay="false" interval="5000"
			 duration="500" @change="cardSwiper" indicator-color="#8799a3" indicator-active-color="#fff">
				<swiper-item v-for="(item,index) in swiperData" :key="index" :class="cardCur==index?'cur':''" @tap="jumpPage(item.page)">
					<view class="swiper-item">
						<image :src=" item.url" mode="aspectFill" v-if="item.type=='1'"></image>
						<video :src="item.url" autoplay loop muted :show-play-btn="false" :controls="false" objectFit="cover" v-if="item.type=='video'"></video>
					</view>
				</swiper-item>
			</swiper>

			<view class="cu-list grid no-border margin-top-sm navButton col-5" v-if="navButton.length>0">
				<view class="cu-item" v-for="(item,index) in navButton" :key="index">
					<navigator :url="item.url+'?type='+index" hover-class="none" :open-type="item.url=='/pages/goods/goods-category/index'?'switchTab':'navigate'">
						<image :src="item.img" class="nav_bt_img"></image>
						<text class="nav-text">{{item.name}}</text>
					</navigator>
				</view>
			</view>
			<!-- 公告 -->
			<view class="adsec light bg-yellow margin-bottom-sm" v-if="noticeData.length > 0">
				<view class="adsec-icon text-xl margin-right-xs margin-left-xs"><text class="cuIcon-notification text-red"></text></view>
				<swiper class="swiper_container" autoplay="true" circular="true" interval="6000">
					<swiper-item v-for="(item, index) in noticeData" :key="index" @tap="jumpPage(item.page)" :data-page="item.page">
						<view class="text-orange text-sm">
							<text class="round bg-red announcement text-xs">{{item.tag}}</text>
							<text class="details margin-left-xs">{{item.content}}</text>
							<text v-if="item.page" class="cuIcon-right"></text>
						</view>
					</swiper-item>
				</swiper>
			</view>
			<view class="wrapper-list bg-hot" style="margin-top: 0;" v-if="shopInfoData.length > 0">
				<view class="cu-bar">
					<image mode="" src="https://qtvedio.oss-cn-qingdao.aliyuncs.com/1303209733649600512/material/dd835b73-e5de-42ef-b9c5-89681ad611d6.png"></image>
					<navigator hover-class="none" url='/pages/shop/shop-list/index' class='action'>
						<view class="getMore">
							更多<text class='cuIcon-right'></text>
						</view>
					</navigator>
				</view>
				<scroll-view class="scroll-view_x shop-detail" scroll-x>
					<block v-for="(item, index) in shopInfoData" :key="index">
						<navigator hover-class="none" :url="'/pages/shop/shop-detail/index?id=' + item.id" class="item shadow-warp flex shop-box radius">
							<view class="bg-mask flex shop-image radius">
								<image :src="item.imgUrl" class="radius"></image>
							</view>
							<view class="shop-information text-center">
								<view class="text-white enter-shop text-sm ">进店<text class="cuIcon-right"></text></view>
								<view class="bg-white round enter-bg"></view>
							</view>
							<view class="overflow-2 text-white text-center text-xs shop-name">{{item.name}}</view>
						</navigator>
					</block>
				</scroll-view>
			</view>
			<!-- 特约店铺 -->
			<view class="bg-white radius shop-card" v-show="shopInfo.length" v-for="(item, index) in shopInfo" :key="index">
				<navigator class="flex padding-top-sm margin-left-sm justify-between align-center" hover-class="none" :url="'/pages/shop/shop-detail/index?id='+item.id">
					<view class="round flex align-center justify-between" style="width: 73%;">
						<image :src="item.imgUrl" class="head-image"></image>
						<view style="width: 80%;" class="text-sm padding-top-xs flex align-start justify-start flex-direction">
							<text class="text-bold">{{item.name}}</text>
							<text class="overflow-1">{{item.detail}}</text>
						</view>
					</view>
					<view class="margin-right-sm">
						<text class="round enter-store" :class="'bg-'+theme.themeColor">进入店铺</text>
					</view>
				</navigator>
				<view class="grid margin-left-sm margin-top-xs">
					<block v-for="(item2, index) in item.listGoodsSpu" :key="index">
						<navigator hover-class="none" :url="'/pages/goods/goods-detail/index?id=' + item2.id" class="goods-item">
							<image class="top radius img-box" :src="item2.picUrls[0]"></image>
							<text class="overflow-2 text-sm ">{{item2.name}}</text>
							<text class="text-gray text-xs">已售{{item2.saleNum}}</text>
							<text class="text-bold text-red flex">￥{{item2.priceDown}}</text>
						</navigator>
					</block>
					<view v-if="item.listGoodsSpu.length <= 0" class="no-goods">
						<image src="/static/public/img/no-item.png" class="no-item margin-top"></image>
						<view class="text-sm text-gray text-center">店主很懒，还没有上架商品哦～</view>
					</view>
				</view>
			</view>
			<view class="wrapper margin-top-xs" v-if="goodsListHot.length > 0" v-show="false">
				<view class="cu-bar bg-image" :class="'bg-'+theme.themeColor">
					<view class="hot-item text-df margin-left">
						<text class="cuIcon-hot text-bold text-white"></text>
						<text class="margin-left-xs">热销单品</text></view>
					<navigator hover-class="none" url="/pages/goods/goods-list/index?type=2" class="hot-more text-sm margin-right">更多<text
						 class="cuIcon-right"></text></navigator>
				</view>
				<view class="wrapper-list hot-product">
					<scroll-view class="scroll-view_x" scroll-x style="width:auto;overflow:hidden;">
						<block v-for="(item, index) in goodsListHot" :key="index">
							<navigator hover-class="none" :url="'/pages/goods/goods-detail/index?id=' + item.id" class="item shadow-warp radius goods-card">
								<view class="img-box">
									<image :src="item.picUrls[0] ? item.picUrls[0] : '/static/public/img/no_pic.png'"></image>
								</view>
								<view class="text-cut goods-name margin-top-sm text-sm">{{item.name}}</view>
								<view class="text-price text-red margin-left-sm margin-xs text-lg text-bold">{{item.priceDown}}</view>
							</navigator>
						</block>
					</scroll-view>
				</view>
			</view>

			<view class="wrapper bg-white margin-top-sm" v-if="goodsListNew.length > 0">
				<view class="cu-bar bg-white">
					<view class="text-df margin-left">
						<text class="cuIcon-new text-bold" :class="'text-'+theme.themeColor"></text>
						<text class="margin-left-xs">新品首发</text></view>
					<navigator hover-class="none" url="/pages/goods/goods-list/index?type=1" class=" text-sm margin-right">更多<text
						 class="cuIcon-right"></text>
					</navigator>
				</view>
				<view class="wrapper-list">
					<scroll-view class="scroll-view_x" scroll-x style="width:auto;overflow:hidden;">
						<block v-for="(item, index) in goodsListNew" :key="index">
							<navigator hover-class="none" :url="'/pages/goods/goods-detail/index?id=' + item.id" class="item shadow-warp goods-card radius">
								<view class="img-box">
									<image :src="item.picUrls[0] ? item.picUrls[0] : '/static/public/img/no_pic.png'"></image>
								</view>
								<view class="text-cut goods-name margin-top-sm text-sm">{{item.name}}</view>
								<view class="text-price text-red margin-left-sm margin-xs text-lg text-bold">{{item.priceDown}}</view>
							</navigator>
						</block>
					</scroll-view>
				</view>
			</view>

			<!-- 微信小程序直播 -->
			<!-- #ifdef MP-WEIXIN -->
			<!-- <navigator class="live" hover-class="none" url="/pages/live/room-list/index">
				<image class="bg-white" src="../../static/public/img/live.gif"></image>
				<view class="text-sm text-white text-center margin-top-xs live-text">直播</view>
			</navigator> -->
			<!-- #endif -->

			<view class="cu-bar justify-center">
				<view class="action text-bold" :class="'text-'+theme.themeColor">
					<text class="cuIcon-move"></text> <text class="cuIcon-like"></text>猜你喜欢<text class="cuIcon-move"></text>
				</view>
			</view>
			<goods-row :goodsList="goodsList"></goods-row>
			<view :class="'cu-load bg-gray ' + (loadmore?'loading':'over')"></view>
		</view>
		<!-- 分类内容 -->
		<view class="margin-top-bar" v-if="TabCur != 0">
			<view class="cu-list grid col-5 no-border">
				<view class="cu-item commodity" v-for="(item, index) in secondCategoryData" :key="index" v-if="index < 9">
					<navigator :url="'/pages/goods/goods-list/index?categorySecond=' + item.id + '&title=' + item.name" hover-class="none">
						<image class="img-category" :src="item.picUrl"></image>
						<text class="text-black">{{item.name}}</text>
					</navigator>
				</view>
				<view class="cu-item more">
					<navigator url="/pages/goods/goods-category/index" open-type="switchTab" @click="setGoodsCategoryParam()"
					 hover-class="none" v-if="secondCategoryData.length>=9">
						<view class="text-gray cuIcon-more"></view>
						<text class="text-black">更多分类</text>
					</navigator>
				</view>
			</view>
			<view class="cu-card case">
				<view class="cu-item">
					<view class="image" style="height: 180rpx;">
						<image class="img-category-banner" :src="firstCategoryData[TabCur].picUrl" @click="jumpPage(firstCategoryData[TabCur].page)"></image>
					</view>
				</view>
			</view>
			<view class="cu-bar justify-center bg-white margin-top-sm">
				<view class="action border-title">
					<text class="cuIcon-hot" :class="'text-'+theme.themeColor"></text>更多热卖<text :class="'bg-'+theme.themeColor" style="width:5rem"></text>
				</view>
			</view>
			<goods-card :goodsList="goodsList2"></goods-card>
			<view :class="'cu-load bg-gray ' + (loadmore2?'loading':'over')"></view>
		</view>
		<!-- 用户隐私政策授权弹框,小程序端首页不弹出 -->
		<!-- #ifdef APP-PLUS -->
		<privacy-policy v-if="showPrivacyPolicy"></privacy-policy>
		<!-- #endif -->
		<view class="cu-modal" :class="modalName=='Modal'?'show':''">
			<view class="cu-dialog">
				<view class="cu-bar bg-white justify-end">
					<view class="content">提示</view>
					<view class="action" @tap="hideModal">
						<text class="cuIcon-close text-red"></text>
					</view>
				</view>
				<view class="padding-xl">
					正在努力开发中，敬请期待。。。
				</view>
			</view>
		</view>
		<!-- #ifdef MP-WEIXIN -->
		<!-- 授权请求 -->
		<view class="cu-modal" :class="modalName=='DialogModal1'?'show':''">
			<view class="cu-dialog">
				<view class="cu-bar bg-white justify-end">
					<view class="content">请求授权当前位置</view>
					<view class="action" @tap="hideModal">
						<text class="cuIcon-close text-red"></text>
					</view>
				</view>
				<view class="padding-xl">
					需要获取您的地理位置，请确认授权
				</view>
				<view class="cu-bar bg-white justify-around">
					<view class="action">
						<button class="cu-btn line-blue text-green" @tap="hideModal">取消</button>
						<button class="cu-btn bg-blue margin-left" @tap="openSet">确定</button>
					</view>
				</view>
			</view>
		</view>
		<!-- #endif -->
	</view>
</template>

<script>
	/**
	 * Copyright (C) 2018-2019
	 * All rights reserved, Designed By www.joolun.com
	 * 注意：
	 * 本软件为www.joolun.com开发研制，未经购买不得使用
	 * 购买后可获得全部源代码（禁止转卖、分享、上传到码云、github等开源平台）
	 * 一经发现盗用、分享等行为，将追究法律责任，后果自负
	 */
	// #ifdef APP-PLUS
	import privacyPolicy from '@/components/privacy-policy/index';
	// #endif
	const app = getApp();
	import api from 'utils/api'
	import divSearch from "@/components/div-components/search/search.vue";
	import goodsCard from "components/goods-card/index";
	import goodsRow from "components/goods-row/index";
	import shopInfo from "components/shop-info/index";

	import __config from "@/config/env";
	const util = require("utils/util.js");
	// #ifdef MP-WEIXIN
	import QQMapWX from "@/utils/qqmap-wx-jssdk.js"
	var qqmapsdk = new QQMapWX({
		key: 'HX5BZ-62JKS-RVBO2-6HZZP-KWZ2E-JCB47'
	});
	// #endif
	export default {
		data() {
			return {
				showPrivacyPolicy: __config.showPrivacyPolicy,
				theme: app.globalData.theme, //全局颜色变量
				CustomBar: this.CustomBar,
				page: {
					searchCount: false,
					current: 1,
					size: 10
				},
				loadmore: true,
				goodsList: [],
				goodsListNew: [],
				goodsListHot: [],
				swiperData: [],
				noticeData: [],
				scrollLeft: 0,
				navButton: app.globalData.navButton, //导航按钮
				cardCur: 0,
				shopInfoData: [],
				TabCur: 0,
				firstCategoryData: [{
					id: '-1',
					name: '首页'
				}],
				secondCategoryData: [],
				page2: {
					searchCount: false,
					current: 1,
					size: 10
				},
				loadmore2: true,
				goodsList2: [],
				modalName: null,
				location: '',
				shopInfo: []
			};
		},

		components: {
			// #ifdef APP-PLUS
			privacyPolicy,
			// #endif
			goodsCard,
			goodsRow,
			divSearch,
			shopInfo
		},
		props: {},
		onLoad() {
			let that = this
			uni.$on('navButton', function(data) { //监听导航按钮的变化
				that.navButton = data
			})
			app.initPage().then(res => {
				this.loadData();
			});
			// #ifdef APP-PLUS
			uni.getLocation({
				geocode: true,
				type: "gcj02",
				success: function(res) {
					that.location = res.address.street
				}
			})
			// #endif
		},
		onShow() {
			//更新购物车tabar角标数量
			uni.setTabBarBadge({
				index: 3,
				text: app.globalData.shoppingCartCount + ''
			});
			var _this = this;
			// #ifdef MP-WEIXIN
			this.getPosition();
			uni.getSetting({
				success(res) {
					if (!res.authSetting['scope.userLocation']) {
						uni.authorize({
							scope: 'scope.userLocation',
							success(res) {
								_this.getPosition();
							},
							fail: function(res) {
								_this.modalName = 'DialogModal1'
							}
						})
					} else {
						_this.getPosition();
					}
				}
			})
			// #endif

		},

		onShareAppMessage: function() {
			let title = '锋德鲜生';
			let path = 'pages/home/index';
			return {
				title: title,
				path: path,
				success: function(res) {
					if (res.errMsg == 'shareAppMessage:ok') {
						console.log(res.errMsg);
					}
				},
				fail: function(res) { // 转发失败
				}
			};
		},

		onPullDownRefresh() {
			// 显示顶部刷新图标
			uni.showNavigationBarLoading();
			this.refresh(); // 隐藏导航栏加载框
			uni.hideNavigationBarLoading(); // 停止下拉动作
			uni.stopPullDownRefresh();
		},

		onReachBottom() {
			if (this.TabCur === 0 && this.loadmore) {
				this.page.current = this.page.current + 1;
				this.goodsPage();
			}
			if (this.TabCur == !0 && this.loadmore2) {
				this.page2.current = this.page2.current + 1;
				this.goodsPageByCateGory();
			}
		},

		methods: {
			//特约电铺
			shopInfoPageSpu() {
				api.shopInfoPageWithSpu(Object.assign({}, this.page, util.filterForm({
					shopType: 5
				}))).then(res => {
					var data = res.data.records
					this.shopInfo = data
				});
			},
			//获取定位
			getLocation() {
				uni.navigateTo({
					url: "/pages/map/index"
				})
			},
			//打开设置页
			openSet() {
				var _this = this;
				uni.openSetting({
					success: function(res) {
						_this.getPosition();
					}
				});
				this.modalName = null;
			},
			hideModal() {
				this.modalName = null;
			},
			//获取位置
			getPosition() {
				var _this = this;
				// #ifdef APP-PLUS
				uni.getLocation({
					geocode: true,
					type: "gcj02",
					success: function(res) {
						_this.location = res.address.street
					}
				})
				// #endif
				// #ifdef MP-WEIXIN
				uni.getLocation({
					type: "gcj02",
					success: function(res) {
						qqmapsdk.reverseGeocoder({
							location: {
								latitude: res.latitude,
								longitude: res.longitude
							},
							success: function(result) {
								_this.location = result.result.address_component.street_number
							}
						})
					}
				})
				// #endif
			},
			loadData() {
				this.swiperGet();
				this.noticeGet();
				this.shopInfoPage();
				this.shopInfoPageSpu();
				this.goodsNew();
				this.goodsHot();
				this.goodsPage();
				this.goodsCategoryPage({
					searchCount: false,
					current: 1,
					size: 100,
					ascs: 'sort',
					parentId: '0'
				});
			},

			jumpPage(url) {
				if (url == '/pages/goods/goods-category/index') {
					uni.switchTab({
						url: url
					});
				} else {
					uni.navigateTo({
						url: url
					});
				}
			},

			tabSelect(e) {
				let index = e.currentTarget.dataset.index
				let TabCur = this.TabCur
				let firstCategory = this.firstCategoryData[index]
				this.TabCur = index;
				this.scrollLeft = (index - 1) * 60
				if (index != 0 && TabCur != index) {
					api.goodsCategoryPage({
						searchCount: false,
						current: 1,
						size: 9,
						ascs: 'sort',
						parentId: firstCategory.id
					}).then(res => {
						this.secondCategoryData = res.data.records;
					});
					this.loadmore2 = true;
					this.goodsList2 = [];
					this.page2.current = 1;
					this.goodsPageByCateGory();
				}
			},
			setGoodsCategoryParam() {
				/* 把参数信息异步存储到缓存当中 */
				uni.setStorage({
					key: 'param-goods-category-index',
					data: this.TabCur - 1
				});
			},
			//获取轮播图
			swiperGet() {
				api.noticeGet({
					type: '1',
					enable: '1'
				}).then(res => {
					let notice = res.data;
					if (notice) {
						this.swiperData = notice.listNoticeItem;
					}
				});
			},

			cardSwiper(e) {
				this.cardCur = e.detail.current
			},
			//获取广告通知
			noticeGet() {
				api.noticeGet({
					type: '2',
					enable: '1'
				}).then(res => {
					let notice = res.data;
					if (notice) {
						this.noticeData = notice.listNoticeItem;
					}
				});
			},
			//商品分类
			goodsCategoryPage(data) {
				api.goodsCategoryPage(data).then(res => {
					this.firstCategoryData = [...this.firstCategoryData, ...res.data.records];
				});
			},
			//店铺列表
			shopInfoPage() {
				api.shopInfoPage({
					searchCount: false,
					current: 1,
					size: 5,
					descs: ''
				}).then(res => {
					this.shopInfoData = res.data.records;
				});
			},

			//新品首发
			goodsNew() {
				api.goodsPage({
					searchCount: false,
					current: 1,
					size: 5,
					descs: 'create_time'
				}).then(res => {
					this.goodsListNew = res.data.records;
				});
			},

			//热销单品
			goodsHot() {
				api.goodsPage({
					searchCount: false,
					current: 1,
					size: 5,
					descs: 'sale_num'
				}).then(res => {
					this.goodsListHot = res.data.records;
				});
			},

			goodsPage() {
				api.goodsPage(this.page).then(res => {
					let goodsList = res.data.records
					// console.log(res.data.records)
					this.goodsList = [...this.goodsList, ...goodsList];
					if (goodsList.length < this.page.size) {
						this.loadmore = false;
					}
				});
			},

			goodsPageByCateGory() {
				api.goodsPage(Object.assign(this.page2, {
					categoryFirst: this.firstCategoryData[this.TabCur].id
				})).then(res => {
					let goodsList2 = res.data.records
					this.goodsList2 = [...this.goodsList2, ...goodsList2];
					if (goodsList2.length < this.page2.size) {
						this.loadmore2 = false;
					}
				});
			},
			refresh() {
				this.loadmore = true;
				this.page.current = 1;
				this.goodsList = [];
				this.goodsListNew = [];
				this.goodsListHot = [];
				this.loadData();
			},
			// jumpPage(page) {
			// 	if (page) {
			// 		uni.navigateTo({
			// 			url: page
			// 		});
			// 	}
			// }
		}
	};
</script>
<style lang="scss" scoped>
	@import "./index.css";

	.location {
		position: fixed;
		/* top: 140rpx; */
		top: 0;
		width: 100%;
		display: flex;
		align-items: center;
		z-index: 1024;
		height: 40rpx;
		padding: 0 30rpx;
	}

	.shop-card {
		width: 94%;
		height: 460rpx;
		margin: 20rpx auto;

		/* box-shadow:0px 5px 10px #e5e5e5; */
		.head-image {
			width: 80rpx;
			height: 80rpx;
		}

		.enter-store {
			font-size: 24rpx;
			padding: 10rpx 20rpx 10rpx 20rpx;
			line-height: 50rpx;
		}

		.img-box {
			height: 200rpx;
		}

		.goods-item {
			padding: 10rpx;
			width: 220rpx;
			height: 220rpx;
		}

		.goods-name {
			height: 65rpx;
		}

		.no-goods {
			margin: 30rpx auto;
		}

		.no-item {
			width: 400rpx;
			height: 200rpx;
		}
	}
</style>
