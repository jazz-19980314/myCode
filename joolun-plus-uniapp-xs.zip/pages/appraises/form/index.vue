<!--
  - Copyright (C) 2018-2019
  - All rights reserved, Designed By www.joolun.com
  - 注意：
  - 本软件为www.joolun.com开发研制，未经购买不得使用
  - 购买后可获得全部源代码（禁止转卖、分享、上传到码云、github等开源平台）
  - 一经发现盗用、分享等行为，将追究法律责任，后果自负
-->
<template>
	<view>
		<cu-custom :bgColor="'bg-'+theme.backgroundColor" :isBack="true">
			<block slot="backText">返回</block>
			<block slot="content">商品评价</block>
		</cu-custom>
		<view class="bg-white" style="margin-bottom: 100rpx;">
			<view class="cu-list menu-avatar" v-for="(item, index) in orderInfo.listOrderItem" :key="index">
				<view class="flex padding bg-white align-center solid-bottom">
					<view class="cu-avatar xl" :style="'background-image:url(' + (item.picUrl ? item.picUrl : '/static/public/img/no_pic.png') + ');'"></view>
					<view class="margin-left-sm goods-detail">
						<view class="text-black text-df overflow-2">{{item.spuName}}</view>
						<view class="text-gray text-sm text-cut margin-top-xs" v-if="item.specInfo">{{item.specInfo}}</view>
					</view>
				</view>
				<view class="cu-form-group">
					<textarea maxlength="200" @input="textareaInput" :data-index="index" placeholder="说说你的使用心得吧"></textarea>
				</view>
				<view class="cu-bar bg-white">
					<view class="action">
						<text class="cuIcon-titles" :class="'text-'+theme.themeColor"></text>订单打分</view>
				</view>
				<view class="cu-list menu">
					<view class="cu-item">
						<view class="content flex">
							<text class="text-gray text-sm">商品评分：</text>
							<base-rade :value="item.goodsScore" @onChange="radeOnChange($event, index, 'goods')"></base-rade>
						</view>
					</view>
					<view class="cu-item">
						<view class="content flex">
							<text class="text-gray text-sm">服务评分：</text>
							<base-rade :value="item.serviceScore" @onChange="radeOnChange($event, index, 'service')"></base-rade>
						</view>
					</view>
					<view class="cu-item">
						<view class="content flex">
							<text class="text-gray text-sm">物流评分：</text>
							<base-rade :value="item.logisticsScore" @onChange="radeOnChange($event, index, 'logistics')"></base-rade>
						</view>
					</view>
				</view>
			</view>
		</view>
		<view class="cu-bar bg-white justify-center foot">
			<button class="cu-btn round shadow-blur lg" :class="'bg-'+theme.themeColor" style="width: 90%;" @tap="subAppraises">确认并提交</button>
		</view>
	</view>
</template>

<script>
	/**
	 * Copyright (C) 2018-2019
	 * All rights reserved, Designed By www.joolun.com
	 * 注意：
	 * 本软件为www.joolun.com开发研制，未经购买不得使用
	 * 购买后可获得全部源代码（禁止转卖、分享、上传到码云、github等开源平台）
	 * 一经发现盗用、分享等行为，将追究法律责任，后果自负
	 */
	const app = getApp();
	import api from 'utils/api'
	import baseRade from "components/base-rade/index";

	export default {
		data() {
			return {
				CustomBar: this.CustomBar,
				theme: app.globalData.theme, //全局颜色变量
				orderInfo: {
					listOrderItem: []
				},
				id: null,
				goodsAppraises: []
			};
		},

		components: {
			baseRade
		},
		props: {},

		onShow() {},

		onLoad(options) {
			app.initPage().then(res => {
				this.orderGet(options.orderId);
			});
		},

		methods: {
			orderGet(id) {
				let that = this;
				api.orderGet(id).then(res => {
					let orderInfo = res.data;
					if (!orderInfo) {
						uni.showToast({
							title: '无效订单',
							icon: 'none',
							duration: 5000
						});
						return;
					}

					let goodsAppraises = [];
					orderInfo.listOrderItem.forEach(function(orderItem, index) {
						orderItem.goodsScore = orderItem.goodsScore ? orderItem.goodsScore : 0;
						orderItem.serviceScore = orderItem.serviceScore ? orderItem.serviceScore : 0;
						orderItem.logisticsScore = orderItem.logisticsScore ? orderItem.logisticsScore : 0;
						let appraisesObj = {};
						appraisesObj.orderId = orderInfo.id;
						appraisesObj.orderItemId = orderItem.id;
						appraisesObj.spuId = orderItem.spuId;
						appraisesObj.skuId = orderItem.skuId;
						appraisesObj.specInfo = orderItem.specInfo;
						appraisesObj.goodsScore = orderItem.goodsScore;
						appraisesObj.serviceScore = orderItem.serviceScore;
						appraisesObj.logisticsScore = orderItem.logisticsScore;
						goodsAppraises.push(appraisesObj);
					});
					this.orderInfo = orderInfo;
					this.goodsAppraises = goodsAppraises;
				});
			},

			radeOnChange(value, index, type) {
				let goodsAppraises = this.goodsAppraises;
				if (type == 'goods') {
					goodsAppraises[index].goodsScore = value;
					this.orderInfo.listOrderItem[index].goodsScore = value;
				}else if (type == 'service') {
					goodsAppraises[index].serviceScore = value;
					this.orderInfo.listOrderItem[index].serviceScore = value;
				}else if (type == 'logistics') {
					goodsAppraises[index].logisticsScore = value;
					this.orderInfo.listOrderItem[index].logisticsScore = value;
				}
				this.goodsAppraises = goodsAppraises;
			},

			textareaInput(e) {
				let dataset = e.currentTarget.dataset;
				let index = dataset.index;
				let goodsAppraises = this.goodsAppraises;
				goodsAppraises[index].content = e.detail.value;
				this.goodsAppraises = goodsAppraises;
			},

			subAppraises() {
				let that = this;
				let b = true;
				let goodsAppraises = that.goodsAppraises;
				goodsAppraises.forEach(function(obj, index) {
					if (!obj.goodsScore || !obj.serviceScore || !obj.logisticsScore) {
						uni.showToast({
							title: '请给商品打分',
							icon: 'none',
							duration: 2000
						});
						b = false;
						return;
					}
				});

				if (b) {
					uni.showModal({
						content: '确认提交评价吗？',
						cancelText: '我再想想',
						confirmColor: '#ff0000',
						success(res) {
							if (res.confirm) {
								api.goodsAppraisesAdd(goodsAppraises).then(res => {
									uni.navigateBack({delta: 1});
								});
							}
						}

					});
				}
			}

		}
	};
</script>
<style>
	.goods-detail{
		width: 74%;
	}
</style>