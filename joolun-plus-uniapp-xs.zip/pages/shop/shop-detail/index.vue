<!--
  - Copyright (C) 2018-2019
  - All rights reserved, Designed By www.joolun.com
  - 注意：
  - 本软件为www.joolun.com开发研制，未经购买不得使用
  - 购买后可获得全部源代码（禁止转卖、分享、上传到码云、github等开源平台）
  - 一经发现盗用、分享等行为，将追究法律责任，后果自负
-->
<template>
	<view>
		<cu-custom :bgColor="'bg-'+theme.backgroundColor" :isBack="true">
			<block slot="backText">返回</block>
			<block slot="content">{{shopInfo.name}}</block>
		</cu-custom>
		<view :class="'cu-modal ' + (shopInfo.enable=='0'?'show':'')">
			<view class="cu-dialog">
				<view class="cu-bar bg-white justify-end">
					<view class="content">提示</view>
				</view>
				<view class="padding-xl">抱歉，该店铺不存在或已下架</view>
			</view>
		</view>
		<view class="cu-bar search top-home fixed shop-card" :class="'bg-'+theme.backgroundColor">
			<view class="search-form round">
				<text class="cuIcon-search"></text>
				<navigator class="response" hover-class="none" :url="'/pages/base/search/index?shopId='+id">
					<input type="text" placeholder="请输入关键字"></input>
				</navigator>
			</view>
			<view class="collection round margin-right-sm text-sm text-center" @tap="userCollect">
				<text :class="'cuIcon-' + (shopInfo.collectId ? 'likefill text-white' : 'like text-white')"></text>{{shopInfo.collectId ? '已收藏' : '收藏'}}
			</view>
		</view>
		<!--店铺信息-->
		<view class="fixed">
			<view class="cu-card no-card article shop-information">
				<view class="cu-item">
					<view class="content shop-detail" :class="'bg-'+theme.backgroundColor">
						<image :src="shopInfo.imgUrl" mode="aspectFill" class="margin-top-xs"></image>
						<view class="shop-text ">
							<view class="cuIcon-locationfill overflow-1 location margin-top-xs"><text class="address text-sm margin-left-xs">{{shopInfo.address}}</text></view>
							<view class="flex collect overflow-1 margin-top-xs" :hover-stop-propagation="true" @click="callPhone(shopInfo.phone)">
								<text class="cuIcon-mobilefill"></text><text class="phone text-sm margin-left-xs">{{shopInfo.phone}}</text></view>
							<view class="flex justify-between margin-top-xs" v-if="shopInfo">
								<text class="margin-left-xs text-sm">{{shopInfo.collectCount}} 人已收藏</text>
								<view class="flex shop-share text-lg">
									<text @tap="shareShowFun" class="cuIcon-share"></text>
								</view>
							</view>
						</view>
					</view>
				</view>
			</view>

			<!-- 首页 -->
			<view v-if="PageCur=='1'" class="margin-bottom-bar padding-bottom-xs">
				<!-- 领取优惠券/秒杀/拼团/砍价 -->
				<view class="left-item bg-white padding-xs padding-top-sm">
					<view class="flex align-center">
						<navigator class="radius econds-kill" hover-class="none" :url="'/pages/seckill/seckill-list/index?shopId='+id">
							<image src="https://joolun-base-test.oss-cn-zhangjiakou.aliyuncs.com/1/material/ed8ba4eb-7b32-4a5b-a635-c977d6127ffc.png"></image>
						</navigator>
						<navigator class="radius margin-left-xs spellGroup" hover-class="none" :url="'/pages/groupon/groupon-list/index?shopId='+id">
							<image src="https://joolun-base-test.oss-cn-zhangjiakou.aliyuncs.com/1/material/1c6183f4-16de-4047-bd99-f7087949775a.png"></image>
						</navigator>
					</view>
					<view class="flex align-center margin-top-xs">
						<navigator class="radius bargain" hover-class="none" :url="'/pages/bargain/bargain-list/index?shopId='+id">
							<image src="https://joolun-base-test.oss-cn-zhangjiakou.aliyuncs.com/1/material/edb0009e-2f8a-4fcc-82d1-05060913103d.png"></image>
						</navigator>
						<navigator class="radius margin-left-xs coupons" @tap="showModalCoupon">
							<image src="https://joolun-base-test.oss-cn-zhangjiakou.aliyuncs.com/1/material/9556be37-c6a7-4cb6-ad49-bb25f5635241.png"></image>
						</navigator>
					</view>
				</view>

				<view class="cu-bar bg-white justify-center">
					<view class="action text-bold" :class="'text-'+theme.themeColor">
						<text class="cuIcon-move"></text> <text class="cuIcon-like"></text>热卖中<text class="cuIcon-move"></text>
					</view>
				</view>
				<goods-card :goodsList="goodsListHot"></goods-card>

				<coupon-receive :couponInfoList="couponInfoList" :modalCoupon="modalCoupon" @changeModalCoupon="modalCoupon=$event"
				 @receiveCouponChange="receiveCouponChange($event)"></coupon-receive>
			</view>

			<!-- 全部商品 -->
			<view v-if="PageCur=='2'" class="margin-bottom-bar padding-bottom-xs">
				<view class="cu-bar justify-center bg-white shop-card">
					<view class="grid response text-center align-start">
						<view class="flex-sub padding-sm margin-xs radius">
							<view class="grid text-center" @tap="sortHandle" data-type="price">价格<view class="margin-left-xs">
									<view :class="'cuIcon-triangleupfill ' + (price=='asc' ? 'text-'+theme.themeColor : '')" data-type="price"></view>
									<view class="basis-df"></view>
									<view :class="'cuIcon-triangledownfill ' + (price=='desc' ? 'text-'+theme.themeColor : '')" data-type="price"></view>
								</view>
							</view>
						</view>
						<view class="flex-sub padding-sm margin-xs radius">
							<view class="grid text-center" @tap="sortHandle" data-type="sales">销量<view class="margin-left-xs">
									<view :class="'cuIcon-triangleupfill ' + (sales=='asc' ? 'text-'+theme.themeColor : '')" data-type="sales"></view>
									<view class="basis-df"></view>
									<view :class="'cuIcon-triangledownfill ' + (sales=='desc' ? 'text-'+theme.themeColor : '')" data-type="sales"></view>
								</view>
							</view>
						</view>
						<view class="flex-sub padding-sm margin-xs radius">
							<view :class="createTime=='desc' ? 'text-bold text-'+theme.themeColor : ''" @tap="sortHandle" data-type="createTime">新上架</view>
						</view>
					</view>
					<view class="action">
						<view class="text-xxl">
							<text :class="'cuIcon-' + (viewType ? 'list' : 'cascades')" @tap="viewTypeEdit"></text>
						</view>
					</view>
				</view>
				<view v-if="viewType">
					<goods-card :goodsList="goodsList"></goods-card>
				</view>
				<view v-if="!viewType">
					<goods-row :goodsList="goodsList"></goods-row>
				</view>
				<view :class="'cu-load bg-gray ' + (loadmore?'loading':'over')"></view>
			</view>
		</view>

		<!-- 分类 -->
		<view v-if="PageCur=='3'" class="margin-bottom-bar padding-sm">
			<view class="cu-card bg-white padding margin-bottom-sm radius" v-for="(item,index) in goodsCategoryShop">
				<navigator hover-class="none" :url="'/pages/goods/goods-list/index?shopId='+id+'&categoryShopFirst='+item.id" class="flex justify-between">
					<view><text class="cuIcon-titles margin-left-xs" :class="'text-'+theme.themeColor"></text>
						<text class="text-bold text-black">{{item.name}}</text></view>
					<view class="cuIcon-right"></view>
				</navigator>
				<view class="content margin-top-xs">
					<view class="grid margin-right-xs">
						<navigator hover-class="none" :url="'/pages/goods/goods-list/index?shopId='+id+'&categoryShopSecond='+item2.id"
						 class="cu-item bg-gray margin-left-sm margin-top-xs padding-sm radius text-sm" style="width: 46%;" v-for="(item2,index) in item.children">{{item2.name}}</navigator>
					</view>
				</view>
			</view>
		</view>

		<view class="cu-bar tabbar bg-white shadow foot">
			<view class="action" @click="NavChange" data-cur="1" :class="PageCur=='1'?'text-'+theme.themeColor:'text-gray'">
				<view class='cuIcon-cu-image'>
					<text class="cuIcon-shop lg"></text>
				</view>
				<view>首页</view>
			</view>
			<view class="action" @click="NavChange" data-cur="2" :class="PageCur=='2'?'text-'+theme.themeColor:'text-gray'">
				<view class='cuIcon-cu-image'>
					<text class="cuIcon-goods lg"></text>
				</view>
				<view>全部商品</view>
			</view>
			<view class="action" @click="NavChange" data-cur="3" :class="PageCur=='3'?'text-'+theme.themeColor:'text-gray'">
				<view class='cuIcon-cu-image'>
					<text class="cuIcon-sort lg"></text>
				</view>
				<view>分类</view>
			</view>
			<view class="action" @click="NavChange" data-cur="4">
				<view class='cuIcon-cu-image'>
					<text class="cuIcon-service lg"></text>
				</view>
				<view :class="PageCur=='4'?'text-'+theme.themeColor:'text-gray'">客服</view>
			</view>
		</view>

		<poster id="poster" ref='posterRef' :hide-loading="false" :preload="false" :config="posterConfig" @success="onPosterSuccess"
		 @fail="onPosterFail"></poster>
		<view :class="'cu-modal bottom-modal ' + shareShow">
			<view class="cu-dialog">
				<view class="cu-bar bg-white">
					<view class="action text-green"></view>
					<view class="action text-red" @tap="shareHide">取消</view>
				</view>
				<view class="padding flex flex-direction">
					<share-friends  :shareObj="{
								title: '发现一个好店铺，推荐给你呀',
								desc: shopInfo.name,
								imgUrl: shopInfo.imgUrl,
						}"></share-friends>
					<!-- #ifndef APP-PLUS -->
					<button class="cu-btn margin-tb-sm lg round shadow-blur" :class="'bg-'+theme.themeColor" @tap="onCreatePoster">生成海报</button>
					<!-- #endif -->
				</view>
			</view>
		</view>

		<view :class="'cu-modal ' + (posterShow ? 'show' : '')">
			<view class="cu-dialog show-bg">
				<view class="bg-white" style="height: calc(100vh - 200rpx)">
					<image :src="posterUrl" class="image-box"></image>
				</view>
				<view class="cu-bar bg-white solid-top show-btn">
					<view class="action margin-0 flex-sub" @tap="hidePosterShow">取消</view>
					<!-- #ifdef MP -->
					<view class="action margin-0 flex-sub solid-left text-red text-bold" @tap="savePoster">保存到相册</view>
					<!-- #endif -->
					<!-- #ifdef H5 -->
					<view class="action margin-0 flex-sub solid-left text-red text-bold" @tap="hidePosterShow">长按图片可保存或分享</view>
					<!-- #endif -->

				</view>
			</view>
		</view>
		<!-- #ifdef H5 -->
		<!-- 二维码组件，不显示，只用来生成二维码调用 说明文档 https://github.com/q310550690/uni-app-qrcode -->
		<!-- 该组件生成二维码时需要canvas元素装载,固直接引用组件没有使用js，效果一样 -->
		<tki-qrcode ref="qrCodeRef" :size="200" :val="curLocalUrl" :show="false" @result="startCreatePoster" icon="/static/public/logo.png"></tki-qrcode>
		<!-- #endif -->
	</view>
</template>

<script>
	/**
	 * Copyright (C) 2018-2019
	 * All rights reserved, Designed By www.joolun.com
	 * 注意：
	 * 本软件为www.joolun.com开发研制，未经购买不得使用
	 * 购买后可获得全部源代码（禁止转卖、分享、上传到码云、github等开源平台）
	 * 一经发现盗用、分享等行为，将追究法律责任，后果自负
	 */
	const util = require("utils/util.js");
	const app = getApp();
	import api from 'utils/api'
	import goodsCard from "components/goods-card/index";
	import goodsRow from "components/goods-row/index";
	import couponReceive from "components/coupon-receive/index";

	const {
		base64src
	} = require("utils/base64src.js");
	import poster from "components/wxa-plugin-canvas/poster/index";
	import tkiQrcode from "components/tki-qrcode/tki-qrcode.vue"
	import shareFriends from "components/share-friends/index.vue"

	export default {
		components: {
			goodsCard,
			goodsRow,
			couponReceive,
			poster,
			tkiQrcode,
			shareFriends,
		},
		data() {
			return {
				CustomBar: this.CustomBar,
				theme: app.globalData.theme, //全局颜色变量
				PageCur: '1',
				id: '',
				shopInfo: {
					collectCount: 0
				},
				page: {
					searchCount: false,
					current: 1,
					size: 10,
					ascs: '',
					//升序字段
					descs: ''
				},
				parameter: {},
				loadmore: true,
				goodsList: [],
				viewType: true,
				price: '',
				sales: '',
				createTime: '',
				title: '',
				couponInfoList: [],
				modalCoupon: false,
				posterUrl: "",
				posterShow: false,
				posterConfig: "",
				shareShow: '',
				curLocalUrl: '',
				goodsCategoryShop: [],
				goodsListHot: []
			};
		},

		props: {},

		onLoad(options) {
			// console.log(options)
			let id = options.id
			this.id = id
			this.parameter.shopId = id
			if(options.scene){
				this.parameter.shopId = options.scene;
				uni.setStorageSync('shop_id', decodeURIComponent(options.scene));
				this.id = options.scene;
			}
			app.initPage().then(res => {
				this.shopInfoGet();
				this.couponInfoPage(id);
				this.goodsHot();
			});
		},

		onReachBottom() {
			if (this.PageCur == '2' && this.loadmore) {
				this.page.current = this.page.current + 1;
				this.goodsPage();
			}
		},

		methods: {
			shopInfoGet() {
				api.shopInfoGet(this.parameter.shopId).then(res => {
					let shopInfo = res.data;
					this.shopInfo = shopInfo
				});
			},
			NavChange: function(e) {
				let cur = e.currentTarget.dataset.cur
				if (cur == '4') {
					uni.navigateTo({
						url: '/pages/customer-service/customer-service-list/index?shopId=' + this.id
					});
				} else {
					this.PageCur = cur
				}
				if (cur == '2' && this.goodsList.length <= 0) {
					this.goodsPage();
				}
				if (cur == '3' && this.goodsCategoryShop.length <= 0) {
					this.goodsCategoryShopTree();
				}
			},
			//热销单品
			goodsHot() {
				api.goodsPage({
					searchCount: false,
					current: 1,
					size: 6,
					descs: 'sale_num',
					shopId: this.id
				}).then(res => {
					this.goodsListHot = res.data.records;
				});
			},
			goodsPage() {
				api.goodsPage(Object.assign({}, this.page, util.filterForm(this.parameter))).then(res => {
					let goodsList = res.data.records;
					this.goodsList = [...this.goodsList, ...goodsList];
					if (goodsList.length < this.page.size) {
						this.loadmore = false;
					}
				});
			},
			//商品分类
			goodsCategoryShopTree() {
				api.goodsCategoryShopTree({
					shopId: this.id
				}).then(res => {
					this.goodsCategoryShop = res.data
				});
			},
			//查询店铺可用电子券
			couponInfoPage(shopId) {
				api.couponInfoPage({
					current: 1,
					size: 50,
					descs: 'create_time',
					shopId: shopId
				}).then(res => {
					this.couponInfoList = res.data.records;
				});
			},

			showModalCoupon() {
				this.modalCoupon = true;
			},

			hideModalCoupon() {
				this.modalCoupon = false;
			},

			viewTypeEdit() {
				this.viewType = !this.viewType;
			},

			sortHandle(e) {
				let type = e.target.dataset.type;

				switch (type) {
					case 'price':
						if (this.price == '') {
							this.price = 'asc';
							this.page.descs = '';
							this.page.ascs = 'price_down';
						} else if (this.price == 'asc') {

							this.price = 'desc';
							this.page.descs = 'price_down';
							this.page.ascs = '';
						} else if (this.price == 'desc') {
							this.price = '';
							this.page.descs = '';
							this.page.ascs = '';
						}
						this.sales = '';
						this.createTime = '';
						break;

					case 'sales':
						if (this.sales == '') {
							this.sales = 'desc';
							this.page.descs = 'sale_num';
							this.page.ascs = '';
						} else if (this.sales == 'desc') {
							this.sales = 'asc';
							this.page.descs = '';
							this.page.ascs = 'sale_num';

						} else if (this.sales == 'asc') {
							this.sales = '';
							this.page.descs = '';
							this.page.ascs = '';
						}
						this.price = '';
						this.createTime = '';
						break;

					case 'createTime':
						if (this.createTime == '') {
							this.createTime = 'desc';
							this.page.descs = 'create_time';
							this.page.ascs = '';
						} else if (this.createTime == 'desc') {
							this.createTime = '';
							this.page.descs = '';
							this.page.ascs = '';
						}
						this.price = '';
						this.sales = '';
						break;
				}

				this.relod();
			},

			receiveCouponChange(obj) { //更新单条数据
				this.couponInfoList[obj.index] = obj.item;
				this.couponInfoList.splice(); //确保页面刷新成功
			},

			relod() {
				this.loadmore = true;
				this.goodsList = [];
				this.page.current = 1;
				this.goodsPage();
			},

			callPhone(phone) {
				uni.makePhoneCall({
					phoneNumber: phone
				});
			},
			//收藏
			userCollect() {
				let shopInfo = this.shopInfo;
				let collectId = shopInfo.collectId;

				if (collectId) {
					api.userCollectDel(collectId).then(res => {
						uni.showToast({
							title: '已取消收藏',
							icon: 'success',
							duration: 2000
						});
						shopInfo.collectId = null;
						shopInfo.collectCount = shopInfo.collectCount - 1
						this.shopInfo = shopInfo;
					});
				} else {
					api.userCollectAdd({
						type: '2',
						relationIds: [shopInfo.id]
					}).then(res => {
						uni.showToast({
							title: '收藏成功',
							icon: 'success',
							duration: 2000
						});
						shopInfo.collectId = res.data[0].id;
						shopInfo.collectCount = shopInfo.collectCount + 1
						this.shopInfo = shopInfo;
					});
				}
			},
			shareHide() {
				this.shareShow = '';
			},
			shareShowFun() {
				// #ifdef H5
				this.curLocalUrl = window.location.href;
				// #endif
				// #ifdef APP-PLUS
				this.curLocalUrl = util.setAppPlusShareUrl();
				// #endif
				this.shareShow = 'show';
			},

			onPosterSuccess(e) {
				this.posterUrl = e;
				this.posterShow = true;
			},
			onPosterFail(err) {
				console.error(err);
			},
			hidePosterShow() {
				this.posterShow = false;
				this.shareShow = '';
			},
			/**
			 * 异步生成海报
			 */
			onCreatePoster() {
				// #ifdef MP
				api.qrCodeUnlimited({
					theme: app.globalData.theme, //全局颜色变量
					page: 'pages/shop/shop-detail/index',
					scene: this.shopInfo.id
				}).then(res => {
					base64src(res.data, res => {
						this.startCreatePoster(res);
					});
				});
				// #endif
				// #ifdef H5
				uni.showLoading({
					title: '海报生成中',
					mask: true
				});
				this.$refs.qrCodeRef._makeCode(); // H5需要先生成二维码后 才能生成海报
				// #endif
			},
			startCreatePoster(res) { // 开始 生成海报
				let desc = '长按识别小程序码';
				let shareImg = this.shopInfo.imgUrl;
				// #ifdef H5
				desc = '长按识别二维码';
				// h5的海报分享的图片有的有跨域问题，所以统一转成base64的
				// 之所以不在组件里面转换是因为无法区分哪张image图片需要处理，一般处理主图
				shareImg = util.imgUrlToBase64(shareImg);
				// #endif
				let qrCode = res; //海报配置请参考 https://github.com/jasondu/wxa-plugin-canvas
				let posterConfig = {
					width: 750,
					height: 1280,
					backgroundColor: '#fff',
					debug: false,
					blocks: [{
						width: 690,
						height: 808,
						x: 30,
						y: 183,
						borderWidth: 2,
						borderColor: '#f0c2a0',
						borderRadius: 20
					}, {
						width: 634,
						height: 74,
						x: 59,
						y: 770,
						backgroundColor: '#fff',
						opacity: 0.5,
						zIndex: 100
					}],
					texts: [{
						x: 40,
						y: 113,
						baseLine: 'top',
						text: '发现一个好店铺，推荐给你呀',
						fontSize: 38,
						color: '#080808'
					}, {
						x: 92,
						y: 810,
						fontSize: 38,
						baseLine: 'middle',
						text: this.shopInfo.name,
						width: 570,
						lineNum: 1,
						color: '#080808',
						zIndex: 200
					}, {
						x: 82,
						y: 900,
						fontSize: 28,
						baseLine: 'middle',
						text: this.shopInfo.address,
						width: 570,
						lineNum: 1,
						color: '#666666',
						zIndex: 200
					}, {
						x: 82,
						y: 950,
						fontSize: 28,
						baseLine: 'middle',
						text: this.shopInfo.phone,
						width: 570,
						lineNum: 1,
						color: '#666666',
						zIndex: 200
					}, {
						x: 540,
						y: 950,
						fontSize: 28,
						baseLine: 'middle',
						text: this.shopInfo.collectCount + '人已收藏',
						width: 570,
						lineNum: 1,
						color: '#666666',
						zIndex: 200
					}, {
						x: 360,
						y: 1065,
						baseLine: 'top',
						text: desc,
						fontSize: 38,
						color: '#080808'
					}, {
						x: 360,
						y: 1123,
						baseLine: 'top',
						text: '超值好货快来购买',
						fontSize: 28,
						color: '#929292'
					}],
					images: [{
						width: 634,
						height: 634,
						x: 59,
						y: 210,
						url: shareImg
					}, {
						width: 220,
						height: 220,
						x: 92,
						y: 1020,
						url: qrCode
					}]
				};
				let userInfo = uni.getStorageSync('user_info');
				if (userInfo && userInfo.headimgUrl) {
					//如果有头像则显示
					posterConfig.images.push({
						width: 62,
						height: 62,
						x: 40,
						y: 30,
						borderRadius: 62,
						url: userInfo.headimgUrl
					});
					posterConfig.texts.push({
						x: 123,
						y: 61,
						baseLine: 'middle',
						text: userInfo.nickName,
						fontSize: 32,
						color: '#8d8d8d'
					});
				}
				this.posterConfig = posterConfig;
				this.posterShow = false;
				this.$refs.posterRef.onCreate(false, this.posterConfig); // 入参：true为抹掉重新生成
			},
			//点击保存到相册
			savePoster: function() {
				var that = this;
				uni.saveImageToPhotosAlbum({
					filePath: that.posterUrl,
					success(res) {
						that.posterShow = false;
						that.shareShow = '';
						uni.showModal({
							content: '图片已保存到相册，赶紧晒一下吧~',
							showCancel: false,
							confirmText: '好的',
							confirmColor: '#333',
							success: function(res) {
								if (res.confirm) {
									/* 该隐藏的隐藏 */
									that.shareShow = '';
								}
							},
							fail: function(res) {
								console.log(res);
							}
						});
					}
				});
			}

		}

	};
</script>
<style>
	.shop-card {
		box-shadow: unset !important;
	}

	.cuIcon-triangledownfill {
		margin-top: -22rpx
	}

	.top-home {
		top: unset !important;
	}

	.shop-information {
		height: 160rpx;
		margin-top: 100rpx;
	}

	.collection {
		width: 120rpx;
		height: 48rpx;
		line-height: 48rpx;
		border: solid 1rpx #FFFFFF;
	}

	.shop-share {
		margin-right: -30rpx;
	}

	.right-item {
		width: 100%;
		margin-left: -10rpx;
	}

	.location {
		width: 480rpx;
	}

	.shop-detail {
		height: 160rpx;
	}

	.shop-detail image {
		width: 120rpx !important;
		height: 120rpx !important;
	}

	.show-bg {
		height: 84%;
		margin-top: 120rpx;
	}

	.image-box {
		height: 90%;
	}

	.show-btn {
		margin-top: -130rpx;
	}

	.econds-kill {
		width: 40%;
		height: 100rpx;
	}

	.econds-kill image {
		width: 100%;
		height: 100rpx;
	}

	.spellGroup {
		width: 700rpx;
		height: 100rpx;
	}

	.spellGroup image {
		width: 100%;
		height: 100rpx;
	}

	.bargain {
		width: 700rpx;
		height: 100rpx;
	}

	.bargain image {
		width: 100%;
		height: 100rpx;
	}

	.coupons {
		width: 40%;
		height: 100rpx;
	}

	.coupons image {
		width: 100%;
		height: 100rpx;
	}
</style>
