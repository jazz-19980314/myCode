<!--
  - Copyright (C) 2018-2019
  - All rights reserved, Designed By www.joolun.com
  - 注意：
  - 本软件为www.joolun.com开发研制，未经购买不得使用
  - 购买后可获得全部源代码（禁止转卖、分享、上传到码云、github等开源平台）
  - 一经发现盗用、分享等行为，将追究法律责任，后果自负
-->
<template>
	<view>
		<cu-custom :bgColor="'bg-'+theme.backgroundColor" :isBack="true">
			<block slot="backText">返回</block>
			<block slot="content">砍价详情</block>
		</cu-custom>
		<view class="cu-card article">
			<view class="cu-item" v-if="bargainInfo.bargainUser&&bargainInfo.bargainUser.status == '0'">
				<view class="content margin-top">倒计时：<count-down class="text-red" :outTime="dateUtil.getOutTime(bargainInfo.bargainUser.validEndTime)"
					 @countDownDone="countDownDone"></count-down>
				</view>
			</view>
			<view class="cu-item">
				<navigator class="padding" hover-class="none" :url="'/pages/shop/shop-detail/index?id=' + bargainInfo.shopInfo.id">
					<view class="cu-avatar sm radius" :style="'background-image:url(' + bargainInfo.shopInfo.imgUrl + ')'"></view>
					<text class="text-black text-bold margin-left-sm">{{bargainInfo.shopInfo.name}}</text>
					<text class="cuIcon-right text-sm"></text>
				</navigator>
				<view class="margin-left-sm">
					<view class="action">
						<text class="cuIcon-titles" :class="'text-'+theme.themeColor"></text>{{bargainInfo.name}}
					</view>
					<view class="flex justify-between margin-xs">
						<text class="text-sm text-gray margin-left-sm" v-if="bargainInfo.launchNum">已有{{bargainInfo.launchNum}}人参与</text>
						<text class="text-blue text-sm margin-right-sm" @tap="ruleShow">砍价规则</text>
					</view>
				</view>
				<view class="content">
					<image :src="bargainInfo.picUrl" mode="aspectFill" class="row-img margin-top-xs"></image>
					<view class="desc">
						<view class="text-black margin-top-sm overflow-2">{{bargainInfo.goodsSpu.name}}</view>
						<view class="text-gray text-sm overflow-1" v-if="bargainInfo.goodsSku.specs.length > 0">{{specInfo}}</view>
						<view class="flex justify-start margin-top-sm align-center">
							<view class="text-price text-bold text-xl text-red">{{bargainInfo.bargainPrice}}</view>
							<view class="text-price text-decorat text-gray margin-left-sm">{{bargainInfo.goodsSku.salesPrice}}</view>
							<view class="cu-tag bg-red radius sm margin-left" v-if="bargainInfo.goodsSpu.freightTemplat.type == '2'">包邮</view>
						</view>

					</view>
				</view>
				<view class="padding-lr text-center margin-top-sm" v-if="bargainInfo">
					<!-- 没参与 -->
					<view v-if="!(bargainInfo.bargainUser && hasBargainUser)">
						<button class="cu-btn bargain-btn round lg shadow-blur" :class="'bg-'+theme.themeColor" v-if="bargainInfo.enable == '1' && bargainInfo.status == '1'"
						 :disabled="disabled" @tap="bargainUserSave"><text class="cuIcon-cardboardforbid">发起砍价</text></button>
						<button class="cu-btn bargain-btn round bg-gray lg shadow-blur" v-if="bargainInfo.status == '0'"><text class="cuIcon-cardboardforbid">活动未开始</text></button>
						<button class="cu-btn bargain-btn round bg-gray lg shadow-blur" v-if="bargainInfo.status == '2'"><text class="cuIcon-close">活动已过期</text></button>
						<view class="text-gray text-sm margin-top" v-if="bargainInfo.validBeginTime">{{bargainInfo.validBeginTime}}至{{bargainInfo.validEndTime}}</view>
					</view>
					<!-- 已经参与 -->
					<view v-if="bargainInfo.bargainUser && hasBargainUser">
						<view class="text-gray text-sm margin-top margin-bottom-sm">{{bargainInfo.bargainUser.validBeginTime}}至{{bargainInfo.bargainUser.validEndTime}}</view>
						<button class="cu-btn bargain-btn round lg shadow-blur" :class="'bg-'+theme.themeColor" v-if="bargainInfo.bargainUser.status == '0'" @tap="shareShowFun"><text class=" cuIcon-friend">邀请好友帮砍</text></button>
						<button class="cu-btn bargain-btn round bg-orange lg shadow-blur" v-if="bargainInfo.bargainUser.status == '1'"><text class=" cuIcon-check">已完成砍价</text></button>
						<button class="cu-btn bargain-btn round bg-gray lg shadow-blur" v-if="bargainInfo.bargainUser.status == '2'"><text class=" cuIcon-close">活动已过期</text></button>

					</view>
				</view>
				<view class="padding" v-if="bargainInfo.bargainUser && hasBargainUser">
					<view>已砍<text class="text-red">{{havCutPrice}}</text>元，还差<text class="text-red">{{numberUtil.numberSubtract(canCutPrice,havCutPrice)}}</text>元</view>
					<view class="cu-progress round margin-top">
						<view class="bg-red"  :class="'bg-'+theme.themeColor" :style="'width: ' + cutPercent">{{cutPercent}}</view>
					</view>
				</view>
				<view v-if="userInfo && bargainInfo.bargainUser && hasBargainUser">
					<view class="padding text-center" v-if="bargainInfo.bargainUser.userId != userInfo.id">
						<button class="cu-btn round bg-orange cuIcon-cardboardforbid lg" :class="'bg-'+theme.themeColor" :disabled="disabled" @tap="bargainCutSave" v-if="bargainInfo.enable == '1' && bargainInfo.bargainUser.status == '0' && !bargainInfo.bargainUser.bargainCut">帮砍一刀</button>
						<button class="cu-btn round bg-gray cuIcon-check lg" v-if="bargainInfo.bargainUser.status == '0' && bargainInfo.bargainUser.bargainCut">已经砍过了</button>
						<navigator class="cu-btn round bg-cyan lg margin-left" hover-class="none" :url="'/pages/bargain/bargain-detail/index?id=' + bargainInfo.id">发起新砍价</navigator>
					</view>
					<view class="padding text-center" v-if="(bargainInfo.bargainUser.status == '1' || bargainInfo.bargainUser.floorBuy == '0') && (bargainInfo.bargainUser.userId == userInfo.id)">
						<button class="cu-btn round bg-green.light lg" @tap="toBuy" v-if="(bargainInfo.bargainUser.status == '1' || bargainInfo.bargainUser.floorBuy == '0') &&  bargainInfo.bargainUser.isBuy == '0'">¥
							{{numberUtil.numberSubtract(bargainInfo.goodsSku.salesPrice,havCutPrice)}} 砍后价购买</button>
						<navigator hover-class="none" :url="'/pages/order/order-detail/index?id=' + bargainInfo.bargainUser.orderId"
						 class="cu-btn round bg-green.light lg" v-if="bargainInfo.bargainUser.isBuy == '1'">已经砍后价购买</navigator>
					</view>
				</view>
			</view>
		</view>

		<view class="cu-card mar-top-30" v-if="bargainCutList.length > 0">
			<view class="cu-item">
				<view class="cu-bar bg-white solid-bottom">
					<view class="action">
						<text class="cuIcon-titles text-xs" :class="'text-'+theme.themeColor"></text>砍价亲友团</view>
				</view>
				<view class="cu-list menu-avatar">
					<view class="cu-item" v-for="(item, index) in bargainCutList" :key="index">
						<view class="cu-avatar round lg" :style="'background-image:url(' + item.headimgUrl + ');'"></view>
						<view class="content">
							<view class="text-grey">{{item.nickName}}</view>
						</view>
						<view class="action margin-right text-red">
							<text class="text-price">{{item.cutPrice}}</text>
						</view>
					</view>
					<view class="cu-load bg-white" v-if="loadmore" @tap="loadMore">加载更多</view>
				</view>
			</view>
		</view>

		<view class="cu-card mar-top-30">
			<view class="cu-item">
				<view class="cu-bar bg-white">
					<view class="content">商品信息</view>
				</view>
				<view class="bg-white">
					<jyf-parser :html="article_description"></jyf-parser>
				</view>
				<view class="cu-load bg-gray to-down">已经到底啦...</view>
			</view>
		</view>
		<!-- html转wxml -->


		<poster id="poster" ref='posterRef' :hide-loading="false" :preload="false" :config="posterConfig" @success="onPosterSuccess"
		 @fail="onPosterFail"></poster>
		<view :class="'cu-modal bottom-modal ' + shareShow">
			<view class="cu-dialog">
				<view class="cu-bar bg-white">
					<view class="action text-green"></view>
					<view class="action text-red" @tap="shareHide">取消</view>
				</view>
				<view class="padding flex flex-direction">
					<share-friends
						:shareObj="{
								title: bargainInfo.shareTitle,
								desc: bargainInfo.goodsSpu.name,
								imgUrl: bargainInfo.picUrl,
								url: curLocalUrl,
						}"></share-friends>
					<!-- #ifndef APP-PLUS -->
					<button class="cu-btn margin-tb-sm lg round shadow-blur" :class="'bg-'+theme.themeColor" @tap="onCreatePoster">生成海报</button>
					<!-- #endif -->
				</view>
			</view>
		</view>

		<view :class="'cu-modal ' + (posterShow ? 'show' : '')">
			<view class="cu-dialog show-bg">
				<view class="bg-white" style="height: calc(100vh - 200rpx)">
					<image :src="posterUrl" class="image-box"></image>
				</view>
				<view class="cu-bar bg-white solid-top show-btn">
					<view class="action margin-0 flex-sub" @tap="hidePosterShow">取消</view>
					<!-- #ifdef MP -->
					<view class="action margin-0 flex-sub solid-left text-red text-bold" @tap="savePoster">保存到相册</view>
					<!-- #endif -->
					<!-- #ifdef H5 -->
					<view class="action margin-0 flex-sub solid-left text-red text-bold"  @tap="hidePosterShow">长按图片可保存或分享</view>
					<!-- #endif -->
				</view>
			</view>
		</view>

		<view :class="'cu-modal ' + modalRule">
			<view class="cu-dialog">
				<view class="cu-bar bg-white justify-end">
					<view class="content">规则说明</view>
					<view class="action" @tap="ruleHide">
						<text class="cuIcon-close text-red"></text>
					</view>
				</view>
				<view class="padding-xl text-left">
					<text>{{bargainInfo.cutRule}}</text>
				</view>
			</view>
		</view>

		<!-- #ifdef H5 -->
		<!-- 二维码组件，不显示，只用来生成二维码调用 说明文档 https://github.com/q310550690/uni-app-qrcode -->
		<!-- 该组件生成二维码时需要canvas元素装载,固直接引用组件没有使用js，效果一样 -->
		<tki-qrcode ref="qrCodeRef" :size="200" :val="curLocalUrl" :show="false" @result="startCreatePoster"  icon="/static/public/logo.png"></tki-qrcode>
		<!-- #endif -->

	</view>
</template>

<script>
	/**
	 * Copyright (C) 2018-2019
	 * All rights reserved, Designed By www.joolun.com
	 * 注意：
	 * 本软件为www.joolun.com开发研制，未经购买不得使用
	 * 购买后可获得全部源代码（禁止转卖、分享、上传到码云、github等开源平台）
	 * 一经发现盗用、分享等行为，将追究法律责任，后果自负
	 */
	import shopInfo from "components/shop-info/index";
	const util = require("utils/util.js");
	const {
		base64src
	} = require("utils/base64src.js");
	const app = getApp();
	import api from 'utils/api'
	import numberUtil from 'utils/numberUtil.js'
	import dateUtil from 'utils/dateUtil.js'
	import jweixin from 'utils/jweixin'
	import poster from "components/wxa-plugin-canvas/poster/index";
	import countDown from "components/count-down/index";
	import tkiQrcode from "components/tki-qrcode/tki-qrcode.vue"
	import shareFriends from "components/share-friends/index"


	export default {
		data() {
			return {
				CustomBar: this.CustomBar,
				theme: app.globalData.theme, //全局颜色变量
				dateUtil: dateUtil,
				numberUtil: numberUtil,
				bargainInfo: {
					shopInfo:{},
					name:'',
					bargainUser: {
						launchNum: '',
						validBeginTime: '',
						validEndTime: ''
					},
					goodsSpu: {
						freightTemplat: {}
					},
					goodsSku: {
						specs: []
					},
				},
				disabled: false,
				page: {
					searchCount: false,
					current: 1,
					size: 10,
					ascs: '',
					//升序字段
					descs: 'create_time'
				},
				parameter: {},
				loadmore: true,
				bargainCutList: [],
				shareShow: '',
				curLocalUrl: '',
				userInfo: null,
				modalRule: '',
				id: "",
				specInfo: "",
				cutPercent: "",
				canCutPrice: "",
				havCutPrice: "",
				posterUrl: "",
				posterShow: false,
				posterConfig: "",
				article_description: "",
				hasBargainUser: false, //是否存在砍价数据
				bargainUserId: ''
			};
		},

		components: {
			poster,
			countDown,
			tkiQrcode,
			shareFriends,
		},
		props: {},
		onShow() {
			if (this.bargainUserId) {
				api.bargainUserGet(this.bargainUserId).then(res => {
					let bargainUser = res.data;
					this.id = bargainUser.bargainId;
					this.bargainInfoGet({
						bargainId: this.id,
						id: bargainUser.id
					});
				});
			} else {
				this.bargainInfoGet({
					bargainId: this.id
				});
			}
		},
		onLoad(options) {
			this.dateUtil = dateUtil;
			this.numberUtil = numberUtil;
			let id;
			let bargainUserId;

			if (options.scene) {
				//接受二维码中参数
				bargainUserId = decodeURIComponent(options.scene);
			} else if (options.bargainUserId) {
				//分享
				bargainUserId = options.bargainUserId;
			} else {
				id = options.id;
			}
			this.bargainUserId = bargainUserId;
			this.id = id;

			app.initPage().then(res => {
				this.userInfo = uni.getStorageSync('user_info');
			});


		},

		onShareAppMessage: function() {
			let bargainInfo = this.bargainInfo;
			let title = bargainInfo.shareTitle;
			let imageUrl = bargainInfo.picUrl;
			let path = '';

			if (bargainInfo.bargainUser && this.hasBargainUser) {
				path = 'pages/bargain/bargain-detail/index?bargainUserId=' + bargainInfo.bargainUser.id;
			} else {
				path = 'pages/bargain/bargain-detail/index?id=' + bargainInfo.id;
			}

			return {
				title: title,
				path: path,
				imageUrl: imageUrl,
				success: function(res) {
					if (res.errMsg == 'shareAppMessage:ok') {
						console.log(res.errMsg);
					}
				},
				fail: function(res) { // 转发失败
				}
			};
		},
		methods: {
			//查询砍价信息
			bargainInfoGet(data) {
				api.bargainInfoGet(data).then(res => {
					this.hasBargainUser = true;
					if (!res.data.bargainUser) {
						res.data.bargainUser = {
							validBeginTime: '',
							validEndTime: '',
						};
						this.hasBargainUser = false;
					}
					let bargainInfo = res.data;
					let goodsSku = bargainInfo.goodsSku;
					let specInfo = '';
					goodsSku.specs.forEach(function(specItem, index) {
						specInfo = specInfo + specItem.specValueName;
						if (goodsSku.specs.length != index + 1) {
							specInfo = specInfo + ';';
						}
					});
					this.bargainInfo = bargainInfo;
					this.specInfo = specInfo;
					if (this.hasBargainUser) {
						let canCutPrice = bargainInfo.goodsSku.salesPrice - bargainInfo.bargainPrice; //可砍
						let havCutPrice = bargainInfo.bargainUser.havBargainAmount; //已砍
						let cutPercent = Number(havCutPrice / canCutPrice * 100).toFixed(2) + '%';
						this.bargainInfo = bargainInfo;
						this.parameter.bargainUserId = bargainInfo.bargainUser.id;
						this.cutPercent = cutPercent;
						this.canCutPrice = canCutPrice;
						this.havCutPrice = havCutPrice;
						this.bargainCutList = [];
						this.bargainCutPage();
					}
					setTimeout(() => {
						this.article_description = bargainInfo.goodsSpu ? bargainInfo.goodsSpu.description:'';
					}, 300);
					// #ifdef H5
					this.curLocalUrl = window.location.href;
					if (this.bargainInfo.bargainUser && this.hasBargainUser) {
						this.curLocalUrl = this.curLocalUrl + '&bargainUserId=' + this.bargainInfo.bargainUser.id;
					}
					// #endif
				});
			},

			//帮砍记录列表
			bargainCutPage() {
				api.bargainCutPage(Object.assign({}, this.page, util.filterForm(this.parameter))).then(res => {
					let bargainCutList = res.data.records;
					this.bargainCutList = [...this.bargainCutList, ...bargainCutList];
					if (bargainCutList.length < this.page.size) {
						this.loadmore = false;
					}
				});
			},

			//发起砍价
			bargainUserSave() {
				this.disabled = true;
				api.bargainUserSave({
					bargainId: this.bargainInfo.id
				}).then(res => {
					this.bargainInfoGet({
						bargainId: this.id
					});
				});
			},

			loadMore() {
				this.page.current = this.page.current + 1;
				this.bargainCutPage();
			},

			shareShowFun() {
				// #ifdef H5
				this.curLocalUrl = window.location.href;
				if (this.bargainInfo.bargainUser && this.hasBargainUser) {
					this.curLocalUrl = this.curLocalUrl + '&bargainUserId=' + this.bargainInfo.bargainUser.id;
				}
				// #endif
				// #ifdef APP-PLUS
				this.curLocalUrl = util.setAppPlusShareUrl();
				if (this.bargainInfo.bargainUser && this.hasBargainUser) {
					this.curLocalUrl = this.curLocalUrl + '&bargainUserId=' + this.bargainInfo.bargainUser.id;
				}
				// #endif
				this.shareShow = 'show';
			},

			shareHide() {
				this.shareShow = '';
			},

			onPosterSuccess(e) {
				this.posterUrl = e;
				this.posterShow = true;
			},

			onPosterFail(err) {
				console.error(err);
			},

			hidePosterShow() {
				this.posterShow = false;
				this.shareShow = '';
			},
			/**
			 * 异步生成海报
			 */
			onCreatePoster() {
				// #ifdef MP
				api.qrCodeUnlimited({
					theme: app.globalData.theme, //全局颜色变量
					page: 'pages/bargain/bargain-detail/index',
					scene: this.bargainInfo.bargainUser.id
				}).then(res => {
					base64src(res.data, res => {
						this.startCreatePoster(res);
					});
				});
				// #endif
				// #ifdef H5
				uni.showLoading({
					title: '海报生成中',
					mask: true
				});
				this.$refs.qrCodeRef._makeCode(); // H5需要先生成二维码后 才能生成海报
				// #endif
			},
			startCreatePoster(res) { // 开始 生成海报

				let desc = '长按识别小程序码';
				let shareImg = this.bargainInfo.picUrl;
				// #ifdef H5
					desc = '长按识别二维码';
					// h5的海报分享的图片有的有跨域问题，所以统一转成base64的
					// 之所以不在组件里面转换是因为无法区分哪张image图片需要处理，一般处理主图
					shareImg = util.imgUrlToBase64(shareImg);
				// #endif
					let qrCode = res; //海报配置请参考 https://github.com/jasondu/wxa-plugin-canvas
					let posterConfig = {
						width: 750,
						height: 1280,
						backgroundColor: '#fff',
						debug: false,
						blocks: [{
							width: 690,
							height: 808,
							x: 30,
							y: 183,
							borderWidth: 2,
							borderColor: '#f0c2a0',
							borderRadius: 20
						}, {
							width: 634,
							height: 74,
							x: 59,
							y: 770,
							backgroundColor: '#fff',
							opacity: 0.5,
							zIndex: 100
						}],
						texts: [{
							x: 30,
							y: 113,
							baseLine: 'top',
							text: this.bargainInfo.shareTitle,
							fontSize: 38,
							color: '#080808'
						}, {
							x: 92,
							y: 810,
							fontSize: 38,
							baseLine: 'middle',
							text: this.bargainInfo.goodsSpu.name,
							width: 570,
							lineNum: 1,
							color: '#080808',
							zIndex: 200
						}, {
							x: 59,
							y: 895,
							baseLine: 'middle',
							text: [{
								text: '底价',
								fontSize: 28,
								color: '#ec1731'
							}, {
								text: '¥' + this.bargainInfo.bargainPrice,
								fontSize: 36,
								color: '#ec1731',
								marginLeft: 30
							}]
						}, {
							x: 522,
							y: 895,
							baseLine: 'middle',
							text: '原价 ¥' + this.bargainInfo.goodsSku.salesPrice,
							fontSize: 28,
							color: '#929292'
						}, {
							x: 59,
							y: 945,
							baseLine: 'middle',
							text: [{
								text: this.bargainInfo.goodsSpu.sellPoint,
								fontSize: 28,
								color: '#929292',
								width: 570,
								lineNum: 1
							}]
						}, {
							x: 360,
							y: 1065,
							baseLine: 'top',
							text: desc,
							fontSize: 38,
							color: '#080808'
						}, {
							x: 360,
							y: 1123,
							baseLine: 'top',
							text: '快来帮好友砍一刀',
							fontSize: 28,
							color: '#929292'
						}],
						images: [{
							width: 634,
							height: 634,
							x: 59,
							y: 210,
							url: shareImg
						}, {
							width: 220,
							height: 220,
							x: 92,
							y: 1020,
							url: qrCode
						}]
					};
					let userInfo = uni.getStorageSync('user_info');

					if (userInfo && userInfo.headimgUrl) {
						//如果有头像则显示
						posterConfig.images.push({
							width: 62,
							height: 62,
							x: 30,
							y: 30,
							borderRadius: 62,
							url: userInfo.headimgUrl
						});
						posterConfig.texts.push({
							x: 113,
							y: 61,
							baseLine: 'middle',
							text: userInfo.nickName,
							fontSize: 32,
							color: '#8d8d8d'
						});
					}
					this.posterConfig = posterConfig;
					this.posterShow = true;
					this.$refs.posterRef.onCreate(false, this.posterConfig); // 入参：true为抹掉重新生成
			},
			//点击保存到相册
			savePoster: function() {
				var that = this;
				uni.saveImageToPhotosAlbum({
					filePath: that.posterUrl,
					success(res) {
						uni.showModal({
							content: '图片已保存到相册，赶紧晒一下吧~',
							showCancel: false,
							confirmText: '好的',
							confirmColor: '#333',
							success: function(res) {
								if (res.confirm) {
									/* 该隐藏的隐藏 */
									that.shareShow = '';
								}
							},
							fail: function(res) {
								console.log(res);
							}
						});
					}

				});
			},

			//砍一刀
			bargainCutSave() {
				this.disabled = true;
				let bargainUserId = this.bargainInfo.bargainUser.id;
				api.bargainCutSave({
					bargainUserId: bargainUserId
				}).then(res => {
					let bargainCut = res.data;
					let that = this;
					uni.showModal({
						content: '恭喜为好友砍下' + bargainCut.cutPrice.toFixed(2) + '元',
						confirmColor: '#ff0000',
						success(res) {
							that.bargainInfoGet({
								bargainId: that.id,
								id: bargainUserId
							});
						}

					});
				});
			},

			ruleShow() {
				this.modalRule = 'show';
			},

			ruleHide() {
				this.modalRule = '';
			},

			//前去购买
			toBuy() {
				let bargainInfo = this.bargainInfo;
				let bargainUser = bargainInfo.bargainUser;
				let goodsSpu = bargainInfo.goodsSpu;
				let goodsSku = bargainInfo.goodsSku;
				/* 把参数信息异步存储到缓存当中 */

				uni.setStorage({
					key: 'param-orderConfirm',
					data: [{
						spuId: goodsSpu.id,
						skuId: goodsSku.id,
						quantity: 1,
						salesPrice: (goodsSku.salesPrice - this.havCutPrice).toFixed(2),
						spuName: goodsSpu.name,
						specInfo: this.specInfo,
						picUrl: goodsSku.picUrl ? goodsSku.picUrl : goodsSpu.picUrls[0],
						freightTemplat: goodsSpu.freightTemplat,
						weight: goodsSku.weight,
						volume: goodsSku.volume,
						orderType: '1',
						marketId: bargainInfo.id,
						relationId: bargainUser.id
					}]
				});
				uni.navigateTo({
					url: '/pages/bargain/bargain-order-confirm/index'
				});
			},

			countDownDone() {
				this.onLoad();
			}

		}
	};
</script>
<style>
	.row-img {
		width: 200rpx !important;
		height: 200rpx !important;
		border-radius: 10rpx
	}

	.bargain-btn{
		width: 580rpx;
		height: 76rpx;
	}

	.show-bg{
		height: 84%;
		margin-top: 120rpx;
	}

	.image-box{
		height: 90%;
	}

	.show-btn{
		margin-top: -130rpx;
	}
</style>
