<template>
	<view>
		<cu-custom :bgColor="'bg-'+theme.backgroundColor" :isBack="true">
			<block slot="content">附近店铺</block>
		</cu-custom>
		<!-- <view class="flex bg-white align-center justify-between" style="width: 100%;padding:0 0rpx 0 30rpx;position: fixed;top: 0rpx;z-index: 1000;">
			<view class="bg-white flex align-center text-bold" @tap="getLocation" style="flex: 1;">
				<text class="cuIcon-location"></text>
				<view style="margin-left: 5rpx;">合肥市</view>
			</view>
			<view class="cu-bar search bg-white" style="flex: 5;">
				<view class="search-form round">
					<text class="cuIcon-search"></text>
					<navigator class="response" hover-class='none' url='/pages/base/searchLocation/index'>
					<input type="text" placeholder="搜索小店"></input>
					</navigator>
				</view>
			</view>
		</view> -->
		<view class="flex justify-between align-center padding fixed" :style="[{top:CustomBar+'px'}]">
			<view class="title">搜索范围</view>
			<picker @change="PickerChange" :value="index" :range="round" range-key="label">
				<view class="flex justify-between">
					<text style="">{{round[index].label}}</text>
					<text class="cuIcon-triangledownfill text-xxl text-bold"></text>
				</view>
			</picker>
		</view>
		<map v-if="isShow" id="map" ref="map" style="width: 100%; height: 300px;position: fixed;z-index: 1000;" :style="[{top:CustomBar + 50+'px'}]"
		 :latitude="page.latitude" :longitude="page.longitude" scale="12" :circles="circles" @controltap="controltap"
		 :markers="markers" @markertap="markertap" @regionchange="regionchange" show-location>
		</map>
		<view class="text-bold shopTitle" style="width: 100%;padding: 20rpx 20rpx 10rpx 20rpx;margin-top:640rpx ;">附件小店</view>
		<view class="locationList" v-for="item in shopInfoData" :key="item.id">
			<view class="flex align-center">
				<view class="loc_img margin-right" style="width: 80rpx;height: 80rpx;">
					<image style="" class="round" :src="item.imgUrl"></image>
				</view>
				<view style="width: 70%;">
					<view class="text-black" style="font-size: 15px;">{{item.name}}</view>
					<view class="text-gray text-sm overflow-2">{{item.detail}}</view>
				</view>
				<view class="text-gray text-sm">
					距离您{{item.distance}}千米
				</view>
			</view>
			<view class="flex justify-around loc_bot">
				<navigator :url="'../shop/shop-detail/index?id='+item.id">
					<view class="text-center">
						<text class="cuIcon-shop text-green" style="font-size: 16px;"></text>
						进店选购
					</view>
				</navigator>
				<view class="line_c"></view>
				<view class="text-center" @click="onGuideTap(item)">
					<text class="cuIcon-taxi text-blue" style="font-size: 16px;"></text>
					导航</view>
			</view>
		</view>
		<view v-if="shopInfoData.length <= 0" class="no-goods">
			<image src="/static/public/img/no-item.png" class="no-item margin-top"></image>
			<view class="text-sm text-gray text-center">您的附近没有店铺哦～</view>
			<navigator hover-class="none" url="/pages/shop/shop-list/index">
				<button class="cu-btn margin-top" :class="'bg-'+theme.themeColor">去其他小店逛逛</button>
			</navigator>
		</view>
	</view>
</template>
<script>
	const app = getApp();
	import api from 'utils/api'
	// import QQMapWX from "@/utils/qqmap-wx-jssdk.js"
	// var qqmapsdk = new QQMapWX({
	// 	key: 'HX5BZ-62JKS-RVBO2-6HZZP-KWZ2E-JCB47'
	// });
	export default {
		data() {
			return {
				theme: app.globalData.theme, //全局颜色变量
				CustomBar: this.CustomBar,
				markers: [],
				shopInfoData: [],
				page: {
					round:2,
					latitude: 31.818119, //纬度
					longitude: 117.233651 //经度
				},
				index:0,
				round:[{
					label:"2公里",
					value:5
				},{
					label:"10公里",
					value:10
				},{
					label:"20公里",
					value:20
				}],
				latitude: 31.818119,
				longitude: 117.233651,
				circles: null,
				isShow:false,
				controls: [{
					id: 1,
					iconPath: '/static/public/logo.png',
					position: {
						left: 0,
						top: 300 - 50,
						width: 50,
						height: 50
					},
					clickable: true
				}]
			}
		},
		onLoad: function() {
			// 调用接口
			var _this = this;
			uni.getLocation({
				type: "gcj02",
				success(res) {
					_this.page.latitude = res.latitude;
					_this.page.longitude = res.longitude;
					_this.isShow = true;
					_this.shopInfoPage(_this.page)
				}
			})
		},
		methods: {
			PickerChange(e){
				this.index = e.detail.value
				this.page.round = this.round[this.index].value
				this.shopInfoPage(this.page)
			},
			//店铺列表
			shopInfoPage(page) {
				api.shopInfoList(page).then(res => {
					this.shopInfoData = res.data;
					var mks = []
					for (var i = 0; i < this.shopInfoData.length; i++) {
						mks.push({ // 获取返回结果，放到mks数组中
							title: this.shopInfoData[i].name,
							id: this.shopInfoData[i].id,
							latitude: this.shopInfoData[i].latitude,
							longitude: this.shopInfoData[i].longitude,
							iconPath: "/static/public/img/icon-1/5-001.png", //图标路径
							address: this.shopInfoData[i].address,
							zIndex: '1',
							width: 40,
							height: 40,
							anchor: {
							    x: 0.5,
							    y: 1
							},
							// #ifdef MP-WEIXIN
							callout: {
								content: this.shopInfoData[i].name,
								title:this.shopInfoData[i].name,
								color: '#fff',
								borderRadius: 5,
								bgColor: '#114EB8',
								padding: 5,
								display: "ALWAYS",
								anchorY: "5"
							},
							// #endif
							// #ifdef APP-PLUS
							label:{
								content: this.shopInfoData[i].name,
								color: '#fff',
								borderRadius: 5,
								bgColor: '#114EB8',
								padding: 5,
							}
							// #endif
						})
					}
					this.markers = mks;
				});
			},
			regionchange(e) {
				// #ifdef MP-WEIXIN
				if (e.type == 'end' && (e.causedBy == 'scale' || e.causedBy == 'drag')) {
					var _this = this;
					_this.mapCtx = uni.createMapContext("map");
					_this.mapCtx.getCenterLocation({
						type: 'gcj02',
						success: function(res) {
							_this.page.latitude = res.latitude
							_this.page.longitude = res.longitude
							_this.circles = [{
								latitude: res.latitude,
								longitude: res.longitude,
								color: '#FF0000DD',
								fillColor: '#d1edff88',
								radius: 300, //定位点半径
								strokeWidth: 5
							}]
							_this.shopInfoPage(_this.page)
						}
					})
				}
				// #endif
				// #ifdef APP-PLUS
				if (e.type == 'regionchange') {
					var _this = this;
					_this.mapCtx = uni.createMapContext("map");
					_this.mapCtx.getCenterLocation({
						type: 'gcj02',
						success: function(res) {
							_this.page.latitude = res.latitude
							_this.page.longitude = res.longitude
							_this.circles = [{
								latitude: res.latitude,
								longitude: res.longitude,
								color: '#FF0000DD',
								fillColor: '#d1edff88',
								radius: 500, //定位点半径
								strokeWidth: 5
							}]
							_this.shopInfoPage(_this.page)
						}
					})
				}
				// #endif
			},
			markertap(e) {
				uni.navigateTo({
					url: `../shop/shop-detail/index?id=${e.detail.markerId}`
				})
			},
			controltap(e) {
				// console.log(e.detail.controlId)
			},
			// my_location: function(e) {
			// 	var that = this;
			// 	that.onLoad();
			// },
			//导航
			onGuideTap: function(data) {
				// console.log(data)
				var lat = Number(data.latitude);
				var lon = Number(data.longitude);
				var bankName = data.name;
				uni.openLocation({
					type: 'gcj02',
					latitude: lat,
					longitude: lon,
					name: bankName,
					scale: 28
				})
			},
			//进店选购
			// shopNow() {
			// 	getApp().globalData.shopId = "1111122585894";
			// 	uni.navigateTo({
			// 		url: "/pages/shop-detail/index"
			// 	});
			// }
		}
	}
</script>
<style lang="scss" scoped>
	/* pages/map/index.wxss */
	// .shopTitle{

	// }
	.list-guide {
		display: flex;
		flex-direction: row;
		justify-content: space-around;
		border-top: 1px solid #ededed;
		height: 80rpx;
	}

	.list-guide-imgae {
		height: 70rpx;
		width: 70rpx;
		margin-right: 20px;
		vertical-align: middle;
	}

	.list-guide-text {
		vertical-align: middle;
		line-height: 90rpx;
		font-size: 35rpx;
	}

	.locationList {
		margin: 20rpx auto;
		padding: 30rpx;
		background-color: #fff;
		border-radius: 5px;
		width: 94%;
	}

	.loc_img {
		width: 80rpx;
		height: 80rpx;
		border-radius: 50%;
		margin-right: 40rpx;
		background: #F7F9FC;
	}

	.loc_img image {
		width: 100%;
		height: 100%;
	}

	.loc_bot {
		background: #F7F9FC;
		width: 100%;
		line-height: 70rpx;
		border-radius: 3px;
		margin-top: 20rpx;
		position: relative;
	}

	.line_c {
		position: absolute;
		height: 40rpx;
		width: 1px;
		background-color: #000;
		top: 50%;
		left: 50%;
		transform: translate(-50%, -50%);
	}

	.cover-image {
		width: 10px;
		height: 10px;
	}

	.no-goods {
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		margin: 0px auto;

		image {
			width: 300px;
			height: 200px;
		}
	}
</style>
