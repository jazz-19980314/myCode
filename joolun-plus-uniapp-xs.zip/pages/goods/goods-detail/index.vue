<!--
  - Copyright (C) 2018-2019
  - All rights reserved, Designed By www.joolun.com
  - 注意：
  - 本软件为www.joolun.com开发研制，未经购买不得使用
  - 购买后可获得全部源代码（禁止转卖、分享、上传到码云、github等开源平台）
  - 一经发现盗用、分享等行为，将追究法律责任，后果自负
-->
<template>
	<view>
		<cu-custom :bgColor="'bg-'+theme.backgroundColor" :isBack="true">
			<block slot="backText">返回</block>
			<block slot="content">商品详情</block>
		</cu-custom>
		<view class="product-bg">
			<swiper :class="'screen-swiper square-dot'" indicator-dots="true" circular="true"
			 autoplay="true" interval="5000" duration="500" @change="change" indicator-color="#cccccc" indicator-active-color="#ffffff">
				<swiper-item v-for="(item, index) in goodsSpu.picUrls" :key="index">
					<image :src="item" mode="aspectFill" ></image>
				</swiper-item>
			</swiper>
		</view>
		<view class="cu-bar bg-white">
			<view class="text-xl padding-tb-xs padding-lr-sm">
				<text class="text-price text-red text-bold">{{goodsSpu.priceDown}}</text>
				<text v-if="goodsSpu.priceDown != goodsSpu.priceUp" class="text-red margin-lr-xs">-</text>
				<text v-if="goodsSpu.priceDown != goodsSpu.priceUp" class="text-red text-bold">{{goodsSpu.priceUp}}</text>
			</view>
			<button class="cu-btn icon margin-right" @tap="shareShowFun">
				<text class="cuIcon-share text-green"></text>
			</button>
		</view>

		<view class="cu-bar bg-white" v-if="couponInfoList.length > 0">
			<view class="flex response margin-left-sm">
				<view class=" flex">
					<view class="coupon text-sm text-orange">{{couponInfoList[0].name}}</view>
					<view class="coupon text-sm text-orange" style="margin-left: 10rpx;" v-if="couponInfoList.length > 1">{{couponInfoList[1].name}}</view>
				</view>
				<view class="flex-sub text-orange text-right margin-right-sm" @tap="showModalCoupon">领券<text class="cuIcon-right"></text>
				</view>
			</view>
		</view>

		<view class="cu-bar bg-white">
			<view class="text-df text-bold padding-tb-xs padding-lr-sm">
				<text class="text-black">{{goodsSpu.name}}</text>
			</view>
		</view>
		<view class="cu-bar bg-white">
			<view class="text-sm padding-tb-xs padding-lr-sm">
				<text class="text-gray">{{goodsSpu.sellPoint}}</text>
			</view>
		</view>

		<view class="cu-bar bg-white margin-top-sm">
			<view class="flex response">
				<view class="flex-sub text-sm">
					<view class="text-gray margin-left-sm">发货</view>
				</view>
				<view class="flex-treble text-sm">
					<text class="cuIcon-location text-black" v-if="goodsSpu.deliveryPlace">{{goodsSpu.deliveryPlace.place}} |</text>
					<text class="text-black" v-if="goodsSpu.freightTemplat">运费：{{goodsSpu.freightTemplat.type == '2' ? '全国包邮' : '￥'+goodsSpu.freightTemplat.firstFreight}}</text>
				</view>
				<view class="flex-sub text-sm text-gray text-right margin-right">销量{{goodsSpu.saleNum?goodsSpu.saleNum:0}}</view>
			</view>
		</view>

		<view class="cu-bar bg-white" v-if="goodsSpu.pointsGiveSwitch == '1' || goodsSpu.pointsDeductSwitch == '1'">
			<view class="flex response">
				<view class="flex-sub text-sm">
					<view class="text-gray margin-left-sm">优惠</view>
				</view>
				<view class="flex-four text-sm" >
					<view v-if="goodsSpu.pointsGiveSwitch == '1'">
						<text class="cu-tag bg-red light sm radius">积分赠送</text>
						<text class="text-black margin-left-xs">购买可获得{{goodsSpu.pointsGiveNum}}积分</text>
					</view>
					<view class="margin-top-xs" v-if="goodsSpu.pointsDeductSwitch == '1'">
						<text class="cu-tag bg-red light sm radius">积分抵扣</text>
						<text class="text-black margin-left-xs">1积分可抵{{goodsSpu.pointsDeductAmount}}元，最多可抵{{goodsSpu.pointsDeductScale}}%</text>
					</view>
				</view>
			</view>
		</view>

		<view class="cu-bar bg-white" v-if="ensureList.length > 0">
			<view class="flex response" @tap="showModalService">
				<view class="flex-sub text-sm">
					<view class="text-gray margin-left-sm">服务</view>
				</view>
				<view class="flex-treble text-sm">
					<text class="text-black">{{ensureList[0].name}} {{ensureList[1] ? '| '+ensureList[1].name : ''}}</text>
				</view>
				<view class="flex-sub text-sm text-gray text-right">
					<text class="cuIcon-right margin-right-sm"></text>
				</view>
			</view>
		</view>
		<view :class="'cu-modal bottom-modal ' + modalService">
			<view class="cu-dialog">
				<view class="padding-xl">
					<view class="text-lg text-center">基础服务</view>
					<view class="cu-list text-left solid-bottom">
						<view class="cu-item" v-for="(item, index) in ensureList" :key="index">
							<view class="content padding-tb-sm">
								<view><text class="cuIcon-roundcheckfill text-orange"></text>{{item.name}}</view>
								<view class="text-gray text-sm" v-if="item.detail">{{item.detail}}</view>
							</view>
						</view>
					</view>
					<button class="cu-btn margin-top response lg" :class="'bg-'+theme.themeColor" @tap="hideModalService">确定</button>
				</view>
			</view>
		</view>

		<coupon-receive
			:couponInfoList="couponInfoList"
			:modalCoupon="modalCoupon"
			@changeModalCoupon="modalCoupon=$event"
			@receiveCouponChange="receiveCouponChange($event)"></coupon-receive>

		<view class="cu-bar bg-white" v-if="goodsSpu.specType == '1'">
			<view class="flex response" @tap="showModalSku">
				<view class="flex-sub text-sm">
					<view class="text-gray margin-left-sm">选择</view>
				</view>
				<view class="flex-treble text-sm text-black">
					<view class="display-ib" v-for="(item, index) in goodsSpecData" :key="index">
						<view class="display-ib" v-if="!item.checked">{{item.value}}</view>
						<view class="display-ib" v-if="item.checked" v-for="(item2, index2) in item.leaf" :key="index2">
							<view class="display-ib" v-if="item.checked == item2.id">{{item2.value}}</view>
						</view>
						<view class="display-ib" v-if="goodsSpecData.length != (index+1)">,</view>
					</view>
				</view>
				<view class="flex-sub text-sm text-gray text-right">
					<text class="cuIcon-right margin-right-sm"></text>
				</view>
			</view>
		</view>

		<view class="margin-top-sm">
			<shopInfo :shopInfo="shopInfo" :card="false"></shopInfo>
		</view>

		<view class="cu-bar bg-white margin-top-sm solid-bottom">
			<view class="flex response">
				<view class="flex-sub text-sm">
					<view class="text-black margin-left-sm">宝贝评价（{{goodsAppraises.total?goodsAppraises.total:0}}）</view>
				</view>
				<navigator :url="'/pages/appraises/list/index?spuId=' + goodsSpu.id" hover-class="none" class="flex-sub text-df text-gray text-right margin-right-sm"
				 v-if="goodsAppraises.total > 0">查看全部<text class="cuIcon-right"></text>
				</navigator>
			</view>
		</view>
		<view class="cu-list menu-avatar comment">
			<navigator :url="'/pages/appraises/list/index?spuId=' + goodsSpu.id" hover-class="none" class="cu-item" v-for="(item, index) in goodsAppraises.records"
			 :key="index">
				<view class="cu-avatar round" :style="'background-image:url(' + item.headimgUrl + ')'">{{!item.headimgUrl ? '头' : ''}}</view>
				<view class="content padding-bottom-xs">
					<view class="text-black">{{item.nickName ? item.nickName : '匿名'}}
						<view class="text-gray margin-left text-sm">{{item.createTime}}</view>
					</view>
					<view class="text-gray text-sm" v-if="item.specInfo">规格：{{item.specInfo}}</view>
					<base-rade :value="item.goodsScore" size="lg"></base-rade>
					<view class="text-black text-content text-df overflow-2">{{item.content ? item.content : '此人很懒没写评语'}}</view>
				</view>
			</navigator>
		</view>

		<view class="cu-bar bg-white margin-top-sm">
			<view class="content">商品信息</view>
		</view>
		<view class="bg-white">
			<jyf-parser :html="article_description"></jyf-parser>
		</view>

		<view class="cu-load bg-gray to-down">已经到底啦...</view>

		<view class="cu-bar bg-white tabbar border shop foot" v-if="shopInfo">
			<navigator class="action bg-white" open-type="navigate"
				:url="'/pages/customer-service/customer-service-list/index?shopId='+shopInfo.id+'&goodsSpuId='+goodsSpu.id">
				<view class="cuIcon-servicefill"></view>客服
			</navigator>
			<view class="action" @tap="userCollect">
				<view :class="'cuIcon-' + (goodsSpu.collectId ? 'likefill text-red' : 'like')"></view>{{goodsSpu.collectId ? '已收藏' : '收藏'}}
			</view>
			<navigator class="action" open-type="switchTab" url="/pages/shopping-cart/index">
				<view class="cuIcon-cart">
					<view class="cu-tag badge">{{shoppingCartCount}}</view>
				</view>购物车
			</navigator>
			<view class="btn-group">
				<button class="cu-btn bg-orange round shadow-blur" @tap="showModalSku" data-type="1">加入购物车</button>
				<button class="cu-btn round shadow-blur" :class="'bg-'+theme.themeColor" @tap="showModalSku" data-type="2">立即购买</button>
			</view>
		</view>
		<goods-sku :goodsSpu="goodsSpu" :cartNum="cartNum" :shopInfo="shopInfo" @numChange="cartNum = $event" :goodsSku="goodsSku"
		 @changeGoodsSku="goodsSku = $event" :goodsSpecData="goodsSpecData" @changeSpec="goodsSpecData = $event" :modalSku="modalSku"
		 @changeModalSku="modalSku=$event" :modalSkuType="modalSkuType" @operateCartEvent="operateCartEvent"></goods-sku>

		<view :class="'cu-modal ' + (goodsSpu.shelf=='0'?'show':'')">
			<view class="cu-dialog">
				<view class="cu-bar bg-white justify-end">
					<view class="content">提示</view>
				</view>
				<view class="padding-xl">抱歉，该商品已下架</view>
			</view>
		</view>
		<poster id="poster" ref='posterRef' :hide-loading="false" :preload="false" :config="posterConfig" @success="onPosterSuccess"
		 @fail="onPosterFail"></poster>
		<view :class="'cu-modal bottom-modal ' + shareShow" @tap="shareHide" >
			<view class="cu-dialog" @tap.stop>
				<view class="cu-bar bg-white">
					<view class="action text-green"></view>
					<view class="action text-red" @tap="shareHide">取消</view>
				</view>
				<view class="padding flex flex-direction">
					<share-friends
						:shareObj="{
								title: '发现一个好物，推荐给你呀',
								desc: goodsSpu.name,
								imgUrl: goodsSpu.picUrls[0],
						}"></share-friends>
					<!-- #ifndef APP-PLUS -->
					<button class="cu-btn margin-tb-sm lg round shadow-blur" :class="'bg-'+theme.themeColor" @tap="onCreatePoster">生成海报</button>
					<!-- #endif -->
				</view>
			</view>
		</view>

		<view :class="'cu-modal ' + (posterShow ? 'show' : '')">
			<view class="cu-dialog show-bg">
				<view class="bg-white" style="height: calc(100vh - 200rpx)">
					<image :src="posterUrl" class="image-box"></image>
				</view>
				<view class="cu-bar bg-white solid-top show-btn">
					<view class="action margin-0 flex-sub" @tap="hidePosterShow">取消</view>
					<!-- #ifdef MP || APP-PLUS -->
					<view class="action margin-0 flex-sub solid-left text-red text-bold" @tap="savePoster">保存到相册</view>
					<!-- #endif -->
					<!-- #ifdef H5 -->
					<view class="action margin-0 flex-sub solid-left text-red text-bold"  @tap="hidePosterShow">长按图片可保存或分享</view>
					<!-- #endif -->

				</view>
			</view>
		</view>

		<!-- #ifdef H5 || APP-PLUS -->
		<!-- 二维码组件，不显示，只用来生成二维码调用 说明文档 https://github.com/q310550690/uni-app-qrcode -->
		<!-- 该组件生成二维码时需要canvas元素装载,固直接引用组件没有使用js，效果一样 -->
		<view>
			<tki-qrcode ref="qrCodeRef" :size="200" :show="false" :val="curLocalUrl" @result="startCreatePoster"  icon="/static/public/logo.png"></tki-qrcode>
		</view>
		<!-- #endif -->
	</view>
</template>

<script>
	/**
	 * Copyright (C) 2018-2019
	 * All rights reserved, Designed By www.joolun.com
	 * 注意：
	 * 本软件为www.joolun.com开发研制，未经购买不得使用
	 * 购买后可获得全部源代码（禁止转卖、分享、上传到码云、github等开源平台）
	 * 一经发现盗用、分享等行为，将追究法律责任，后果自负
	 */
	import goodsSku from "components/goods-sku/index";
	const {
		base64src
	} = require("utils/base64src.js");
	const app = getApp();
	import api from 'utils/api'
	import jweixin from '@/utils/jweixin'
	import util from '@/utils/util'

	import baseRade from "components/base-rade/index";
	import poster from "components/wxa-plugin-canvas/poster/index";
	import couponReceive from "components/coupon-receive/index";
	import shopInfo from "components/shop-info/index";

	import tkiQrcode from "components/tki-qrcode/tki-qrcode.vue"
	import shareFriends from "components/share-friends/index.vue"

	export default {
		components: {
			goodsSku,
			baseRade,
			poster,
			couponReceive,
			shopInfo,
			tkiQrcode,
			shareFriends,
		},
		data() {
			return {
				CustomBar: this.CustomBar,
				theme: app.globalData.theme, //全局颜色变量
				shopInfo: {},
				cartNum: 1,
				goodsSpu: {
					picUrls: []
				},
				goodsSku: {},
				goodsSpecData: [],
				goodsAppraises: {},
				currents: 1,
				modalSku: false,
				modalSkuType: '',
				shoppingCartCount: 0,
				shareShow: '',
				curLocalUrl: '',
				ensureList: [],
				modalService: '',
				modalCoupon: false,
				couponInfoList: [],
				id: "",
				posterUrl: "",
				posterShow: false,
				posterConfig: "",
				article_description: ""
			};
		},
		props: {},
		onLoad(options) {
			let id;
			if (options.scene) {
				//接受二维码中参数
				id = decodeURIComponent(options.scene);
			} else {
				id = options.id;
			}
			this.id = id;
			app.initPage().then(res => {
				this.goodsGet(id);
				this.couponInfoPage(id);
				this.shoppingCartCountFun();
				this.goodsAppraisesPage();
				this.listEnsureBySpuId(id);
			});
		},
		onShareAppMessage: function() {
			let goodsSpu = this.goodsSpu;
			let title = goodsSpu.name;
			let imageUrl = goodsSpu.picUrls[0];
			let path = 'pages/goods/goods-detail/index?id=' + goodsSpu.id;
			return {
				title: title,
				path: path,
				imageUrl: imageUrl,
				success: function(res) {
					if (res.errMsg == 'shareAppMessage:ok') {
						console.log(res.errMsg);
					}
				},
				fail: function(res) { // 转发失败
				}
			};
		},
		methods: {
			goodsGet(id) {
				api.goodsGet(id).then(res => {
					this.goodsSpu = res.data;
					this.goodsSpecGet(id);
					//获取店铺信息
					this.shopInfoGet(this.goodsSpu.shopId);
					if (this.goodsSpu) {
						this.goodsSku = this.goodsSpu.specType == '0' ? this.goodsSpu.skus[0] : {}
					}
					//WxParse.wxParse('description', 'html', goodsSpu.description, this, 0)
					setTimeout(() => {
						this.article_description = this.goodsSpu.description;
					}, 300);
				});
			},

			//查询店铺
			shopInfoGet(shopId) {
				api.shopInfoGet(shopId).then(res => {
					this.shopInfo = res.data;
				});
			},

			goodsSpecGet(spuId) {
				api.goodsSpecGet({
					spuId: spuId
				}).then(res => {
					res.data ? res.data.map(t => {
						t.checked = ''
					}) : [];
					this.goodsSpecData = res.data;
				});
			},

			goodsAppraisesPage() {
				api.goodsAppraisesPage({
					current: 1,
					size: 3,
					descs: 'create_time',
					spuId: this.id
				}).then(res => {
					this.goodsAppraises = res.data;
				});
			},

			//查询商品可用电子券
			couponInfoPage(spuId) {
				api.couponInfoPage({
					current: 1,
					size: 50,
					descs: 'create_time',
					spuId: spuId
				}).then(res => {
					this.couponInfoList = res.data.records;
				});
			},

			receiveCouponChange(obj) { //更新单条数据
				this.couponInfoList[obj.index] = obj.item;
				this.couponInfoList.splice(); //确保页面刷新成功
			},

			//获取商品保障
			listEnsureBySpuId(spuId) {
				api.listEnsureBySpuId({
					spuId: spuId
				}).then(res => {
					this.ensureList = res.data;
				});
			},

			change: function(e) {
				this.currents = e.detail.current + 1;
			},

			showModalService() {
				this.modalService = 'show';
			},

			hideModalService() {
				this.modalService = '';
			},

			showModalCoupon() {
				this.modalCoupon = true;
			},

			hideModalCoupon() {
				this.modalCoupon = false;
			},

			showModalSku(e) {
				this.modalSku = true;
				this.modalSkuType = e.target.dataset.type ? e.target.dataset.type+'' : '';
			},

			shoppingCartCountFun() {
				api.shoppingCartCount().then(res => {
					this.shoppingCartCount = res.data; //设置TabBar购物车数量
					app.globalData.shoppingCartCount = this.shoppingCartCount + '';
				});
			},

			operateCartEvent() {
				this.shoppingCartCountFun();
			},

			//收藏
			userCollect() {
				let goodsSpu = this.goodsSpu;
				let collectId = goodsSpu.collectId;

				if (collectId) {
					api.userCollectDel(collectId).then(res => {
						uni.showToast({
							title: '已取消收藏',
							icon: 'success',
							duration: 2000
						});
						goodsSpu.collectId = null;
						this.goodsSpu = goodsSpu;
					});
				} else {
					api.userCollectAdd({
						type: '1',
						relationIds: [goodsSpu.id]
					}).then(res => {
						uni.showToast({
							title: '收藏成功',
							icon: 'success',
							duration: 2000
						});
						goodsSpu.collectId = res.data[0].id;
						this.goodsSpu = goodsSpu;
					});
				}
			},
			shareShowFun() {
				// #ifdef H5
				this.curLocalUrl = window.location.href;
				// #endif
				// #ifdef APP-PLUS
				this.curLocalUrl = util.setAppPlusShareUrl();
				// #endif
				this.shareShow = 'show';
			},
			shareHide() {
				this.shareShow = '';
			},
			onPosterSuccess(e) {
				this.posterUrl = e;
				this.posterShow = true;
			},
			onPosterFail(err) {
				console.error(err);
			},
			hidePosterShow() {
				this.posterShow = false;
				this.shareShow = '';
			},
			/**
			 * 异步生成海报
			 */
			onCreatePoster() {
				// #ifdef MP
				api.qrCodeUnlimited({
					theme: app.globalData.theme, //全局颜色变量
					page: 'pages/goods/goods-detail/index',
					scene: this.goodsSpu.id
				}).then(res => {
					base64src(res.data, res => {
						this.startCreatePoster(res);
					});
				});
				// #endif
				// #ifdef H5 || APP-PLUS
					uni.showLoading({
						title: '海报生成中',
						mask: false
					});
					this.$refs.qrCodeRef._makeCode(); // H5需要先生成二维码后 才能生成海报
				// #endif
			},

			startCreatePoster(res){ // 开始 生成海报
				uni.hideLoading();
				let desc = '长按识别小程序码';
				let qrCode = res; //海报配置请参考 https://github.com/jasondu/wxa-plugin-canvas
				let shareImg = this.goodsSpu.picUrls[0];
				// #ifdef H5 || APP-PLUS
					desc = '长按识别二维码';
					// h5的海报分享的图片有的有跨域问题，所以统一转成base64的
					// 之所以不在组件里面转换是因为无法区分哪张image图片需要处理，一般处理主图
					shareImg = util.imgUrlToBase64(shareImg);
				// #endif
				let posterConfig = {
					width: 750,
					height: 1280,
					backgroundColor: '#fff',
					debug: false,
					blocks: [{
						width: 690,
						height: 808,
						x: 30,
						y: 183,
						borderWidth: 2,
						borderColor: '#f0c2a0',
						borderRadius: 20
					}, {
						width: 634,
						height: 74,
						x: 59,
						y: 770,
						backgroundColor: '#fff',
						opacity: 0.5,
						zIndex: 100
					}],
					texts: [{
						x: 30,
						y: 113,
						baseLine: 'top',
						text: '发现一个好物，推荐给你呀',
						fontSize: 38,
						color: '#080808'
					}, {
						x: 92,
						y: 810,
						fontSize: 38,
						baseLine: 'middle',
						text: this.goodsSpu.name,
						width: 570,
						lineNum: 1,
						color: '#080808',
						zIndex: 200
					}, {
						x: 59,
						y: 895,
						baseLine: 'middle',
						text: [{
							text: '只需',
							fontSize: 28,
							color: '#ec1731'
						}, {
							text: '¥' + this.goodsSpu.priceDown,
							fontSize: 36,
							color: '#ec1731',
							marginLeft: 30
						}]
					}, {
						x: 522,
						y: 895,
						baseLine: 'middle',
						text: '已售' + this.goodsSpu.saleNum,
						fontSize: 28,
						color: '#929292'
					}, {
						x: 59,
						y: 945,
						baseLine: 'middle',
						text: [{
							text: this.goodsSpu.sellPoint,
							fontSize: 28,
							color: '#929292',
							width: 570,
							lineNum: 1
						}]
					}, {
						x: 360,
						y: 1065,
						baseLine: 'top',
						text: desc,
						fontSize: 38,
						color: '#080808'
					}, {
						x: 360,
						y: 1123,
						baseLine: 'top',
						text: '超值好货快来购买',
						fontSize: 28,
						color: '#929292'
					}],
					images: [{
						width: 634,
						height: 634,
						x: 59,
						y: 210,
						url: shareImg
					}, {
						width: 220,
						height: 220,
						x: 92,
						y: 1020,
						url: qrCode
					}]
				};
				let userInfo = uni.getStorageSync('user_info');
				if (userInfo && userInfo.headimgUrl) {
					//如果有头像则显示
					posterConfig.images.push({
						width: 62,
						height: 62,
						x: 30,
						y: 30,
						borderRadius: 62,
						url: userInfo.headimgUrl
					});
					posterConfig.texts.push({
						x: 113,
						y: 61,
						baseLine: 'middle',
						text: userInfo.nickName,
						fontSize: 32,
						color: '#8d8d8d'
					});
				}
				this.posterConfig = posterConfig;
				this.posterShow = false;
				this.$refs.posterRef.onCreate(false, this.posterConfig); // 入参：true为抹掉重新生成
			},
			//点击保存到相册
			savePoster: function() {
				var that = this;
				uni.saveImageToPhotosAlbum({
					filePath: that.posterUrl,
					success(res) {
						that.posterShow = false;
						that.shareShow = '';
						uni.showModal({
							content: '图片已保存到相册，赶紧晒一下吧~',
							showCancel: false,
							confirmText: '好的',
							confirmColor: '#333',
							success: function(res) {
								if (res.confirm) {
									/* 该隐藏的隐藏 */
									that.shareShow = '';
								}
							},
							fail: function(res) {
								console.log(res);
							}
						});
					}
				});
			}
		}
	};
</script>
<style>
	.product-bg {
		width: 100%;
		position: relative;
	}

	.product-bg swiper {
		width: 100%;
		height: calc(100vw);
		position: relative;
	}

	.product-bg .page-index {
		position: absolute;
		right: 30rpx;
		bottom: 30rpx;
	}

	.cu-bar.tabbar.shop .action {
		width: unset;
	}

	.to-down {
		margin-bottom: 100rpx
	}

	.coupon{
		border-radius: 4rpx;
		padding: 8rpx 20rpx 8rpx 20rpx;
		background: radial-gradient(circle at bottom left, transparent 4px, #f9e7d4 0) top left,
		            radial-gradient(circle at bottom right, transparent 4px, #f9e7d4 0) top right,
		            radial-gradient(circle at top left, transparent 4px, #f9e7d4 0) bottom left,
		            radial-gradient(circle at top right, transparent 4px, #f9e7d4 0) bottom right;
		background-repeat: no-repeat;
		background-size: 51% 51%;
	}

	.show-bg{
		height: 84%;
		margin-top: 120rpx;
	}

	.image-box{
		height: 90%;
	}

	.show-btn{
		margin-top: -130rpx;
	}
</style>
