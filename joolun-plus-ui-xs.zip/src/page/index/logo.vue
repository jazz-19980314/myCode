<template>
  <div class="avue-logo" style="line-height: unset">
    <transition name="fade">
      <span v-if="keyCollapse"
            class="avue-logo_subtitle"
            key="0">

      </span>
    </transition>
    <transition-group name="fade">
      <template v-if="!keyCollapse">
        <span class="avue-logo_title" style="padding: 5px"
              key="1">
          <span style="font-size: 16px;text-align:left">{{tenantName}}</span><br>
          <span v-if="shopName" style="font-size: 4px;text-align:right">{{shopName}}</span>
        </span>
      </template>
    </transition-group>
  </div>
</template>

<script>
  import {mapGetters, mapState} from "vuex";
  import {getObj as getTenant} from '@/api/upms/tenant'
  import {getObj as getShopInfo} from '@/api/mall/shopinfo'

  export default {
    name: "logo",
    data() {
      return {
        tenantName: '',
        shopName: ''
      };
    },
    created() {
      getTenant(this.userInfo.tenantId).then(response =>  {
        this.tenantName = response.data.data.name
        if(this.userInfo.type == '2'){
          getShopInfo(this.userInfo.shopId).then(response =>  {
            this.shopName = response.data.data.name
          })
        }
      })
    },
    computed: {
      ...mapGetters(["keyCollapse"]),
      ...mapState({
        userInfo: state => state.user.userInfo
      }),
    },
    methods: {}
  };
</script>

<style lang="scss">
  .fade-leave-active {
    transition: opacity 0.2s;
  }

  .fade-enter-active {
    transition: opacity 2.5s;
  }

  .fade-enter,
  .fade-leave-to {
    opacity: 0;
  }

  .avue-logo {
    position: fixed;
    top: 0;
    left: 0;
    width: 220px;
    height: 50px;
    line-height: 50px;
    background-color: #20222a;
    font-size: 20px;
    overflow: hidden;
    box-sizing: border-box;
    box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.15);
    color: rgba(255, 255, 255, 0.8);
    z-index: 1024;

    &_title {
      display: block;
      text-align: center;
      font-weight: 300;
      font-size: 16px;
    }

    &_subtitle {
      display: block;
      text-align: center;
      font-size: 18px;
      font-weight: bold;
      color: #fff;
    }
  }
</style>
