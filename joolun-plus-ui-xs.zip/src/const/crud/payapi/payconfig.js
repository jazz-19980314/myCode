/**
 * Copyright (C) 2018-2019
 * All rights reserved, Designed By www.joolun.com
 * 注意：
 * 本软件为www.joolun.com开发研制，未经购买不得使用
 * 购买后可获得全部源代码（禁止转卖、分享、上传到码云、github等开源平台）
 * 一经发现盗用、分享等行为，将追究法律责任，后果自负
 */
export const tableOption = {
  dialogDrag: true,
  border: true,
  indexLabel: '序号',
  stripe: true,
  menuAlign: 'center',
  align: 'center',
  menuType: 'text',
  searchShow: false,
  excelBtn: true,
  printBtn: true,
  viewBtn: true,
  column: [
    {
      label: '支付类型',
      prop: 'type',
      search: true,
      sortable: true,
      editDisplay: false,
      slot: true,
      formslot: true,
      rules: [{
        required: true,
        message: '请选择支付类型',
        trigger: 'blur'
      }]
    },
    {
      label: 'appId',
      prop: 'appId',
      sortable: true,
      rules: [
        {
          required: true,
          message: '请输入appId',
          trigger: 'blur'
        },
        {
          max: 64,
          message: '长度在不能超过64个字符'
        },
      ],
      tip: '微信支付平台申请，不要乱填，否则商城将无法下单'
    },
    {
      label: '商户号',
      prop: 'mchId',
      sortable: true,
      rules: [
        {
          required: true,
          message: '请输入商户号',
          trigger: 'blur'
        },
        {
          max: 64,
          message: '长度在不能超过64个字符'
        },
      ],
      tip: '微信支付平台申请，不要乱填，否则商城将无法下单'
    },
    {
      label: '商户密钥',
      prop: 'mchKey',
      type:'password',
      rules: [
        {
          required: true,
          message: '请输入商户密钥',
          trigger: 'blur'
        },
        {
          max: 64,
          message: '长度在不能超过64个字符'
        },
      ],
      tip: '微信支付平台申请，不要乱填，否则商城将无法下单'
    },
    {
      label: 'apiV3证书序列号',
      prop: 'certSerialNo',
      sortable: true,
      rules: [
        {
          required: true,
          message: '请输入apiV3证书序列号',
          trigger: 'blur'
        },
        {
          max: 64,
          message: '长度在不能超过64个字符'
        },
      ],
      tip: '微信支付平台申请，不要乱填，否则商城将无法下单'
    },
    {
      label: 'apiV3秘钥',
      prop: 'apiV3Key',
      type:'password',
      rules: [
        {
          required: true,
          message: '请输入apiV3秘钥',
          trigger: 'blur'
        },
        {
          max: 64,
          message: '长度在不能超过64个字符'
        },
      ],
      tip: '微信支付平台申请，不要乱填，否则商城将无法下单'
    },
    {
      label: 'apiclient_cert.p12',
      prop: 'keyPath',
      sortable: true,
      rules: [
        {
          required: true,
          message: '请上传apiclient_cert.p12',
          trigger: 'blur'
        }],
      formslot: true,
      tip: '微信支付平台申请，不要乱填，否则商城退款功能将无法使用'
    },
    {
      label: 'apiclient_key.pem',
      prop: 'privateKeyPath',
      sortable: true,
      rules: [
        {
          required: true,
          message: '请上传apiclient_key.pem',
          trigger: 'blur'
        }],
      formslot: true,
      tip: '微信支付平台申请，不要乱填，否则商城退款功能将无法使用'
    },
    {
      label: 'apiclient_cert.pem',
      prop: 'privateCertPath',
      sortable: true,
      rules: [
        {
          required: true,
          message: '请上传apiclient_cert.pem',
          trigger: 'blur'
        }],
      formslot: true,
      tip: '微信支付平台申请，不要乱填，否则商城退款功能将无法使用'
    },
    {
      label: '微信开放平台移动应用APPID',
      prop: 'subAppId',
      sortable: true,
      rules: [
        {
          max: 64,
          message: '长度在不能超过64个字符'
        },
      ],
      tip: '微信开放平台申请移动应用，app端支付使用'
    },
  ]
}
