/**
 * Copyright (C) 2018-2019
 * All rights reserved, Designed By www.joolun.com
 * 注意：
 * 本软件为www.joolun.com开发研制，未经购买不得使用
 * 购买后可获得全部源代码（禁止转卖、分享、上传到码云、github等开源平台）
 * 一经发现盗用、分享等行为，将追究法律责任，后果自负
 */
export const tableOption = {
	dialogDrag: true,
	border: true,
	indexLabel: '序号',
	stripe: true,
	menuAlign: 'center',
	align: 'center',
	menuType: 'text',
	searchShow: false,
	excelBtn: true,
	printBtn: true,
	viewBtn: true,
	searchMenuSpan: 6,
	column: [{
			label: '商铺',
			prop: 'shopId',
			type:"select",
			sortable: true,
			rules: [{
					required: true,
					message: '请输入商铺ID',
					trigger: 'blur'
				},
				{
					max: 32,
					message: '长度在不能超过32个字符'
				},
			],
			props: {
			  label: 'name',
			  value: 'id'
			},
			dicUrl: '/mall/shopinfo/list',
			search:true
		},
		{
			label: '到账金额',
			prop: 'amount',
			type:"number",
			sortable: true,
			rules: [{
				required: true,
				message: '请输入提现金额',
				trigger: 'blur'
			}, ]
		},
		{
			label: '创建时间',
			prop: 'createTime',
			sortable: true,
			rules: []
		},
		{
			label: '更新时间',
			prop: 'updateTime',
			sortable: true,
			rules: []
		},
	]
}
