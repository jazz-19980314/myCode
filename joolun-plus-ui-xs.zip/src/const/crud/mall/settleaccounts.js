/**
 * Copyright (C) 2018-2019
 * All rights reserved, Designed By www.joolun.com
 * 注意：
 * 本软件为www.joolun.com开发研制，未经购买不得使用
 * 购买后可获得全部源代码（禁止转卖、分享、上传到码云、github等开源平台）
 * 一经发现盗用、分享等行为，将追究法律责任，后果自负
 */
var validatePass = (rule, value, callback) => {
	var pattern = /^[1-9]\d{9,29}$/;
	if (pattern.test(value)) {
		callback();
	} else {
		callback(new Error('请输入正确银行卡号'));
	}
};
export const tableOption = {
	dialogDrag: true,
	border: true,
	indexLabel: '序号',
	stripe: true,
	menuAlign: 'center',
	align: 'center',
	menuType: 'text',
	searchShow: false,
	excelBtn: true,
	printBtn: true,
	viewBtn: true,
	searchMenuSpan: 6,
	column: [{
			label: '申请时间',
			prop: 'createTime',
			sortable: true,
			rules: [],
			addDisplay: false,
			editDisabled: true,
		},
		{
			label: '审核时间',
			prop: 'updateTime',
			sortable: true,
			rules: [],
			addDisplay: false,
			editDisabled: true,
		},
		//0：审核中，1：通过；2：取消
		{
			label: '审核状态',
			prop: 'status',
			type: 'select',
			dicData: [{
				label: '审核中',
				value: 0
			}, {
				label: '通过',
				value: 1
			}, {
				label: '取消',
				value: 2
			}],
			value:0,
			sortable: true,
			rules: [],
			addDisplay: false,
		},
		{
			label: '提现金额',
			type: 'number',
			prop: 'amount',
			sortable: true,
			rules: [{
				required: true,
				message: '请输入提现金额',
				trigger: 'blur'
			}, ],
			editDisabled: true,
		},
		// {
		// 	label: '提现时余额',
		// 	prop: 'wallet',
		// 	sortable: true,
		// 	rules: [{
		// 		required: true,
		// 		message: '请输入提现时余额',
		// 		trigger: 'blur'
		// 	}, ]
		// },
		{
			label: '银行卡号',
			prop: 'bankCode',
			type: 'number',
			sortable: true,
			rules: [{
				required: true, 
				validator: validatePass,
				trigger: 'blur'
			}],
			editDisabled: true,
		},
		{
			label: '开户行',
			prop: 'bankName',
			sortable: true,
			rules: [{
					required: true,
					message: '请输入开户行',
					trigger: 'blur'
				}
			],
			editDisabled: true,
		},
		{
			label: '店铺',
			prop: 'shopId',
			type:"select",
			sortable: true,
			rules: [{
					required: true,
					message: '请输入店铺',
					trigger: 'blur'
				}
			],
			props: {
			  label: 'name',
			  value: 'id'
			},
			dicUrl: '/mall/shopinfo/list',
			editDisabled: true,
		},
		{
			label: '备注',
			prop: 'remark',
			sortable: true
		},
	]
}
