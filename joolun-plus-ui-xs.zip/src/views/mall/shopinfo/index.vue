<!--
  - Copyright (C) 2018-2019
  - All rights reserved, Designed By www.joolun.com
  - 注意：
  - 本软件为www.joolun.com开发研制，未经购买不得使用
  - 购买后可获得全部源代码（禁止转卖、分享、上传到码云、github等开源平台）
  - 一经发现盗用、分享等行为，将追究法律责任，后果自负
-->
<template>
  <div class="execution">
    <basic-container>
      <avue-crud ref="crud"
                 :page="page"
                 :data="tableData"
                 :permission="permissionList"
                 :table-loading="tableLoading"
                 :option="tableOption"
                 v-model="form"
                 :before-open="beforeOpen"
                 @on-load="getPage"
                 @refresh-change="refreshChange"
                 @row-update="handleUpdate"
                 @row-save="handleSave"
                 @row-del="handleDel"
                 @sort-change="sortChange"
                 @search-change="searchChange">
        <template slot-scope="scope" slot="menu">
          <el-button icon="el-icon-bank-card"
                     size="small"
                     type="text"
                     v-if="permissions['payapi:payapplyform:index']"
                     @click="payApplyForm(scope.row,scope.index)">微信支付账号申请（小微进件）
          </el-button>
        </template>
        <template slot="enable" slot-scope="scope">
          <el-switch
            active-value="1"
            inactive-value="0"
            v-model="scope.row.enable"
            active-color="#13ce66"
            inactive-color="#ff4949"
            @change="changeEnable(scope.row)">
          </el-switch>
        </template>
        <template slot="addressForm" slot-scope="scope">
          <div>
            <i class="el-icon-location"></i>{{scope.row.address}}
            <avue-input-map v-model="addressInfo" style="width:200px"></avue-input-map>
          </div>
        </template>
        <template slot="imgUrlForm"
                  slot-scope="scope">
          <div>
            <MaterialList v-model="scope.row.imgUrl" type="image" :shopId="form.id ? form.id : '-1'" :num=1 :width='150' :height=150></MaterialList>
            <p>推荐尺寸100*100</p>
          </div>
        </template>
        <template slot="imgUrl" slot-scope="scope">
          <img
            style="height: 100px"
            :src="scope.row.imgUrl">
        </template>
      </avue-crud>
      <el-dialog
        title="小微进件申请单"
        :visible.sync="dialogPayApplyForm"
        width="90%">
        <avue-crud ref="crud2"
                   :page="page2"
                   :data="tableData2"
                   :permission="permissionList2"
                   :table-loading="tableLoading2"
                   :option="tableOption2"
                   :before-open="beforeOpen2"
                   v-model="form2"
                   @on-load="getPage2"
                   @refresh-change="refreshChange2"
                   @row-update="handleUpdate2"
                   @row-save="handleSave2"
                   @row-del="handleDel2"
                   @sort-change="sortChange2"
                   @search-change="searchChange2"
                   v-if="dialogPayApplyForm">
          <template slot-scope="scope" slot="menu">
            <el-button icon="el-icon-bank-card"
                       size="small"
                       type="text"
                       v-if="permissions['payapi:payapplyform:submit']"
                       @click="payApplyFormSub(scope.row,scope.index)">提交申请
            </el-button>
            <el-button icon="el-icon-bank-card"
                       size="small"
                       type="text"
                       v-if="permissions['payapi:payapplyform:submit']"
                       @click="payApplyStatus(scope.row,scope.index)">更新申请状态
            </el-button>
          </template>
          <template slot-scope="scope" slot="contactInfo">
            {{scope.row.contactInfo.contact_name}}
          </template>
          <template slot-scope="scope" slot="auditDetail">
            {{scope.row.auditDetail.rejectReason}}
          </template>
          <template slot-scope="scope" slot="signUrl">
            <vue-qr v-if="scope.row.signUrl" :text="scope.row.signUrl" :size="160" :dotScale = 1></vue-qr>
          </template>
          <template slot-scope="scope" slot="contactInfoForm">
            <el-form ref="contactInfoForm" :model="contactInfo" label-width="180px">
              <el-form-item label="姓名">
                <el-input size="mini" v-model="contactInfo.contact_name"></el-input>
              </el-form-item>
              <el-form-item label="身份证号">
                <el-input size="mini" v-model="contactInfo.contact_id_number"></el-input>
              </el-form-item>
              <el-form-item label="联系手机">
                <el-input size="mini" v-model="contactInfo.mobile_phone"></el-input>
              </el-form-item>
              <el-form-item label="联系邮箱">
                <el-input size="mini" v-model="contactInfo.contact_email"></el-input>
              </el-form-item>
            </el-form>
          </template>
          <template slot-scope="scope" slot="subjectInfoForm">
            <el-form ref="subjectInfoForm" :model="subjectInfo" label-width="180px">
              <el-form-item label="主体类型">
                <el-select size="mini" v-model="subjectInfo.subject_type" placeholder="请选择">
                  <el-option
                    key="SUBJECT_TYPE_INDIVIDUAL"
                    label="个体户"
                    value="SUBJECT_TYPE_INDIVIDUAL">
                  </el-option>
                  <el-option
                    key="SUBJECT_TYPE_ENTERPRISE"
                    label="企业"
                    value="SUBJECT_TYPE_ENTERPRISE">
                  </el-option>
                </el-select>
              </el-form-item>
              <div>
                <div class="pay_bar">营业执照</div>
                <el-form-item label="营业执照">
                  <div class="el-upload__tip">{{subjectInfo.business_license_info.license_copy}}</div>
                  <el-upload
                    :action="actionUrl"
                    :headers="headers"
                    multiple
                    :limit="1"
                    :show-file-list="false"
                    :on-success="uploadSuccessLicenseCopy"
                    :on-error="uploadError">
                    <el-button type="primary">上传图片</el-button>
                    <div slot="tip" class="el-upload__tip">
                      请上传JPG、BMP、PNG文件
                    </div>
                  </el-upload>
                </el-form-item>
                <el-form-item label="社会信用代码">
                  <el-input size="mini" v-model="subjectInfo.business_license_info.license_number"></el-input>
                </el-form-item>
                <el-form-item label="商户名称">
                  <el-input size="mini" v-model="subjectInfo.business_license_info.merchant_name"></el-input>
                </el-form-item>
                <el-form-item label="法人姓名">
                  <el-input size="mini" v-model="subjectInfo.business_license_info.legal_person"></el-input>
                </el-form-item>
              </div>
<!--              <div v-if="subjectInfo.subject_type == 'SUBJECT_TYPE_ENTERPRISE'">-->
              <div>
                <div class="pay_bar">组织机构代码证</div>
                <el-form-item label="组织机构代码证">
                  <div class="el-upload__tip">{{subjectInfo.organization_info.organization_copy}}</div>
                  <el-upload
                    :action="actionUrl"
                    :headers="headers"
                    multiple
                    :limit="1"
                    :show-file-list="false"
                    :on-success="uploadSuccessOrganizationCopy"
                    :on-error="uploadError">
                    <el-button type="primary">上传图片</el-button>
                    <div slot="tip" class="el-upload__tip">
                      请上传JPG、BMP、PNG文件
                    </div>
                  </el-upload>
                </el-form-item>
                <el-form-item label="组织机构代码">
                  <el-input size="mini" v-model="subjectInfo.organization_info.organization_code"></el-input>
                </el-form-item>
                <el-form-item label="有效期开始日期">
                  <el-date-picker
                    v-model="subjectInfo.organization_info.org_period_begin"
                    type="date"
                    format="yyyy-MM-dd"
                    valueFormat="yyyy-MM-dd"
                    placeholder="选择日期">
                  </el-date-picker>
                </el-form-item>
                <el-form-item label="有效期结束日期">
                  <el-date-picker
                    v-model="subjectInfo.organization_info.org_period_end"
                    type="date"
                    format="yyyy-MM-dd"
                    valueFormat="yyyy-MM-dd"
                    placeholder="选择日期">
                  </el-date-picker>
                </el-form-item>
              </div>
              <div>
                <div class="pay_bar">身份证</div>
                <el-form-item label="证件类型">
                  <el-select size="mini" v-model="subjectInfo.identity_info.id_doc_type" placeholder="请选择">
                    <el-option
                      key="IDENTIFICATION_TYPE_IDCARD"
                      label="中国大陆居民-身份证"
                      value="IDENTIFICATION_TYPE_IDCARD">
                    </el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="身份证人像面">
                  <div class="el-upload__tip">{{subjectInfo.identity_info.id_card_info.id_card_copy}}</div>
                  <el-upload
                    :action="actionUrl"
                    :headers="headers"
                    multiple
                    :limit="1"
                    :show-file-list="false"
                    :on-success="uploadSuccessIdCardCopy"
                    :on-error="uploadError">
                    <el-button type="primary">上传图片</el-button>
                    <div slot="tip" class="el-upload__tip">
                      请上传JPG、BMP、PNG文件
                    </div>
                  </el-upload>
                </el-form-item>
                <el-form-item label="身份证国徽面">
                  <div class="el-upload__tip">{{subjectInfo.identity_info.id_card_info.id_card_national}}</div>
                  <el-upload
                    :action="actionUrl"
                    :headers="headers"
                    multiple
                    :limit="1"
                    :show-file-list="false"
                    :on-success="uploadSuccessIdCardNational"
                    :on-error="uploadError">
                    <el-button type="primary">上传图片</el-button>
                    <div slot="tip" class="el-upload__tip">
                      请上传JPG、BMP、PNG文件
                    </div>
                  </el-upload>
                </el-form-item>
                <el-form-item label="身份证姓名">
                  <el-input size="mini" v-model="subjectInfo.identity_info.id_card_info.id_card_name"></el-input>
                </el-form-item>
                <el-form-item label="身份证号码">
                  <el-input size="mini" v-model="subjectInfo.identity_info.id_card_info.id_card_number"></el-input>
                </el-form-item>
                <el-form-item label="有效期开始时间">
                  <el-date-picker
                    v-model="subjectInfo.identity_info.id_card_info.card_period_begin"
                    type="date"
                    format="yyyy-MM-dd"
                    valueFormat="yyyy-MM-dd"
                    placeholder="选择日期">
                  </el-date-picker>
                </el-form-item>
                <el-form-item label="有效期结束时间">
                  <el-date-picker
                    v-model="subjectInfo.identity_info.id_card_info.card_period_end"
                    type="date"
                    format="yyyy-MM-dd"
                    valueFormat="yyyy-MM-dd"
                    placeholder="选择日期">
                  </el-date-picker>
                </el-form-item>
              </div>
              <el-form-item label="法人是否为受益人">
                <el-select size="mini" v-model="subjectInfo.identity_info.owner" placeholder="请选择">
                  <el-option
                    key="true"
                    label="是"
                    value="true">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-form>
          </template>
          <template slot-scope="scope" slot="businessInfoForm">
            <el-form ref="businessInfoForm" :model="businessInfo" label-width="180px">
              <el-form-item label="商户简称">
                <el-input size="mini" v-model="businessInfo.merchant_shortname"></el-input>
              </el-form-item>
              <el-form-item label="客服电话">
                <el-input size="mini" v-model="businessInfo.service_phone"></el-input>
              </el-form-item>
              <el-form-item label="经营场景类型">
                <el-checkbox-group v-model="businessInfo.sales_info.sales_scenes_type">
                  <el-checkbox label="SALES_SCENES_MP" value="SALES_SCENES_MP">公众号</el-checkbox>
                  <el-checkbox label="SALES_SCENES_MINI_PROGRAM" value="SALES_SCENES_MINI_PROGRAM">小程序</el-checkbox>
                  <el-checkbox label="SALES_SCENES_WEB" value="SALES_SCENES_WEB">互联网</el-checkbox>
                  <el-checkbox label="SALES_SCENES_APP" value="SALES_SCENES_APP">APP</el-checkbox>
                </el-checkbox-group>
              </el-form-item>
              <div v-if="businessInfo.sales_info.sales_scenes_type.indexOf('SALES_SCENES_MP') > -1">
                <div class="pay_bar">公众号场景</div>
                <el-form-item label="服务商公众号APPID">
                  <el-input size="mini" v-model="businessInfo.sales_info.mp_info.mp_appid"></el-input>
                </el-form-item>
              </div>
              <div v-if="businessInfo.sales_info.sales_scenes_type.indexOf('SALES_SCENES_MINI_PROGRAM') > -1">
                <div class="pay_bar">小程序场景</div>
                <el-form-item label="服务商小程序APPID">
                  <el-input size="mini" v-model="businessInfo.sales_info.mini_program_info.mini_program_appid"></el-input>
                </el-form-item>
              </div>
              <div v-if="businessInfo.sales_info.sales_scenes_type.indexOf('SALES_SCENES_WEB') > -1">
                <div class="pay_bar">互联网网站场景</div>
                <el-form-item label="互联网网站域名">
                  <el-input size="mini" v-model="businessInfo.sales_info.web_info.domain"></el-input>
                </el-form-item>
              </div>
              <div v-if="businessInfo.sales_info.sales_scenes_type.indexOf('SALES_SCENES_APP') > -1">
                <div class="pay_bar">APP场景</div>
                <el-form-item label="服务商应用APPID">
                  <el-input size="mini" v-model="businessInfo.sales_info.app_info.app_appid"></el-input>
                </el-form-item>
                <el-form-item label="APP截图">
                  <el-tooltip class="item" effect="dark" content="请提供APP首页截图、尾页截图、应用内截图、支付页截图各1张" placement="top-start">
                    <i class="el-icon-info"></i>
                  </el-tooltip>
                  <div class="el-upload__tip" v-for="(item,index) in businessInfo.sales_info.app_info.app_pics" :key="index">
                    {{item}}<el-link type="danger" @click="appPicsDel(index)" style="margin-left: 5px">删除</el-link>
                  </div>
                  <el-upload
                    :action="actionUrl"
                    :headers="headers"
                    multiple
                    :limit="5"
                    :show-file-list="false"
                    :on-success="uploadSuccessAppPics"
                    :on-error="uploadError">
                    <el-button type="primary">上传图片</el-button>
                    <div slot="tip" class="el-upload__tip">
                      请上传JPG、BMP、PNG文件
                    </div>
                  </el-upload>
                </el-form-item>
              </div>
            </el-form>
          </template>
          <template slot-scope="scope" slot="settlementInfoForm">
            <el-form ref="settlementInfoForm" :model="settlementInfo" label-width="180px">
              <el-form-item label="入驻结算规则">
                <el-tooltip class="item" effect="dark" content="请参考https://pay.weixin.qq.com/wiki/doc/apiv3/wxpay/ecommerce/applyments/chapter4_1.shtml" placement="top-start">
                  <i class="el-icon-info"></i>
                </el-tooltip>
                <el-input size="mini" v-model="settlementInfo.settlement_id"></el-input>
              </el-form-item>
              <el-form-item label="所属行业">
                <el-tooltip class="item" effect="dark" content="请参考https://pay.weixin.qq.com/wiki/doc/apiv3/wxpay/ecommerce/applyments/chapter4_1.shtml" placement="top-start">
                  <i class="el-icon-info"></i>
                </el-tooltip>
                <el-input size="mini" v-model="settlementInfo.qualification_type"></el-input>
              </el-form-item>
            </el-form>
          </template>
        </avue-crud>
      </el-dialog>
    </basic-container>
  </div>
</template>

<script>
  import {getPage, getObj, addObj, putObj, delObj} from '@/api/mall/shopinfo'
  import {getPage as getPage2, getObj as getObj2, addObj as addObj2, putObj as putObj2, delObj as delObj2, subObj, statusObj} from '@/api/payapi/payapplyform'
  import {tableOption} from '@/const/crud/mall/shopinfo'
  import {tableOption as tableOption2} from '@/const/crud/payapi/payapplyform'
  import MaterialList from '@/components/material/list.vue'
  import {mapGetters} from 'vuex'
  import store from "@/store"

  export default {
    components: {
      MaterialList
    },
    name: 'shopinfo',
    data() {
      return {
        form: {},
        tableData: [],
        page: {
          total: 0, // 总页数
          currentPage: 1, // 当前页数
          pageSize: 20, // 每页显示多少条
          ascs: [],//升序字段
          descs: []//降序字段
        },
        paramsSearch: {},
        tableLoading: false,
        tableOption: tableOption,
        addressInfo: [],
        dialogPayApplyForm: false,
        shopIdSelect: null,
        form2: {},
        tableData2: [],
        page2: {
          total: 0, // 总页数
          currentPage: 1, // 当前页数
          pageSize: 20, // 每页显示多少条
          ascs: [],//升序字段
          descs: []//降序字段
        },
        paramsSearch2: {},
        tableLoading2: false,
        tableOption2: tableOption2,
        contactInfo: {},
        subjectInfo: {
          business_license_info: {},
          organization_info: {},
          identity_info: {
            id_card_info: {}
          }
        },
        businessInfo: {
          sales_info: {
            sales_scenes_type: [],
            mp_info: {},
            mini_program_info: {},
            app_info: {
              app_pics: []
            },
            web_info: {}
          }
        },
        settlementInfo: {},
        actionUrl: '/payapi/payapplyform/imageUploadV3',
        headers: {
          Authorization: 'Bearer ' + store.getters.access_token
        }
      }
    },
    created() {
    },
    mounted: function () {
    },
    watch: {
      addressInfo: {
        deep: true,
        immediate: true,
        handler(newSkus, oldSkus) {
          this.form.address = newSkus[2]
        }
      }
    },
    computed: {
      ...mapGetters(['permissions']),
      permissionList() {
        return {
          addBtn: this.permissions['mall:shopinfo:add'] ? true : false,
          delBtn: this.permissions['mall:shopinfo:del'] ? true : false,
          editBtn: this.permissions['mall:shopinfo:edit'] ? true : false,
          viewBtn: this.permissions['mall:shopinfo:get'] ? true : false
        };
      },
      permissionList2() {
        return {
          addBtn: this.permissions['payapi:payapplyform:add'] ? true : false,
          delBtn: this.permissions['payapi:payapplyform:del'] ? true : false,
          editBtn: this.permissions['payapi:payapplyform:edit'] ? true : false,
          viewBtn: this.permissions['payapi:payapplyform:get'] ? true : false
        };
      }
    },
    methods: {
      appPicsDel(index){
        this.businessInfo.sales_info.app_info.app_pics.splice(index, 1)
      },
      uploadError(err, file, fileList){
        this.$message.error('上传出错：' + err)
      },
      uploadSuccessLicenseCopy(response){
        console.log('营业执照')
        this.subjectInfo.business_license_info.license_copy = response.data.mediaId
      },
      uploadSuccessOrganizationCopy(response){
        console.log('组织机构代码证')
        this.subjectInfo.organization_info.organization_copy = response.data.mediaId
      },
      uploadSuccessIdCardCopy(response){
        console.log('身份证人像面')
        this.subjectInfo.identity_info.id_card_info.id_card_copy = response.data.mediaId
      },
      uploadSuccessIdCardNational(response){
        console.log('身份证国徽面')
        this.subjectInfo.identity_info.id_card_info.id_card_national = response.data.mediaId
      },
      uploadSuccessAppPics(response){
        console.log('APP截图')
        this.businessInfo.sales_info.app_info.app_pics.push(response.data.mediaId)
      },
      payApplyForm(row, index, done){
        this.tableData2 = []
        this.dialogPayApplyForm = false//销毁组件
        this.$nextTick(() => {
          this.dialogPayApplyForm = true//重建组件
        })
        this.shopIdSelect = row.id
      },
      beforeOpen(done,type){
        if(type == 'add'){
          this.form.imgUrl = []
        }else{
          this.form.imgUrl = [this.form.imgUrl]
          this.addressInfo = [this.form.longitude, this.form.latitude, this.form.address]
        }
        done()
      },
      changeEnable(row){
        putObj({
          id: row.id,
          enable: row.enable
        }).then(data => {

        })
      },
      searchChange(params, done) {
        params = this.filterForm(params)
        this.paramsSearch = params
        this.page.currentPage = 1
        this.getPage(this.page, params)
        done()
      },
      sortChange(val) {
        let prop = val.prop ? val.prop.replace(/([A-Z])/g, "_$1").toLowerCase() : ''
        if (val.order == 'ascending') {
          this.page.descs = []
          this.page.ascs = prop
        } else if (val.order == 'descending') {
          this.page.ascs = []
          this.page.descs = prop
        } else {
          this.page.ascs = []
          this.page.descs = []
        }
        this.getPage(this.page)
      },
      getPage(page, params) {
        this.tableLoading = true
        getPage(Object.assign({
          current: page.currentPage,
          size: page.pageSize,
          descs: this.page.descs,
          ascs: this.page.ascs,
        }, params, this.paramsSearch)).then(response => {
          this.tableData = response.data.data.records
          this.page.total = response.data.data.total
          this.page.currentPage = page.currentPage
          this.page.pageSize = page.pageSize
          this.tableLoading = false
        }).catch(() => {
          this.tableLoading = false
        })
      },
      /**
       * @title 数据删除
       * @param row 为当前的数据
       * @param index 为当前删除数据的行数
       *
       **/
      handleDel: function (row, index) {
        let _this = this
        this.$confirm('是否确认删除此数据', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(function () {
          return delObj(row.id)
        }).then(data => {
          _this.$message({
            showClose: true,
            message: '删除成功',
            type: 'success'
          })
          this.getPage(this.page)
        }).catch(function (err) {
        })
      },
      /**
       * @title 数据更新
       * @param row 为当前的数据
       * @param index 为当前更新数据的行数
       * @param done 为表单关闭函数
       *
       **/
      handleUpdate: function (row, index, done, loading) {
        row.imgUrl = row.imgUrl.length > 0 ? row.imgUrl[0] : ''
        let addressInfo = this.addressInfo
        row.longitude = addressInfo[0]
        row.latitude = addressInfo[1]
        row.address = addressInfo[2]
        putObj(row).then(response => {
          this.$message({
            showClose: true,
            message: '修改成功',
            type: 'success'
          })
          done()
          this.getPage(this.page)
        }).catch(() => {
          loading()
        })
      },
      /**
       * @title 数据添加
       * @param row 为当前的数据
       * @param done 为表单关闭函数
       *
       **/
      handleSave: function (row, done, loading) {
        row.imgUrl = row.imgUrl.length > 0 ? row.imgUrl[0] : ''
        let addressInfo = this.addressInfo
        row.longitude = addressInfo[0]
        row.latitude = addressInfo[1]
        row.address = addressInfo[2]
        addObj(row).then(response => {
          this.$message({
            showClose: true,
            message: '添加成功',
            type: 'success'
          })
          done()
          this.getPage(this.page)
        }).catch(() => {
          loading()
        })
      },
      /**
       * 刷新回调
       */
      refreshChange(page) {
        this.getPage(this.page)
      },
      beforeOpen2(done,type){
        if(type == 'edit'){
          this.contactInfo =  this.form2.contactInfo
          this.subjectInfo = this.form2.subjectInfo
          this.businessInfo = this.form2.businessInfo
          this.settlementInfo = this.form2.settlementInfo
        }
        done()
      },
      searchChange2(params, done) {
        params = this.filterForm(params)
        this.paramsSearch2 = params
        this.page2.currentPage = 1
        this.getPage2(this.page2, params)
        done()
      },
      sortChange2(val) {
        let prop = val.prop ? val.prop.replace(/([A-Z])/g, "_$1").toLowerCase() : ''
        if (val.order == 'ascending') {
          this.page2.descs = []
          this.page2.ascs = prop
        } else if (val.order == 'descending') {
          this.page2.ascs = []
          this.page2.descs = prop
        } else {
          this.page2.ascs = []
          this.page2.descs = []
        }
        this.getPage2(this.page2)
      },
      getPage2(page, params) {
        if(this.shopIdSelect){
          this.tableLoading2 = true
          getPage2(Object.assign({
            current: page.currentPage,
            size: page.pageSize,
            descs: this.page2.descs,
            ascs: this.page2.ascs,
            shopId: this.shopIdSelect
          }, params, this.paramsSearch2)).then(response => {
            this.tableData2 = response.data.data.records
            this.page2.total = response.data.data.total
            this.page2.currentPage = page.currentPage
            this.page2.pageSize = page.pageSize
            this.tableLoading2 = false
          }).catch(() => {
            this.tableLoading2 = false
          })
        }
      },
      /**
       * @title 数据删除
       * @param row 为当前的数据
       * @param index 为当前删除数据的行数
       *
       **/
      handleDel2: function (row, index) {
        let _this = this
        this.$confirm('是否确认删除此数据', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(function () {
          return delObj2(row.id)
        }).then(data => {
          _this.$message({
            showClose: true,
            message: '删除成功',
            type: 'success'
          })
          this.getPage2(this.page2)
        }).catch(function (err) {
        })
      },
      /**
       * @title 数据更新
       * @param row 为当前的数据
       * @param index 为当前更新数据的行数
       * @param done 为表单关闭函数
       *
       **/
      handleUpdate2: function (row, index, done, loading) {
        row.shopId = this.shopIdSelect
        row.contactInfo = this.contactInfo
        row.subjectInfo = this.subjectInfo
        row.businessInfo = this.businessInfo
        row.settlementInfo = this.settlementInfo
        putObj2(row).then(response => {
          this.$message({
            showClose: true,
            message: '修改成功',
            type: 'success'
          })
          done()
          this.getPage2(this.page2)
        }).catch(() => {
          loading()
        })
      },
      /**
       * @title 数据添加
       * @param row 为当前的数据
       * @param done 为表单关闭函数
       *
       **/
      handleSave2: function (row, done, loading) {
        row.shopId = this.shopIdSelect
        row.contactInfo = this.contactInfo
        row.subjectInfo = this.subjectInfo
        row.businessInfo = this.businessInfo
        row.settlementInfo = this.settlementInfo
        row.auditDetail = {}
        addObj2(row).then(response => {
          this.$message({
            showClose: true,
            message: '添加成功',
            type: 'success'
          })
          done()
          this.getPage2(this.page2)
        }).catch(() => {
          loading()
        })
      },
      /**
       * 刷新回调
       */
      refreshChange2(page) {
        this.getPage2(this.page2)
      },
      payApplyFormSub(row, index, done){
        this.tableLoading2 = true
        subObj(row).then(response => {
          this.tableLoading2 = false
          this.$message({
            showClose: true,
            message: '提交成功',
            type: 'success'
          })
          this.getPage2(this.page2)
        }).catch(() => {
        })
      },
      payApplyStatus(row, index, done){
        this.tableLoading2 = true
        statusObj(row).then(response => {
          this.tableLoading2 = false
          this.$message({
            showClose: true,
            message: '更新成功',
            type: 'success'
          })
          this.getPage2(this.page2)
        }).catch(() => {
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .pay_bar{
    text-align: center;
    font-size: large;
    font-weight: bold;
  }
</style>
