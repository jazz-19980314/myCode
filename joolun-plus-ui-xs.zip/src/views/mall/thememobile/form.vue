<!--
  - Copyright (C) 2018-2019
  - All rights reserved, Designed By www.joolun.com
  - 注意：
  - 本软件为www.joolun.com开发研制，未经购买不得使用
  - 购买后可获得全部源代码（禁止转卖、分享、上传到码云、github等开源平台）
  - 一经发现盗用、分享等行为，将追究法律责任，后果自负
-->
<template>
  <div class="execution">
    <basic-container>
      <div>
        <el-row :gutter="20">
          <el-col :span="16">

            <el-tabs v-model="activeName" @tab-click="activeName==$event.name">
              <el-tab-pane label="主题设置" name="name1"></el-tab-pane>
              <el-tab-pane label="首页轮播图设置" name="name2"></el-tab-pane>
              <el-tab-pane label="公告设置" name="name3"></el-tab-pane>
              <el-tab-pane label="导航设置" name="name4"></el-tab-pane>
              <el-tab-pane label="首页底部TabBar设置" name="name5"></el-tab-pane>
            </el-tabs>

            <!-- 主题设置 -->
            <div v-show="activeName=='name1'">
              <el-form ref="form" :model="form" label-width="0px" :rules="rules">
                <el-row>
                  <el-col :span="12" style="padding-left: 20px; margin-top: 50px;">
                    <div style="font-size: 16px;color: #303133;">背景颜色</div>
                    <div style="font-size: 12px;color: #909399;">（导航栏、模块背景色值，可支持渐变色）</div>
                  </el-col>
                  <el-col :span="12" style="margin-top: 50px; margin-left: -100px;">
                    <el-form-item label="" prop="backgroundColor">
                      <el-tooltip effect="dark" content="colorUI中的类名" placement="top">
                        <el-input v-model="form.backgroundColor" size="small" @focus="appTheme.bgType='background',appTheme.showBgDialog=true">
                          <template slot="append">
                            <div style="background:#fff;width: 24px;padding-left: 5px;">
                              <div :class="'bg-' + form.backgroundColor" style="height: 20px;width: 20px;float: left;"></div>
                            </div>
                          </template>
                        </el-input>
                      </el-tooltip>
                    </el-form-item>
                  </el-col>

                  <el-col :span="12" style="padding-left: 20px; margin-top: 20px;">
                    <div style="font-size: 16px;color: #303133;">主题颜色</div>
                    <div style="font-size: 12px;color: #909399;">（页面中图标、按钮、元素色值，暂不支持渐变色）</div>
                  </el-col>
                  <el-col :span="12" style="margin-top: 20px; margin-left: -100px;">
                    <el-form-item label="" prop="themeColor">
                      <el-tooltip effect="dark" content="colorUI中的类名" placement="top">
                        <el-input v-model="form.themeColor" size="small" @focus="appTheme.bgType='theme',appTheme.showBgDialog=true">
                          <template slot="append">
                            <div style="background:#fff;width: 24px;padding-left: 5px;">
                              <div :class="'bg-' + form.themeColor" style="height: 20px;width: 20px;float: left;"></div>
                            </div>
                          </template>
                        </el-input>
                      </el-tooltip>
                    </el-form-item>
                  </el-col>

                  <el-col :span="12" style="padding-left: 20px; margin-top: 20px;">
                    <div style="font-size: 16px;color: #303133;">tabBar文字颜色</div>
                  </el-col>
                  <el-col :span="12" style="margin-top: 20px; margin-left: -100px;">
                    <el-form-item label="" prop="tabbarColor">
                      <el-tooltip effect="dark" content="色值代码，如#ffffff" placement="top">
                        <el-input v-model="form.tabbarColor" size="small">
                          <template slot="append">
                            <el-color-picker size="mini" v-model="form.tabbarColor"></el-color-picker>
                          </template>
                        </el-input>
                      </el-tooltip>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12" style="padding-left: 20px; margin-top: 20px;">
                    <div style="font-size: 16px;color: #303133;">tabBar文字选中颜色</div>
                  </el-col>
                  <el-col :span="12" style="margin-top: 20px; margin-left: -100px;">
                    <el-form-item label="" prop="tabbarSelectedColor">
                      <el-tooltip effect="dark" content="色值代码，如#ffffff" placement="top">
                        <el-input v-model="form.tabbarSelectedColor" size="small">
                          <template slot="append">
                            <el-color-picker size="mini" v-model="form.tabbarSelectedColor"></el-color-picker>
                          </template>
                        </el-input>
                      </el-tooltip>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12" style="padding-left: 20px; margin-top: 20px;">
                    <div style="font-size: 16px;color: #303133;">tabBar背景色</div>
                  </el-col>
                  <el-col :span="12" style="margin-top: 20px; margin-left: -100px;">
                    <el-form-item label="" prop="tabbarBackgroundColor">
                      <el-tooltip effect="dark" content="色值代码，如#ffffff" placement="top">
                        <el-input v-model="form.tabbarBackgroundColor" size="small">
                          <template slot="append">
                            <el-color-picker size="mini" v-model="form.tabbarBackgroundColor"></el-color-picker>
                          </template>
                        </el-input>
                      </el-tooltip>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12" style="padding-left: 20px; margin-top: 20px;">
                    <div style="font-size: 16px;color: #303133;">tabBar上边框颜色</div>
                  </el-col>
                  <el-col :span="12" style="margin-top: 20px; margin-left: -100px;">
                    <el-form-item label="" prop="tabbarBorderStyle">
                      <el-tooltip effect="dark" content="请选择tabBar上边框颜色" placement="top">
                        <el-select size="small" style="width: 100%;" v-model="form.tabbarBorderStyle" placeholder="请选择tabBar上边框颜色">
                          <el-option label="黑色" value="black"></el-option>
                          <el-option label="白色" value="white"></el-option>
                        </el-select>
                      </el-tooltip>
                    </el-form-item>
                  </el-col>
                </el-row>

              </el-form>
            </div>

            <!-- 轮播图设置 -->
            <div v-show="activeName=='name2'">
              <div style="margin-bottom: 30px;">
                <el-button type="primary" icon="el-icon-plus" @click="onAddNoticeItemButton(index)">新增</el-button>
                <div style="font-size: 12px; color: #666666; margin: -30px 0 0 100px; color: #ff0000;">*轮播图片建议尺寸（620x180）px</div>
              </div>
              <el-row>
                <el-col :span="12" v-for="(item,index) in noticeItemList" :key="index">
                  <div :style="{background: noticeItemCurIndex==index?'#efefef':''}" style="width: 340px;">
                    <div>
                      <el-image :src="item.url?item.url[0]:item.url" style="float:left;padding-top:11px;width: 100%;height: 88px;"></el-image>
                    </div>
                    <div style="margin-top:5px; width: 340px;">
                      <el-tooltip effect="dark" content="前端页面跳转地址路径url" placement="top">
                        <el-input v-model="item.page" disabled style="margin-top: 5px;" size="small" placeholder="页面跳转地址路径的url"></el-input>
                      </el-tooltip>
                    </div>
                    <div style="margin-top: 10px;">
                      <el-tooltip effect="dark" content="是否启用" placement="top">
                        <el-switch v-model="item.enable" @change="onChangeNoticeItemButton(item)" active-value="1"
                                   inactive-value="0" active-color="#13ce66" inactive-color="#ff4949">
                        </el-switch>
                      </el-tooltip>
                      <el-tooltip effect="dark" content="编辑" placement="top">
                        <el-button type="primary" size="mini" style="margin-left: 10px;" icon="el-icon-edit" circle
                                   @click="onEditNoticeItemButton(item, index)"></el-button>
                      </el-tooltip>
                      <el-tooltip effect="dark" content="删除" placement="top">
                        <el-button type="danger" size="mini" icon="el-icon-delete" circle @click="onDelNoticeItemButton(item, index)"></el-button>
                      </el-tooltip>
                      <el-button type="primary" icon="el-icon-bottom" @click="onSortBottom(noticeItemList,index, 'noticeItem')"
                                 :disabled="index===noticeItemList.length-1" size="mini" circle></el-button>
                      <el-button icon="el-icon-top" type="primary" @click="onSortTop(noticeItemList,index, 'noticeItem')"
                                 :disabled="index===0" size="mini" circle></el-button>
                    </div>
                  </div>
                </el-col>
              </el-row>
            </div>

            <!-- 公告 -->
            <div v-show="activeName=='name3'">
              <el-button type="primary" icon="el-icon-plus" @click="onAddNoticeTextButton(index)">新增</el-button>
              <el-row style="margin-top: 10px;">
                <el-col :span="24" v-for="(item, index) in noticeTextList" :key="index" :style="{background: noticeTextCurIndex==index?'#efefef':''}"
                        style="padding: 5px 0;">
                  <div style="margin-top: 20px;">
                    <!--显示图标-->
                    <div>
                      <div style="float:left;text-align: center; width:64px; height:64px; border: #cccccc 1px solid; margin-right: 10px; color: #E6A23C; border-radius: 5px;">
                        <el-icon class="el-icon-message-solid" style="margin-top: 20px;"></el-icon>
                        <el-tag size="mini" type="warning">{{item.tag}}</el-tag>
                      </div>
                      <div style="float: left;margin-right: 10px; width: 500px;">
                        <el-input size="small" type="textarea" disabled v-model="item.content" placeholder="公告内容"></el-input>
                        <!--url-->
                        <el-input size="small" style="margin-top: 5px;" disabled v-model="item.page" placeholder="跳转地址url"></el-input>
                        <!--文字-->
                      </div>
                    </div>
                    <div style="float:left;line-height:4;margin-left: 20px;">
                      <el-tooltip effect="dark" content="是否启用" placement="top">
                        <el-switch v-model="item.enable" active-value="1" @change="onChangeNoticeTextButton(item)"
                                   inactive-value="0" active-color="#13ce66" inactive-color="#ff4949">
                        </el-switch>
                      </el-tooltip>

                      <el-tooltip effect="dark" content="编辑" placement="top">
                        <el-button type="primary" style="margin-left: 10px;" size="mini" icon="el-icon-edit" circle
                                   @click="onEditNoticeTextButton(item, index)"></el-button>
                      </el-tooltip>
                      <el-tooltip effect="dark" content="删除" placement="top">
                        <el-button type="danger" size="mini" icon="el-icon-delete" circle @click="onDelNoticeTextButton(item, index)"></el-button>
                      </el-tooltip>
                      <el-button icon="el-icon-bottom" type="primary" @click="onSortBottom(noticeTextList, index, 'noticeText')"
                                 :disabled="index===noticeTextList.length-1" size="mini" circle></el-button>
                      <el-button icon="el-icon-top" type="primary" @click="onSortTop(noticeTextList, index, 'noticeText')"
                                 :disabled="index===0" size="mini" circle></el-button>
                    </div>
                  </div>
                </el-col>
              </el-row>
            </div>

            <!-- 首页中间导航按钮 -->
            <div v-show="activeName=='name4'">
              <div style="margin-bottom: 30px;">
                <el-button type="primary" icon="el-icon-plus" @click="navButtonModal=true">新增</el-button>
                <div style="font-size: 12px; color: #666666; margin: -30px 0 0 100px; color: #ff0000;">*图片/icon建议尺寸（60x60）px</div>
              </div>
              <el-form style="margin-top: 10px;"  :model="form" label-width="150px" @submit="handleUpdate"
                       v-if="form.navButton&&form.navButton.info.length>0">
                <div v-for="(item, index) in form.navButton.info" :key="index">
                  <el-form-item label-width="0px" style="padding: 5px;" :style="{background: navButtonCurIndex==index?'#efefef':''}">
                    <div>
                      <!--显示图标-->
                      <div style="float:left;margin-right: 10px;">
                        <MaterialList :value="item.img?[item.img]:[]" @sureSuccess="item.img = $event?$event[0]:''" @deleteMaterial="item.img = ''"
                                      type="image" shopId="-1" :num=1 :width=60 :height=60 style="float:left;padding-top:11px"></MaterialList>
                      </div>
                      <div style="float: left;margin-right: 10px;width: 70%;">
                        <!--文字-->
                        <el-tooltip effect="dark" content="名称" placement="top">
                          <el-input size="small" v-model="item.name" placeholder="请输入名称"></el-input>
                        </el-tooltip>
                        <!--url-->
                        <el-tooltip effect="dark" content="跳转的页面" placement="top">
                          <div>
                            <app-page-select :page="item.url" @change="item.url=$event"></app-page-select>
                          </div>
                        </el-tooltip>
                      </div>
                      <div style="float: left; line-height: 5.5;">
                        <el-button icon="el-icon-bottom" type="primary" @click="onSortBottom(form.navButton.info, index)"
                                   :disabled="index===form.navButton.info.length-1" size="mini" circle></el-button>
                        <el-button icon="el-icon-top" type="primary" @click="onSortTop(form.navButton.info, index)"
                                   :disabled="index===0" size="mini" circle></el-button>
                        <!-- <el-button type="primary"  size="mini" icon="el-icon-plus" circle @click="onAddNavButton(index)"></el-button> -->
                        <el-button type="danger" size="mini" icon="el-icon-delete" circle @click="onDeleteButton(form.navButton.info, index)"></el-button>
                      </div>
                    </div>
                  </el-form-item>
                </div>
              </el-form>
              <div v-else style="width: 100%;text-align: center; color:#aaaaaa; font-size: 13px;">
                暂无数据
              </div>
            </div>

            <!-- 新增弹框 首页中间导航按钮 -->
            <el-dialog title="新增导航按钮" :visible.sync="navButtonModal">
              <el-form :model="navButtonForm" ref="navButtonForm" label-width="100px">
                <el-form-item label="图片"  prop="img" :rules="[{ required: true, message: '不能为空', trigger: ['blur', 'change']}]">
                  <MaterialList :value="navButtonForm.img?[navButtonForm.img]:[]"
                                @sureSuccess="navButtonForm.img = $event?$event[0]:''"
                                @deleteMaterial="navButtonForm.img = ''"
                                type="image" shopId="-1" :num=1 :width=60 :height=60 ></MaterialList>
                </el-form-item>
                <el-form-item label="名称"  prop="name" :rules="[{ required: true, message: '不能为空'}]">
                  <el-input size="small" v-model="navButtonForm.name" placeholder="请输入名称"></el-input>
                </el-form-item>
                <el-form-item label="跳转的页面" prop="url"  :rules="[{ required: true, message: '不能为空'}]">
                  <app-page-select :page="navButtonForm.url" @change="navButtonForm.url=$event"></app-page-select>
                </el-form-item>
              </el-form>
              <div slot="footer" class="dialog-footer">
                <el-button @click="navButtonModal = false">取 消</el-button>
                <el-button type="primary" @click="onAddNavButton(form.navButton.info.length)">确 定</el-button>
              </div>
            </el-dialog>

            <!-- 底部tabBar -->
            <div v-show="activeName=='name5'" >
              <div style="font-size: 13px;color: #8c939d;height: 30px;">提示：目前已经提供4套图标可以选择配置。</div>
            <!--  注意：图标路径请按已有方式进行统一存放 -->
            <!--  web图标路径示例：'public/img/thememobile/icon-1/1-001.png' 'public/img/thememobile/icon-1/1-002.png' -->
            <!--  app图标路径示例：'/static/public/img/icon-1/1-001.png' '/static/public/img/icon-1/1-002.png' -->
              <el-form :model="form" label-width="60px" v-if="form.tabbarItem&&form.tabbarItem.info"  >
                <el-form-item :label="'图标' + (index + 1)" v-for="(item,index) in 4" :key="index" class="tabbar-item"
                              :style="index==curTabBarIndex?'background:#efefef':'background:#fff'" style="margin-top: 40px;">
                  <div  @click="tabbarChange(index)">
                    <el-row >
                      <el-col :span="4" v-for="(item2, index2) in 5" :key="index2" style="text-align: center;margin-left: 20px;">
                        <div>
                          <img :src="'/img/thememobile/icon-'+(index+1)+'/' + (index2+1) + '-001.png'" style="width: 40px;height: 40px;" />
                          <img :src="'/img/thememobile/icon-'+(index+1)+'/' + (index2+1) + '-002.png'" style="width: 40px;height: 40px;margin-left: 10px;"/>
                        </div>
                        <div ><el-input size="mini" v-model="form.tabbarItem.info[index2].text" style="width: 86px;text-align: center;"></el-input></div>
                      </el-col>
                    </el-row>
                  </div>

                </el-form-item>
              </el-form>
            </div>
            <!-- 底部tabBar（可以使用网络图片的tabbar暂时保留，因为UniApp的原生App暂不支持网络图片所以先隐藏保留） -->
<!--            <div v-show="activeName=='name5'">-->
<!--              <el-form :model="form" label-width="100px" v-if="form.tabbarItem&&form.tabbarItem.info">-->
<!--                <el-row style="margin-top: 30px;">-->
<!--                  <el-col :span="12" v-for="(item,index) in tabBarData" :key="index">-->
<!--                    <div>-->
<!--                      <el-form-item :label="'TabBar'+(index+1)">-->
<!--                        <el-input size="mini" v-model="form.tabbarItem.info[index].text"></el-input>-->
<!--                      </el-form-item>-->
<!--                      <el-row :gutter="20" v-if="form.tabbarItem&&form.tabbarItem.info">-->
<!--                        <el-col :span="12">-->
<!--                          <el-form-item :label="''" label-width="100px">-->
<!--                            <MaterialList :value="[form.tabbarItem.info[index].selectedIconPath]" @sureSuccess="form.tabbarItem.info[index].selectedIconPath=$event?$event[0]:''"-->
<!--                                          @deleteMaterial="form.tabbarItem.info[index].selectedIconPath=tabBarData[index].selectedIconPath"-->
<!--                                          type="image" shopId="-1" :num=1 :width=60 :height=60></MaterialList>-->
<!--                            <div style="margin-top: -20px;">选中时图片</div>-->
<!--                          </el-form-item>-->
<!--                        </el-col>-->
<!--                        <el-col :span="12">-->
<!--                          <el-form-item :label="''" label-width="50px">-->
<!--                            <MaterialList :value="[form.tabbarItem.info[index].iconPath]" @sureSuccess="form.tabbarItem.info[index].iconPath=$event?$event[0]:''"-->
<!--                                          @deleteMaterial="form.tabbarItem.info[index].iconPath=tabBarData[index].iconPath" type="image"-->
<!--                                          shopId="-1" :num=1 :width=60 :height=60></MaterialList>-->
<!--                            <div style="margin-top: -20px;">未选中时图片</div>-->
<!--                          </el-form-item>-->
<!--                        </el-col>-->
<!--                      </el-row>-->
<!--                    </div>-->
<!--                  </el-col>-->
<!--                </el-row>-->
<!--                <div style="font-size: 12px; color: #666666; margin: 0 0 0 40px; color: #ff0000;">*图片/icon建议尺寸（66x66）px</div>-->
<!--              </el-form>-->
<!--            </div>-->
          </el-col>
          <!-- 以下为右边显示预览内容 -->
          <el-col :span="8">
            <div class=''>
              <div class="previewBlcok" style="width: 360px; margin-top: 60px;">
                <div class="preview" style="height: 650px; margin-top: -5px;">
                  <div class="previewContent">
                    <div :class="'bg-' + form.backgroundColor" style="height: 200px;cursor: pointer;" @click.stop="onEditView('appTheme')">
                      <img style="width: 350px; margin-left: 5px;" src="../../../../public/img/top.png" />
                      <div style="text-align: center;color: white;height: 50px;line-height: 50px;cursor: pointer; margin-top: -10px;">首页</div>
                      <div style="padding: 0 10px;border-radius: 50px;">
                        <el-input style="border-radius: 90px;" placeholder="搜索商品" size="small"></el-input>
                      </div>
                    </div>
                    <div style="padding: 0 20px 10px;margin-top: -70px;">
                      <el-carousel height="150px">
                        <el-carousel-item v-for="(item,index) in noticeItemList" :key="index" v-if="item.enable == '1'">
                          <el-image @click.stop="onEditView('noticeItem', index)" style="height: 100px;border-radius: 5px;cursor: pointer;"
                                    :src="item.url[0]"></el-image>
                        </el-carousel-item>
                      </el-carousel>
                    </div>
                    <div>
                      <el-carousel height="35px" indicator-position="outside">
                        <div style="background-color: #E6A23C;height: 100%;line-height: 35px;">
                          <i class="el-icon-bell" style="margin-left: 5px"></i>
                          <el-carousel-item v-for="(item,index) in noticeTextList" :key="index" v-if="item.enable == '1'"
                                            style="padding-left: 30px;width: 85%">
                            <div style="font-size: 10px; cursor: pointer;" @click.stop="onEditView('noticeText', index)">
                              <el-tag size="mini" type="danger">{{item.tag}}</el-tag> {{item.content}}
                            </div>
                          </el-carousel-item>
                        </div>
                      </el-carousel>
                    </div>
                    <div>
                      <div>
                        <el-row :gutter="20">
                          <el-col :span="6" v-for="(item,index) in form.navButton.info" :key="index" @click="onEditView('navButton', index)"
                                  style="float:left;cursor: pointer;text-align:center;">
                              <img style="width: 30px;height: 30px;" :src="item.img">
                              <div style="padding: 5px;text-align: center;font-size: 12px;">
                                <span>{{item.name}}</span>
                              </div>
                          </el-col>
                        </el-row>
                      </div>
                    </div>

                    <!-- 底部tabBar -->
                    <div>
                      <div @click.stop="onEditView('tabBar')" style="bottom:-5px;position: absolute;width: 100%;border-top: #e5e5e5 solid 1px;"
                           v-if="form.tabbarItem&&form.tabbarItem.info" :style="{color:form.tabbarColor, background: form.tabbarBackgroundColor}">
                        <div style="float:left;width:20%;">
                          <div @click="tabBarItemActive=0" style="cursor: pointer">
                            <img style="margin: 10px 0 0 20px;width: 30px;height: 30px;" :src="tabBarItemActive==0?'/img/thememobile/icon-' + (curTabBarIndex+1) + '/1-002.png':'/img/thememobile/icon-' + (curTabBarIndex+1) + '/1-001.png'">
                            <div style="padding: 5px;text-align: center; font-size: 14px;" :style="{color:tabBarItemActive==0?form.tabbarSelectedColor:form.tabbarColor}">
                              <span>{{form.tabbarItem.info[0].text}}</span>
                            </div>
                          </div>
                        </div>
                        <div style="float:left;width:20%;">
                          <div @click="tabBarItemActive=1" style="cursor: pointer">
                            <img style="margin: 10px 0 0 20px;width: 30px;height: 30px;" :src="tabBarItemActive==1?'/img/thememobile/icon-' + (curTabBarIndex+1) + '/2-002.png':'/img/thememobile/icon-' + (curTabBarIndex+1) + '/2-001.png'">
                            <div style="padding: 5px;text-align: center; font-size: 14px;" :style="{color:tabBarItemActive==1?form.tabbarSelectedColor:form.tabbarColor}">
                              <span>{{form.tabbarItem.info[1].text}}</span>
                            </div>
                          </div>
                        </div>
                        <div style="float:left;width:20%;">
                          <div @click="tabBarItemActive=2" style="cursor: pointer">
                            <img style="margin: 10px 0 0 20px;width: 30px;height: 30px;" :src="tabBarItemActive==2?'/img/thememobile/icon-' + (curTabBarIndex+1) + '/3-002.png':'/img/thememobile/icon-' + (curTabBarIndex+1) + '/3-001.png'">
                            <div style="padding: 5px;text-align: center; font-size: 14px;" :style="{color:tabBarItemActive==2?form.tabbarSelectedColor:form.tabbarColor}">
                              <span>{{form.tabbarItem.info[2].text}}</span>
                            </div>
                          </div>
                        </div>
                        <div style="float:left;width:20%;">
                          <div @click="tabBarItemActive=3" style="cursor: pointer">
                            <img style="margin: 10px 0 0 20px;width: 30px;height: 30px;" :src="tabBarItemActive==3?'/img/thememobile/icon-' + (curTabBarIndex+1) + '/4-002.png':'/img/thememobile/icon-' + (curTabBarIndex+1) + '/4-001.png'">
                            <div style="padding: 5px;text-align: center; font-size: 14px;" :style="{color:tabBarItemActive==3?form.tabbarSelectedColor:form.tabbarColor}">
                              <span>{{form.tabbarItem.info[3].text}}</span>
                            </div>
                          </div>
                        </div>
                        <div style="float:left;width:20%;">
                          <div @click="tabBarItemActive=4" style="cursor: pointer">
                            <img style="margin: 10px 0 0 20px;width: 30px;height: 30px;" :src="tabBarItemActive==4?'/img/thememobile/icon-' + (curTabBarIndex+1) + '/5-002.png':'/img/thememobile/icon-' + (curTabBarIndex+1) + '/5-001.png'">
                            <div style="padding: 5px;text-align: center; font-size: 14px;" :style="{color:tabBarItemActive==4?form.tabbarSelectedColor:form.tabbarColor}">
                              <span>{{form.tabbarItem.info[4].text}}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!-- 底部tabBar -->
<!--                    <div>-->
<!--                      <div @click.stop="onEditView('tabBar')" style="bottom:-5px;position: absolute;width: 100%;border-top: #e5e5e5 solid 1px;"-->
<!--                           v-if="form.tabbarItem&&form.tabbarItem.info" :style="{color:form.tabbarColor, background: form.tabbarBackgroundColor}">-->
<!--                        <div style="float:left;width:20%;">-->
<!--                          <div @click="tabBarItemActive=0" style="cursor: pointer">-->
<!--                            <img style="margin: 10px 0 0 20px;width: 30px;height: 30px;" :src="tabBarItemActive==0?form.tabbarItem.info[0].selectedIconPath:form.tabbarItem.info[0].iconPath">-->
<!--                            <div style="padding: 5px;text-align: center; font-size: 14px;" :style="{color:tabBarItemActive==0?form.tabbarSelectedColor:form.tabbarColor}">-->
<!--                              <span>{{form.tabbarItem.info[0].text}}</span>-->
<!--                            </div>-->
<!--                          </div>-->
<!--                        </div>-->
<!--                        <div style="float:left;width:20%;">-->
<!--                          <div @click="tabBarItemActive=1" style="cursor: pointer">-->
<!--                            <img style="margin: 10px 0 0 20px;width: 30px;height: 30px;" :src="tabBarItemActive==1?form.tabbarItem.info[1].selectedIconPath:form.tabbarItem.info[1].iconPath">-->
<!--                            <div style="padding: 5px;text-align: center; font-size: 14px;" :style="{color:tabBarItemActive==1?form.tabbarSelectedColor:form.tabbarColor}">-->
<!--                              <span>{{form.tabbarItem.info[1].text}}</span>-->
<!--                            </div>-->
<!--                          </div>-->
<!--                        </div>-->
<!--                        <div style="float:left;width:20%;">-->
<!--                          <div @click="tabBarItemActive=2" style="cursor: pointer">-->
<!--                            <img style="margin: 10px 0 0 20px;width: 30px;height: 30px;" :src="tabBarItemActive==2?form.tabbarItem.info[2].selectedIconPath:form.tabbarItem.info[2].iconPath">-->
<!--                            <div style="padding: 5px;text-align: center; font-size: 14px;" :style="{color:tabBarItemActive==2?form.tabbarSelectedColor:form.tabbarColor}">-->
<!--                              <span>{{form.tabbarItem.info[2].text}}</span>-->
<!--                            </div>-->
<!--                          </div>-->
<!--                        </div>-->
<!--                        <div style="float:left;width:20%;">-->
<!--                          <div @click="tabBarItemActive=3" style="cursor: pointer">-->
<!--                            <img style="margin: 10px 0 0 18px;width: 30px;height: 30px;" :src="tabBarItemActive==3?form.tabbarItem.info[3].selectedIconPath:form.tabbarItem.info[3].iconPath">-->
<!--                            <div style="padding: 5px;text-align: center; font-size: 14px;" :style="{color:tabBarItemActive==3?form.tabbarSelectedColor:form.tabbarColor}">-->
<!--                              <span>{{form.tabbarItem.info[3].text}}</span>-->
<!--                            </div>-->
<!--                          </div>-->
<!--                        </div>-->
<!--                        <div style="float:left;width:20%;">-->
<!--                          <div @click="tabBarItemActive=4" style="cursor: pointer">-->
<!--                            <img style="margin: 10px 0 0 20px;width: 30px;height: 30px;" :src="tabBarItemActive==4?form.tabbarItem.info[4].selectedIconPath:form.tabbarItem.info[4].iconPath">-->
<!--                            <div style="padding: 5px;text-align: center; font-size: 14px;" :style="{color:tabBarItemActive==4?form.tabbarSelectedColor:form.tabbarColor}">-->
<!--                              <span>{{form.tabbarItem.info[4].text}}</span>-->
<!--                            </div>-->
<!--                          </div>-->
<!--                        </div>-->
<!--                      </div>-->
<!--                    </div>-->

                  </div>
                </div>
              </div>
              <div style="margin-top: 20px;">
                <el-button type="primary" @click="submitForm('form')" style="width: 168px;">提交</el-button>
                <el-button @click="resetForm('form')" style="width: 168px; margin-left: 24px;">清空</el-button>
              </div>
            </div>
          </el-col>
        </el-row>
      </div>
      <el-dialog title="背景颜色" :visible.sync="appTheme.showBgDialog" width="40%">
        <el-row :gutter="20">
          <el-col :span="6" v-for="(item,index) in colorList" :key="index" class="tm-select-bg">
            <div @click="onBgColor(item)">
              <div :class="'bg-' + item.name" style="width: 30px;height: 30px;margin: 0 auto;"></div>
              <div style="margin-top: 5px;">{{item.title}}&nbsp;{{item.name}}</div>
            </div>
          </el-col>
        </el-row>
      </el-dialog>
      <!-- 首页轮播组件及通知组件，不显示，仅用作调用方法 -->
      <div v-show="false">
        <notice-text @noticeTextCallback="noticeTextList=$event" ref="noticeTextRef"></notice-text>
        <notice-item @noticeItemCallback="noticeItemList=$event" ref="noticeItemRef"></notice-item>
      </div>
    </basic-container>
  </div>
</template>

<script>
  import {
    getPage,
    getObj,
    addObj,
    putObj,
    delObj,
    getObj2
  } from '@/api/mall/thememobile'
  import {
    tableOption
  } from '@/const/crud/mall/thememobile'
  import {
    mapGetters
  } from 'vuex'

  import MaterialList from '@/components/material/list.vue'
  import NoticeText from '@/views/mall/noticeitem/index-text.vue'
  import NoticeItem from '@/views/mall/noticeitem'
  import AppPageSelect from '@/components/app-page-select/Index.vue'

  export default {
    name: 'thememobileform',
    components: {
      MaterialList,
      NoticeText,
      NoticeItem,
      AppPageSelect,
    },
    data() {
      return {
        noticeTextCurIndex: -1, //通知编 辑时索引
        noticeItemCurIndex: -1, //轮播图 编辑时索引
        navButtonCurIndex: -1, //首页中间导航按钮 编辑时索引
        noticeTextList: [], //通知DATA数据
        noticeItemList: [], //轮播图数据
        appTheme: { //主题设置显示
          bgType: 'theme', //类型 theme background
          showForm: false, //显示
          showBgDialog: false,
        },

        activeName: "name1", //页面tabs设置显示
        tabBarItemActive: 0, //激活的tab
        tabBar: [{}, {}, {}, {}, ],
        rules: {
          themeColor: [{
            required: true,
            message: '请选择主题颜色',
            trigger: 'blur'
          },
            {
              max: 50,
              message: '长度在不能超过10个字符'
            },
          ],
          backgroundColor: [{
            required: true,
            message: '请选择背景颜色',
            trigger: 'blur'
          },
            {
              max: 50,
              message: '长度在不能超过10个字符'
            },
          ],
          tabbarColor: [{
            required: true,
            message: '请选择tabBar文字颜色',
            trigger: 'blur'
          },
            {
              max: 50,
              message: '长度在不能超过10个字符'
            },
          ],
          tabbarSelectedColor: [{
            required: true,
            message: '请选择tabBar文字选中颜色',
            trigger: 'blur'
          },
            {
              max: 50,
              message: '长度在不能超过10个字符'
            },
          ],
          tabbarBackgroundColor: [{
            required: true,
            message: '请选择tabBar背景色',
            trigger: 'blur'
          },
            {
              max: 50,
              message: '长度在不能超过10个字符'
            },
          ],
          tabbarBorderStyle: [{
            required: true,
            message: '请选择tabBar上边框颜色',
            trigger: 'blur'
          }],
        },
        navButtonModal:false,
        navButtonForm: {
          name:'',
          url:'',
          img:null,
        },
        form: {
          "themeColor": "scarlet",
          "backgroundColor": "gradual-scarlet",
          "tabbarColor": "#666666",
          "tabbarSelectedColor": "#e53c43",
          "tabbarBackgroundColor": "#ffffff",
          "tabbarBorderStyle": "#black",
          tabbarItem: {
            info: [
              {
                text: '首页',
                index:0,
                iconPath: '/img/thememobile/icon-1/1-001.png',
                selectedIconPath: '/img/thememobile/icon-1/1-002.png'
              },
              {
                text: '类别',
                index:1,
                iconPath: '/img/thememobile/icon-1/2-001.png',
                selectedIconPath: '/img/thememobile/icon-1/2-002.png'
              },
              {
                text: '消息',
                index:2,
                iconPath: '/img/thememobile/icon-1/3-001.png',
                selectedIconPath: '/img/thememobile/icon-1/3-002.png'
              },
              {
                text: '购物车',
                index:3,
                iconPath: '/img/thememobile/icon-1/4-001.png',
                selectedIconPath: '/img/thememobile/icon-1/4-002.png'
              },
              {
                text: '我的',
                index:4,
                iconPath: '/img/thememobile/icon-1/5-001.png',
                selectedIconPath: '/img/thememobile/icon-1/5-002.png'
              },
            ]
          },
          navButton: {
            info: []
          }
        },

        colorList: [
          {
            title: '默认',
            name: 'gradual-scarlet',
            color: '#ffffff'
          },{
            title: '嫣红',
            name: 'red',
            color: '#e54d42'
          },
          {
            title: '桔橙',
            name: 'orange',
            color: '#f37b1d'
          },
          {
            title: '明黄',
            name: 'yellow',
            color: '#fbbd08'
          },
          {
            title: '橄榄',
            name: 'olive',
            color: '#8dc63f'
          },
          {
            title: '森绿',
            name: 'green',
            color: '#39b54a'
          },
          {
            title: '天青',
            name: 'cyan',
            color: '#1cbbb4'
          },
          {
            title: '海蓝',
            name: 'blue',
            color: '#0081ff'
          },
          {
            title: '深蓝',
            name: 'darkblue',
            color: '#0055ff'
          },
          {
            title: '姹紫',
            name: 'purple',
            color: '#6739b6'
          },
          {
            title: '木槿',
            name: 'mauve',
            color: '#9c26b0'
          },
          {
            title: '桃粉',
            name: 'pink',
            color: '#e03997'
          },
          {
            title: '棕褐',
            name: 'brown',
            color: '#a5673f'
          },
          {
            title: '玄灰',
            name: 'grey',
            color: '#8799a3'
          },
          {
            title: '草灰',
            name: 'gray',
            color: '#aaaaaa'
          },
          {
            title: '墨黑',
            name: 'black',
            color: '#333333'
          },
          {
            title: '雅白',
            name: 'white',
            color: '#ffffff'
          },
          {
            title: '粉红',
            name: 'gradual-red',
            color: '#ffffff'
          },
          {
            title: '橙红',
            name: 'gradual-orange',
            color: '#ffffff'
          },
          {
            title: '绿青',
            name: 'gradual-green',
            color: '#ffffff'
          },
          {
            title: '紫红',
            name: 'gradual-purple',
            color: '#ffffff'
          },
          {
            title: '粉紫',
            name: 'gradual-pink',
            color: '#ffffff'
          },
          {
            title: '蓝绿',
            name: 'gradual-blue',
            color: '#ffffff'
          },
          {
            title: '黑灰',
            name: 'gradual-gray',
            color: '#ffffff'
          },
          {
            title: '淡蓝',
            name: 'gradual-darkblue',
            color: '#ffffff'
          },

          {
            title: '默认',
            name: 'scarlet',
            color: '#ffffff'
          },
        ],
        tableOption: tableOption,

        previewHei: 667, //预览窗口高度
        previewWid: 375, //预览窗口宽度
        pageTopHei: 0, //页面顶部title高度
        navButtonData: [],
        curTabBarIndex: 0,
        tabBarData: [
          {
            text: '首页',
            iconPath: '/img/thememobile/icon-1/1-001.png',//web的地址
            selectedIconPath: '/img/thememobile/icon-1/1-002.png',
          },
            {
              text: '类别',
              iconPath: '/img/thememobile/icon-1/2-001.png',
              iconPathApp: '/static/public/img/2-001.png',//app中的地址
              selectedIconPath: '/img/thememobile/icon-1/2-002.png',
              selectedIconPathApp: '/static/public/img/2-002.png',//app中的地址
            },
            {
              text: '消息',
              iconPath: '/img/thememobile/icon-1/2-001.png',
              selectedIconPath: '/img/thememobile/icon-1/2-002.png'
            },
            {
              text: '购物车',
              iconPath: '/img/thememobile/icon-1/3-001.png',
              selectedIconPath: '/img/thememobile/icon-1/3-002.png'
            },
            {
              text: '我的',
              iconPath: '/img/thememobile/icon-1/4-001.png',
              selectedIconPath: '/img/thememobile/icon-1/4-002.png'
            }
        ]
      }
    },
    created() {
      this.handleGet()
    },
    mounted: function() {},
    watch: {

    },
    computed: {
      ...mapGetters(['permissions']),

    },
    methods: {
      onEditView(type, index) {
        if (type == 'appTheme') { //主题
          this.activeName = 'name1';
        } else if (type == 'noticeItem') { //轮播
          this.activeName = 'name2';
          this.noticeItemCurIndex = index;
        } else if (type == 'noticeText') { //公告
          this.activeName = 'name3';
          this.noticeTextCurIndex = index;
        } else if (type == 'navButton') { //中间导航
          this.activeName = 'name4';
          this.navButtonCurIndex = index;
        } else if (type == 'tabBar') { //tabBar
          this.activeName = 'name5';
        }
      },
      onSortBottom(dataTemp, index, type) { //往下移动一格 0 + 1
        if (index != dataTemp.length - 1) {
          dataTemp[index] = dataTemp.splice(index + 1, 1, dataTemp[index])[0];
        } else {
          dataTemp.unshift(dataTemp.splice(index, 1)[0]);
        }
        dataTemp[index].sort = index;
        dataTemp[index + 1].sort = index + 1;
        if (type == 'noticeItem') { //轮播
          this.$refs.noticeItemRef.changeSort(dataTemp[index]);
          this.$refs.noticeItemRef.changeSort(dataTemp[index + 1]);
        } else if (type == 'noticeText') { //公告
          this.$refs.noticeTextRef.changeSort(dataTemp[index]);
          this.$refs.noticeTextRef.changeSort(dataTemp[index + 1]);
        }
      },
      onSortTop(dataTemp, index, type) { //往上移动一格
        if (index != 0) {
          dataTemp[index] = dataTemp.splice(index - 1, 1, dataTemp[index])[0];
        } else {
          dataTemp.push(dataTemp.shift());
        }
        dataTemp[index].sort = index;
        dataTemp[index - 1].sort = index - 1;
        if (type == 'noticeItem') { //轮播
          this.$refs.noticeItemRef.changeSort(dataTemp[index]);
          this.$refs.noticeItemRef.changeSort(dataTemp[index - 1]);
        } else if (type == 'noticeText') { //公告
          this.$refs.noticeTextRef.changeSort(dataTemp[index]);
          this.$refs.noticeTextRef.changeSort(dataTemp[index - 1]);
        }
      },
      onAddNoticeItemButton(startIndex) { //新增 轮播图
        this.$refs.noticeItemRef.openAddForm();
      },
      onEditNoticeItemButton(row, index) { //编辑 轮播图
        this.$refs.noticeItemRef.openEditForm(row, index);
      },
      onChangeNoticeItemButton(item) { //启用 轮播图
        this.$refs.noticeItemRef.changeEnable(item);
      },
      onDelNoticeItemButton(item, startIndex) { //删除 轮播图
        this.$refs.noticeItemRef.handleDel(item);
      },

      onAddNoticeTextButton(startIndex) { //新增 通知
        this.$refs.noticeTextRef.openAddForm();
      },
      onEditNoticeTextButton(row, index) { //编辑 通知
        this.$refs.noticeTextRef.openEditForm(row, index);
      },
      onChangeNoticeTextButton(item) { //启用 通知
        this.$refs.noticeTextRef.changeEnable(item);
      },
      onDelNoticeTextButton(item, startIndex) { //删除 通知
        this.$refs.noticeTextRef.handleDel(item);
      },
      onAddNavButton(startIndex) { //新增 NavBtn
        this.$refs['navButtonForm'].validate((valid) => {
          if (valid) {
            this.form.navButton.info.push(this.navButtonForm);
            this.navButtonModal = false;
            this.navButtonForm = {
              name:'',
              url:'',
              img:null,
            };
          } else {
            return false;
          }
        });

      },
      onDeleteButton(dataTemp, index) { //删除
        dataTemp.splice(index, 1);
      },
      onBgColor(item) {
        if (this.appTheme.bgType === 'theme') {
          this.form.themeColor = item.name;
        } else {
          this.form.backgroundColor = item.name;
        }
        this.appTheme.showBgDialog = false;
      },
      tabbarChange(index){ // 选择tabBar
        this.curTabBarIndex = index
        this.form.tabbarItem.info.map((item, index2)=>{
          item.iconPath = '/static/public/img/icon-' + (index+1) + '/'+(index2+1)+ '-001.png'
          item.selectedIconPath = '/static/public/img/icon-' + (index+1) + '/' + (index2+1) + '-002.png'
        })
      },
      initResponseData(response) {
        response.data.data = response.data.data ? response.data.data : null;
        //初始化数据 tabBar数据
        if (response.data.data.tabbarItem && response.data.data.tabbarItem.info) {
          let info = response.data.data.tabbarItem.info;
          let iconPathTemp = info[0].iconPath
          for (let i = 0; i < 3; i++) {// 确认第几套图标
            if (iconPathTemp == '/static/public/img/' + i + '-001.png'){
              this.curTabBarIndex = i
            }
          }
        }
        //初始化数据 tabBar数据
        // if (response.data.data.tabbarItem && response.data.data.tabbarItem.info) {
        //   let info = response.data.data.tabbarItem.info;
        //   let infoIndex = [];
        //   let infoTemp = [];
        //   info.map(item => {
        //     infoIndex.push(item.index)
        //   });
        //   // 默认tabBar图片
        //   for (let i = 0; i < 5; i++) {
        //     let indexTemp = infoIndex.indexOf(i);
        //     if (indexTemp == -1) {
        //       infoTemp.push({
        //         "selectedIconPath": this.tabBarData[i].selectedIconPath,
        //         "iconPath": this.tabBarData[i].iconPath,
        //         "index": i,
        //         "text": this.tabBarData[i].text,
        //       })
        //     } else {
        //       infoTemp.push({
        //         "selectedIconPath": info[indexTemp].selectedIconPath ? info[indexTemp].selectedIconPath : this.tabBarData[
        //           i].selectedIconPath,
        //         "iconPath": info[indexTemp].iconPath ? info[indexTemp].iconPath : this.tabBarData[i].iconPath,
        //         "index": i,
        //         "text": info[indexTemp].text ? info[indexTemp].text : this.tabBarData[i].text,
        //       })
        //     }
        //   }
        //   response.data.data.tabbarItem.info = infoTemp;
        // }
        if(response.data.data){
          this.form = response.data.data;
        }
      },
      handleGet: function() {
        getObj2().then(response => {
          this.initResponseData(response)
        })
      },
      //提交
      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.handleUpdate(this.form);
          } else {
            return false;
          }
        });
      },
      resetForm(formName) {
        this.$refs[formName].resetFields();
      },
      /**
       * @title 数据更新
       * @param row 为当前的数据
       * @param index 为当前更新数据的行数
       * @param done 为表单关闭函数
       *
       **/
      handleUpdate(form) {
        // 过滤数据
        // this.form.tabbarItem.info.map(item => {
        //   if (item.iconPath.indexOf("http") == -1) {
        //     item.iconPath = ''
        //   }
        //   if (item.selectedIconPath.indexOf("http") == -1) {
        //     item.selectedIconPath = ''
        //   }
        // });
        putObj(this.form).then(response => {
          // done()
          this.initResponseData(response)
          this.$message({
            showClose: true,
            message: '修改成功',
            type: 'success'
          })
        }).catch(() => {
          // done()
        })
      },
    }
  }
</script>
<style lang='less' scoped>
  .icon-list {

    overflow: hidden;
    list-style: none;
    padding: 0 !important;
    border: 1px solid #eaeefb;
    border-radius: 4px;

    li {

      float: left;
      width: 16.66%;
      text-align: center;
      height: 120px;
      line-height: 120px;
      color: #666;
      font-size: 13px;
      border-right: 1px solid #eee;
      border-bottom: 1px solid #eee;
      margin-right: -1px;
      margin-bottom: -1px;

      span {
        line-height: normal;
        color: #99a9bf;
        transition: color .15s linear;

      }

    }
  }

  .el-col-5 {
    width: 20%;

  }

  .icon-name {
    display: inline-block;
    padding: 0 3px;
    height: 1em;
  }

  .previewBlcok {
    box-shadow: 0 0 5px #ccc;
    top: 60px;
    right: 20px;
    z-index: 10;

    .pageTopBlock {
      width: 100%;
      z-index: 220;

      .title {
        position: absolute;
        left: 0;
        width: 100%;
        text-align: center;
      }
    }

    .preview {
      width: 100%;
      height: 667px;
      margin-top: -5px;

      &::-webkit-scrollbar {
        display: none
      }

    ;

      .previewContent {
        min-height: calc(~"100% - 5px");
        position: relative;

        .modal {
          position: absolute;
          top: -5px;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, .6);
          z-index: 3;
        }
      }
    }
  }

  /*color ui*/
  .grid {
    display: flex;
    flex-wrap: wrap;
  }

  .grid.grid-square {
    overflow: hidden;
  }

  .grid.grid-square .cu-tag {
    position: absolute;
    right: 0;
    top: 0;
    border-bottom-left-radius: 6px;
    padding: 6px 12px;
    height: auto;
    background-color: rgba(0, 0, 0, 0.5);
  }

  .grid.grid-square>view>text[class*="cuIcon-"] {
    font-size: 52px;
    position: absolute;
    color: #8799a3;
    margin: auto;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
  }

  .grid.grid-square>view {
    margin-right: 20px;
    margin-bottom: 20px;
    border-radius: 6px;
    position: relative;
    overflow: hidden;
  }

  .grid.grid-square>view.bg-img image {
    width: 100%;
    height: 100%;
    position: absolute;
  }

  .grid.col-1.grid-square>view {
    padding-bottom: 100%;
    height: 0;
    margin-right: 0;
  }

  .grid.col-2.grid-square>view {
    padding-bottom: calc((100% - 20px)/2);
    height: 0;
    width: calc((100% - 20px)/2);
  }

  .grid.col-3.grid-square>view {
    padding-bottom: calc((100% - 40px)/3);
    height: 0;
    width: calc((100% - 40px)/3);
  }


  .bg-red {
    background-color: #e54d42;
    color: #ffffff;
  }

  .bg-orange {
    background-color: #f37b1d;
    color: #ffffff;
  }

  .bg-yellow {
    background-color: #fbbd08;
    color: #333333;
  }

  .bg-olive {
    background-color: #8dc63f;
    color: #ffffff;
  }

  .bg-green {
    background-color: #39b54a;
    color: #ffffff;
  }

  .bg-cyan {
    background-color: #1cbbb4;
    color: #ffffff;
  }

  .bg-darkblue {
    background-color: #0055ff;
    color: #ffffff;
  }

  .bg-blue {
    background-color: #0081ff;
    color: #ffffff;
  }

  .bg-purple {
    background-color: #6739b6;
    color: #ffffff;
  }

  .bg-mauve {
    background-color: #9c26b0;
    color: #ffffff;
  }

  .bg-pink {
    background-color: #e03997;
    color: #ffffff;
  }

  .bg-brown {
    background-color: #a5673f;
    color: #ffffff;
  }

  .bg-grey {
    background-color: #8799a3;
    color: #ffffff;
  }

  .bg-gray {
    background-color: #f0f0f0;
    color: #333333;
  }

  .bg-black {
    background-color: #333333;
    color: #ffffff;
  }

  .bg-white {
    background-color: #ffffff;
    color: #666666;
  }

  .bg-shadeTop {
    background-image: linear-gradient(rgba(0, 0, 0, 1), rgba(0, 0, 0, 0.01));
    color: #ffffff;
  }

  .bg-shadeBottom {
    background-image: linear-gradient(rgba(0, 0, 0, 0.01), rgba(0, 0, 0, 1));
    color: #ffffff;
  }

  .bg-red.light {
    color: #e54d42;
    background-color: #fadbd9;
  }

  .bg-orange.light {
    color: #f37b1d;
    background-color: #fde6d2;
  }

  .bg-yellow.light {
    color: #fbbd08;
    background-color: #fef2ced2;
  }

  .bg-olive.light {
    color: #8dc63f;
    background-color: #e8f4d9;
  }

  .bg-green.light {
    color: #39b54a;
    background-color: #d7f0dbff;
  }

  .bg-cyan.light {
    color: #1cbbb4;
    background-color: #d2f1f0;
  }

  .bg-blue.light {
    color: #0081ff;
    background-color: #cce6ff;
  }

  .bg-purple.light {
    color: #6739b6;
    background-color: #e1d7f0;
  }

  .bg-mauve.light {
    color: #9c26b0;
    background-color: #ebd4ef;
  }

  .bg-pink.light {
    color: #e03997;
    background-color: #f9d7ea;
  }

  .bg-brown.light {
    color: #a5673f;
    background-color: #ede1d9;
  }

  .bg-grey.light {
    color: #8799a3;
    background-color: #e7ebed;
  }
  .bg-scarlet {
    background-color: #e53c43;
    color: #ffffff;
  }
  .bg-gradual-scarlet {
    background-image: linear-gradient(45deg, #e5432e, #e53c43);
    color: #ffffff;
  }
  .bg-gradual-red {
    background-image: linear-gradient(45deg, #f43f3b, #ec008c);
    color: #ffffff;
  }

  .bg-gradual-orange {
    background-image: linear-gradient(45deg, #ff9700, #ed1c24);
    color: #ffffff;
  }

  .bg-gradual-green {
    background-image: linear-gradient(45deg, #39b54a, #8dc63f);
    color: #ffffff;
  }

  .bg-gradual-purple {
    background-image: linear-gradient(45deg, #9000ff, #5e00ff);
    color: #ffffff;
  }

  .bg-gradual-pink {
    background-image: linear-gradient(45deg, #ec008c, #6739b6);
    color: #ffffff;
  }

  .bg-gradual-blue {
    background-image: linear-gradient(45deg, #0081ff, #1cbbb4);
    color: #ffffff;
  }


  .bg-gradual-gray {
    background-image: linear-gradient(45deg, #99a6c3, #444c5e);
    color: #ffffff;
  }

  .bg-gradual-darkblue {
    background-image: linear-gradient(45deg, #339eec, #1b7bde);
    color: #ffffff;
  }

  .tm-select-bg {
    text-align: center;
    cursor: pointer;
    padding: 10px 0;
  }

  .tm-select-bg:hover {
    background: #efefef;
  }

  .tabbar-item{
    padding-top: 10px;
    cursor: pointer;
    background: #efefef;
  }
  .tabbar-item:hover {
    background: rgba(189, 238, 255, 0.91);
  }

</style>
