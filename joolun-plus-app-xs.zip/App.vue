<script>
	/**
	 * Copyright (C) 2019-2020
	 * All rights reserved, Designed By www.joolun.com
	 * 注意：
	 * 本软件为www.joolun.com开发研制，未经购买不得使用
	 * 购买后可获得全部源代码（禁止转卖、分享、上传到码云、github等开源平台）
	 * 一经发现盗用、分享等行为，将追究法律责任，后果自负
	 */
	import Vue from 'vue'

	import service from '@/store/service';
	import { showChatNotice } from '@/components/notice/notice-plus-show.js';
	import api from '@/api/api';
	import __config from "@/config/env";
	import JMessage from 'public/jmessage-wxapplet-sdk/jmessage-wxapplet-sdk-1.4.0.min.js';
	// #ifdef APP-PLUS
	import APPUpdate from "@/public/APPUpdate/index.js";//App版本更新
	// #endif
	
	export default {
		globalData: {
			username: null,
			user_id: null,
			tenant_id: null,
			access_token: null,
			expires_in: null,//过期时间：该时间为当前时间之后的时间，单位为毫秒数
			permissions: {},//权限 Object
			bgColor: 'bg-white',
			JIM: null, //极光JMessage
			isDev: false, // 是否是开发模式,开发模式下会记录日志等显示开发模式下的操作及显示
		},
		data() {
			return {
				refreshTime: null,
				refreshLock: false
			}
		},
		onLaunch: function() {
			service.saveLogInfo("********************** App启动 ************************")
			uni.getSystemInfo({
				success: function(e) {
					// #ifndef MP
					Vue.prototype.StatusBar = e.statusBarHeight;
					if (e.platform == 'android') {
						Vue.prototype.CustomBar = e.statusBarHeight + 50;
					} else {
						Vue.prototype.CustomBar = e.statusBarHeight + 45;
					};
					// #endif

					// #ifdef MP-WEIXIN
					Vue.prototype.StatusBar = e.statusBarHeight;
					let custom = wx.getMenuButtonBoundingClientRect();
					Vue.prototype.Custom = custom;
					Vue.prototype.CustomBar = custom.bottom + custom.top - e.statusBarHeight;
					// #endif

					// #ifdef MP-ALIPAY
					Vue.prototype.StatusBar = e.statusBarHeight;
					Vue.prototype.CustomBar = e.statusBarHeight + e.titleBarHeight;
					// #endif
				}
			});
			// 判断登录
			service.saveLogInfo("-----开始登录-----")
			this.startLogin();
			service.saveLogInfo("-----结束登录-----")
			// 版本更新检测
			// #ifdef APP-PLUS
			APPUpdate();
			// #endif
		},
		onShow: function() {
			console.log('App Show')
			// 初始化极光IM
			this.initJIM()
		},
		onHide: function() {
			console.log('App Hide')
		},
		methods: {
			startLogin() {
				// 登录流程--接口调用处也会判断和验证token
				// 1.如果有值就表示登录过，启动自动登录
				// 		1.1 验证token有效期(一般为7天),如果在有效期内就直接跳转到首页
				// 		1.2 如果token过期,那么就调用刷新token的接口刷新有效期
				// 		1.3 如果refresh_token(一般为30天)也过期那么就跳转到登录页面
				// 2.如果没有登录过就直接跳转到登录页面
				const loginTokenInfo = service.getLoginAccessToken();
				if (loginTokenInfo && loginTokenInfo.access_token) {
					service.saveLogInfo("-----token登录-----")
					let curDateTime = new Date().getTime();
					if(curDateTime<loginTokenInfo.expires_in){ // 1.1
						service.saveLogInfo("-----token未过期登录-----")
						let app = getApp();
						app.globalData.access_token = loginTokenInfo.access_token;
						app.globalData.username = loginTokenInfo.username;
						app.globalData.user_id = loginTokenInfo.user_id;
						app.globalData.tenant_id = loginTokenInfo.tenant_id;
						app.globalData.expires_in = loginTokenInfo.expires_in;
						// 获取个人信息
						this.getUserInfo();
					}else{//1.2
						service.saveLogInfo("-----token已过期，刷新登录-----")
						// token过期，刷新token
						api.login.refreshToken(loginTokenInfo.refresh_token).then(response => {
							service.saveLogInfo("-----token过期已刷新成功-----")
							// 登录成功 保存登录数据、本次登录的token
							service.saveAccessToken(response);
							// 获取个人信息
							this.getUserInfo();
						}).catch(response => {
							//失败 重新登录
							this.loginFail();
						});
					}
				} else {
					// 登录
					uni.reLaunch({
						url: '/pages/login/login'
					});
				}
			},
			loginFail(){
				service.removeUser();
				uni.showToast({
					icon: 'none',
					position: 'bottom',
					title: '登录失败,请重新登录'
				});
				uni.reLaunch({
				    url: '/pages/login/login'
				});
			},
			getUserInfo() {
				service.saveLogInfo("-----登录成功,获取用户信息-----")
				api.getUserInfo().then(response => {
					service.saveLogInfo("-----获取用户信息成功-----")
					// 更新用户信息
					service.saveUserInfo(response.data.sysUser);
					// 保存用户权限
					service.saveUserPermissions(response.data.permissions);
					
					service.saveLogInfo("-----初始化JIM-----")
					// 初始化极光IM
					this.initJIM()
					service.saveLogInfo("-----初始化IM完成-----")
				}).catch(response => {
					//失败 重新登录
					service.saveLogInfo("-----获取用户信息失败-----"+JSON.stringify(response))
					this.loginFail();
				});
			},
			//初始化极光IM
			initJIM() {
				let that = this
				if(!this.globalData.JIM){
					this.globalData.JIM = new JMessage({})
				} 
				return new Promise((resolve, reject) => {
					//获取用户信息
					let userInfo = service.getUser();
					let JIM = that.globalData.JIM
					if(!userInfo){
						console.log("用户未登录，不登录极光")
						service.saveLogInfo("用户未登录，不登录极光")
						resolve("success");
						return
					};
					if(JIM.isInit()){//极光IM已经初始化，直接登录
						console.log("极光IM已经初始化，直接登录")
						service.saveLogInfo("极光IM已经初始化，直接登录")
						that.loginJIM(userInfo).then(res => {
							resolve("success");
						});
					}else{
						api.mall.getJiguangConfig().then(res => {
							//初始化
							JIM.init({
								"appkey": res.data.appkey,
								"random_str": res.data.random_str,
								"signature": res.data.signature,
								"timestamp": res.data.timestamp,
								"flag": res.data.flag
							}).onSuccess(function(data) {
								console.log('JIMInitSuccess')
								that.loginJIM(userInfo).then(res => {
									resolve("success");
								});
							}).onFail(function(data) {
								console.log('JIMInitFail')
								console.log(data)
								uni.showModal({
									title: '极光初始化失败',
									content: data.message,
									success() {},
									complete() {
										
									}
								});
								resolve("success");
							});
							//
							JIM.onDisconnect(function() {
								console.log('JIM断开链接')
							});
						
							JIM.onMsgReceive(function(data) {
								// 接受在线消息
								console.log('在线接受消息');
								console.log(data);
								// 收到消息时如果不是在聊天界面就发送通知及声音及震动
								showChatNotice(data);
								//更新消息未读数
								that.getJIMUnreadMsgCnt()
								uni.$emit('msg_ol', data.messages[0].content);
							});
						
							//JIM.isInit();// 无回调函数，调用则成功
							Vue.prototype.onSyncConversation = null
							uni.$once('onSyncConversation', function(data) {
								that.onSyncConversation = data
								console.log('离线传递：')
								console.log(data)
								uni.$off()
							})
						});
					}
				});
			},
			//极光登录
			loginJIM(userInfo){
				let that = this
				return new Promise((resolve, reject) => {
					let JIM = that.globalData.JIM
					if (JIM.isLogin()) {
						service.saveLogInfo("极光IM已经登录，无需再登录")
						console.log("极光IM已经登录，无需再登录");
						resolve("success");
						return
					};
					//登录
					JIM.login({
						'username': userInfo.id,
						'password': userInfo.id
					}).onSuccess(function(data) {
						console.log("极光IM登录成功");
						service.saveLogInfo("极光IM登录成功")
						//更新用户信息
						that.updataJIMUserInfo(userInfo).then(res => {
							resolve("success");
						});
						//更新消息未读数
						that.getJIMUnreadMsgCnt()
					}).onFail(function(data) {
						//如果用户不存在，则注册账号
						service.saveLogInfo("极光IM--如果用户不存在，则注册账号")
						if (data.code == 880103) {
							JIM.register({
								'username': userInfo.id,
								'password': userInfo.id,
								'nickname': userInfo.nickName,
								'extras': {
									'avatar': userInfo.avatar
								}
							}).onSuccess(function(data) {
								console.log("极光IM注册成功");
								service.saveLogInfo("极光IM注册成功");
								//登录
								JIM.login({
									'username': userInfo.id,
									'password': userInfo.id
								}).onSuccess(function(data) {
									console.log("极光IM登录成功");
									service.saveLogInfo("极光IM登录成功");
									//更新用户信息
									that.updataJIMUserInfo(userInfo).then(res => {
										resolve("success");
									});
									//更新消息未读数
									that.getJIMUnreadMsgCnt()
								}).onFail(function(data) {
									uni.showModal({
										title: '极光IM登录失败',
										content: data.message,
										success() {},
										complete() {
											
										}
									});
									console.log(data)
									resolve("success");
								});
							}).onFail(function(data) {
								console.log(data)
								uni.showModal({
									title: '极光IM注册失败',
									content: data.message,
									success() {},
									complete() {
										
									}
								});
								resolve("success");
							});
						}else if(data.code == 880109 || data.code == 880107){
							console.log(data)
						} else {
							uni.showModal({
								title: '极光IM登录失败',
								content: data.message,
								success() {},
								complete() {
									
								}
							});
							console.log(data)
							resolve("success");
						}
					});
				})
			},
			//获取极光未读数
			getJIMUnreadMsgCnt(){
				let JIM = this.globalData.JIM
				JIM.getConversation().onSuccess(function(data) {
					let conversation = data.conversations.reverse()
					let count = 0
					for (var i = 0; i < conversation.length; i++) {
						count = count + conversation[i].unread_msg_count
					}
					//设置tabbar未读数量
					uni.setTabBarBadge({
						index: 1,
						text: count + ''
					});
				}).onFail(function(data) {
					console.log('JIM fail:' + data )
				});
			},
			//更新极光IM用户信息
			updataJIMUserInfo(userInfo) {
				service.saveLogInfo("更新极光IM用户信息");
				let that = this
				return new Promise((resolve, reject) => {
					let JIM = that.globalData.JIM;
					JIM.getUserInfo({
						'username': userInfo.id,
					}).onSuccess(function(data) {
						//data.code 返回码
						//data.message 描述
						//data.user_info.username
						//data.user_info.appkey
						//data.user_info.nickname
						//data.user_info.avatar 头像
						//data.user_info.birthday 生日，默认空
						//data.user_info.gender 性别 0 - 未知， 1 - 男 ，2 - 女
						//data.user_info.signature 用户签名
						//data.user_info.region 用户所属地区
						//data.user_info.address 用户地址
						//data.user_info.mtime 用户信息最后修改时间
						//data.extras 自定义json字段
						console.log('获取IM用户信息成功')
						service.saveLogInfo("获取IM用户信息成功");
						if(data.user_info.nickname != userInfo.nickName || data.user_info.extras.avatar != userInfo.avatar){
							console.log('更新JIM用户信息')
							service.saveLogInfo("更新IM用户信息");
							JIM.updateSelfInfo({
								'nickname': userInfo.nickName,
								'extras': {
									'avatar': userInfo.avatar
								}
							}).onSuccess(function(data) {
								//data.code 返回码
								//data.message 描述
								resolve("success");
							}).onFail(function(data) {
								console.log('updataJIMUserInfo fail:' + data)
								resolve("success");
							});
						}else{
							resolve("success");
						}
					}).onFail(function(data) {
						//data.code 返回码
						//data.message 描述
						resolve("success");
					});
				});
			}
		}
	}
</script>

<style>
	/* #ifndef APP-PLUS-NVUE  */
	@import "public/colorui/main.css";
	@import "public/colorui/icon.css";

	.nav-list {
		display: flex;
		flex-wrap: wrap;
		padding: 0px 40upx 0px;
		justify-content: space-between;
	}

	.nav-li {
		padding: 30upx;
		border-radius: 12upx;
		width: 45%;
		margin: 0 2.5% 40upx;
		background-image: url(https://cdn.nlark.com/yuque/0/2019/png/280374/1552996358352-assets/web-upload/cc3b1807-c684-4b83-8f80-80e5b8a6b975.png);
		background-size: cover;
		background-position: center;
		position: relative;
		z-index: 1;
	}

	.nav-li::after {
		content: "";
		position: absolute;
		z-index: -1;
		background-color: inherit;
		width: 100%;
		height: 100%;
		left: 0;
		bottom: -10%;
		border-radius: 10upx;
		opacity: 0.2;
		transform: scale(0.9, 0.9);
	}

	.nav-li.cur {
		color: #fff;
		background: rgb(94, 185, 94);
		box-shadow: 4upx 4upx 6upx rgba(94, 185, 94, 0.4);
	}

	.nav-title {
		font-size: 32upx;
		font-weight: 300;
	}

	.nav-title::first-letter {
		font-size: 40upx;
		margin-right: 4upx;
	}

	.nav-name {
		font-size: 28upx;
		text-transform: Capitalize;
		margin-top: 20upx;
		position: relative;
	}

	.nav-name::before {
		content: "";
		position: absolute;
		display: block;
		width: 40upx;
		height: 6upx;
		background: #fff;
		bottom: 0;
		right: 0;
		opacity: 0.5;
	}

	.nav-name::after {
		content: "";
		position: absolute;
		display: block;
		width: 100upx;
		height: 1px;
		background: #fff;
		bottom: 0;
		right: 40upx;
		opacity: 0.3;
	}

	.nav-name::first-letter {
		font-weight: bold;
		font-size: 36upx;
		margin-right: 1px;
	}

	.nav-li text {
		position: absolute;
		right: 30upx;
		top: 30upx;
		font-size: 52upx;
		width: 60upx;
		height: 60upx;
		text-align: center;
		line-height: 60upx;
	}

	.text-light {
		font-weight: 300;
	}

	@keyframes show {
		0% {
			transform: translateY(-50px);
		}

		60% {
			transform: translateY(40upx);
		}

		100% {
			transform: translateY(0px);
		}
	}

	@-webkit-keyframes show {
		0% {
			transform: translateY(-50px);
		}

		60% {
			transform: translateY(40upx);
		}

		100% {
			transform: translateY(0px);
		}
	}
	
	/* #endif  */
</style>
