/**
 * 在原生App通知栏上显示一条通知信息
 * 文档地址：http://www.html5plus.org/doc/zh_cn/push.html#plus.push.PushMessage
 */
import service from '@/store/service';//存储相关数据服务util
// 显示聊天消息通知
export const showChatNotice = (data) => {
	// #ifdef APP-PLUS
		const setting = service.getUserSetting();
		const noticeSound = setting.noticeSound;//设置里面的消息通知是否开启，true 开启，默认开启
		if(!noticeSound)return;
		let msgContent = data.messages[0];
		let content = '['+msgContent.content.from_name + ']:'+msgContent.content.msg_body.text; // 消息显示的内容，在系统通知中心中显示的文本内容。
		let payload = msgContent.from_username; // String 消息承载的数据，可根据业务逻辑自定义数据格式。
		let options = {	 // JSON 创建消息的额外参数，参考MessageOptions。
			cover: false, // (Boolean 类型 )是否覆盖上一次提示的消息: 可取值true或false，true为覆盖，false不覆盖。 默认为false。
			sound: 'system', // (String 类型 )推送消息的提示音: 可取值： “system”-表示使用系统通知提示音； “none”-表示不使用提示音； 默认值为“system”。
			payload: payload
		}; 
		// 创建通知栏消息
		plus.push.createMessage(content, payload, options);
		// 原生通知的点击事件 - 跳转到聊天页面
		plus.push.addEventListener('click', function(message) {
			uni.navigateTo({
				url: "/pages/message/chat/index?userId="+message.payload
			})
		});  
	// #endif 
}
// 清空通知栏的所有消息
export const clearShowNotice = (data) => {
	// #ifdef APP-PLUS
		plus.push.clear();
	// #endif 
}