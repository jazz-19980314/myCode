<template>
	<!-- 根据店铺ID 显示店铺名的组件 -->
	<text>{{showShopName}}</text>
</template>

<script>
	
	import { getObj,getPage } from '@/api/mall/shopinfo'
	
	export default {
		props:{
			shopId: {  // 店铺ID 必填
				type: String,
				required: true
			},
			shopList: { // 店铺列表数据，在列表中使用时 尽量直接传过来，不然会多次请求数据
				type: Array,
				default: function () {
                    return []
                }
			}
		},
		computed:{
			showShopName(){
				if(this.shopId && this.shopinfoDataList && this.shopinfoDataList.length>0){
					let name = this.shopId;
					this.shopinfoDataList.map(item=>{
						if(item.id==this.shopId){
							name = item.name;
							return;
						}
					})
					return name;
				}else{
					return this.shopId;
				}
			}
		},
		data() {
			return {
				shopinfoDataList:[],
				shopinfo:{},
			};
		},
		created(){
			if(this.shopList && this.shopList.length>0){
				this.shopinfoDataList = this.shopList;
			} else {
				this.getDataList();
			}
		},
		methods:{
			getDataList(){
				if(this.shopinfoDataList.length>0){
					return;
				}
				getPage().then(response => {
					if (response.data) {
						this.shopinfoDataList = response.data.records;
					}
				});
				
			}
		}
	}
</script>

<style>

</style>
