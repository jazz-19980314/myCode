<template>
	<view>
		<cu-custom :bgColor="globalData.bgColor" :isBack="true"><block slot="content"><text class="text-darkgrey">设置</text></block></cu-custom>
		<form>
			<view class="cu-form-group solid-top">
				<view class="title text-darkgrey cuIcon-notice"><text class="margin-left-xs">消息通知</text></view>
				<switch @change="noticeSoundChange" :class="userSetting.noticeSound?'checked':''" :checked="userSetting.noticeSound?true:false"></switch>
			</view>
			<navigator class="cu-form-group " url="log-list" v-show="globalData.isDev">
				<view class="title text-darkgrey cuIcon-info"><text class="margin-left-xs">查看日志</text></view>
			</navigator>
		</form>
	</view>
</template>

<script>

	import service from '@/store/service';//存储相关数据服务util

	const app = getApp();

	export default {
		onLoad() {
			this.userSetting = service.getUserSetting();
		},
		data() {
			return {
                globalData: app.globalData,
				userSetting: {//设置信息
					noticeSound: true,//是否开启声音通知
				}
			}
		},
		methods : {
			noticeSoundChange: function (e) {
				this.userSetting.noticeSound = e.detail.value;
				service.saveUserSetting(this.userSetting)
			}
		}
	}
</script>

<style>
</style>
