<template>
	<view>
		<cu-custom :bgColor="globalData.bgColor" :isBack="true"><block slot="content"><text class="text-darkgrey">日志</text></block></cu-custom>
		<view class="flex justify-between padding-sm">
			<view >记录了100条保存的日志</view>
			<view class="cu-btn sm bg-blue round" @click="onClearLog">清空日志</view>
		</view>
		<view class="cu-list  text-darkgrey bg-white padding-sm" v-if="list&&list.length>0">
			<view class="cu-item padding-sm" v-for="(item,index) in list" :key="index">
				<view class="text-grey">{{item.time}}</view>
				<view >{{item.log}}</view>
			</view>
		</view>
		<view v-else class="text-center text-gray">
			没有找到数据
		</view>
	</view>
</template>

<script>
	

	import service from '@/store/service';//存储相关数据服务util

	const app = getApp();

	export default {
		onLoad() {
			this.list = service.getLogInfo().reverse();
		},
		components: {
		},
		data() {
			return {
                globalData: app.globalData,
				list:[],
			};
		},
		methods:{
			onClearLog(){
				service.removeLogInfo();
				this.list = [];
			}
		}
	}
</script>

<style>
	.header {
		display: flex;
		flex-direction: row;
		padding: 10px 15px;
		align-items: center;
	}
	.base-info-item{
		justify-content: space-between;
		padding: 10upx 10upx;
	}
	.input-view {
		display: flex;
		align-items: center;
		flex-direction: row;
		background-color: #e7e7e7;
		height: 60upx;
		border-radius: 15px;
		padding: 0 10px;
		flex: 1;
	}

	.input {
		flex: 1;
		padding: 0 5px;
		height: 24px;
		line-height: 54upx;
		font-size: 26upx;
	}

	.icon {
		display: flex;
		flex-direction: column;
		justify-content: center;
		margin-left: 10px;
	}
		
    .hello {
        display: flex;
        flex: 1;
        flex-direction: column;
    }

    .title {
        color: #8f8f94;
        margin-top: 50px;
    }

    .ul {
        font-size: 30px;
        color: #8f8f94;
        margin-top: 50px;
    }

    .ul>view {
        line-height: 50px;
    }


	.scrollList {
		flex: 1;
		height: 100vh;
	}

	.uni-indexed-list-bar {
		width: 46upx;
		height: 100vh;
		background-color: lightgrey;
		display: flex;
		flex-direction: column;
	}

	.uni-indexed-list-bar.active {
		background-color: rgb(200, 200, 200);
	}

	.uni-indexed-list-text {
		color: #aaa;
		font-size: 22upx;
		text-align: center;
	}

	.uni-indexed-list-bar.active .uni-indexed-list-text {
		color: #333;
	}

	.uni-indexed-list-text.active,
	.uni-indexed-list-bar.active .uni-indexed-list-text.active {
		color: #007AFF;
	}

	.uni-indexed-list-alert {
		position: absolute;
		z-index: 20;
		width: 160upx;
		height: 160upx;
		left: 50%;
		top: 50%;
		margin-left: -80upx;
		margin-top: -80upx;
		border-radius: 80upx;
		text-align: center;
		line-height: 160upx;
		font-size: 70upx;
		color: #fff;
		background-color: rgba(0, 0, 0, 0.5);
	}
</style>