<!-- 服务协议 -->
<template>
    <view >
		<cu-custom :bgColor="globalData.bgColor" :isBack="true"><block slot="content"><text class="text-darkgrey">服务条款</text></block></cu-custom>
		<form>
			<navigator class="cu-form-group solid-top" :url="'/pages/public/webview/webview?title=隐私政策&url='+config.privacyPolicyUrl">
				<view class="title text-darkgrey cuIcon-form" ><text class="margin-left-xs">隐私政策</text></view>
			</navigator>
			<navigator class="cu-form-group " url="log-list" :url="'/pages/public/webview/webview?title=用户协议&url='+config.protocolUrl">
				<view class="title text-darkgrey cuIcon-profile" ><text class="margin-left-xs">用户协议</text></view>
			</navigator>
		</form>
    </view>
</template>

<script>
	
	// 服务协议

	import __config from "@/config/env";
	const app = getApp();
    export default {
        onLoad() {
			
        },
		data() {
			return {
				globalData: app.globalData,
				config:__config,
				value: ''
			}
		},
		methods : {
			click(){
				
			}
		}
    }
</script>

<style>
	
</style>
