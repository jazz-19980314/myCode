<template>
    <view>
		<cu-custom :bgColor="globalData.bgColor" :isBack="true"><block slot="content"><text class="text-darkgrey">修改密码</text></block></cu-custom>
		<form ref="resetPasswordForm">
			<view>
				<view class="cu-form-group solid-top">
					<input name="inputOldPassword" :value="form.password" @input="form.password=$event.target.value" prop="password" placeholder="请输入原密码" :maxlength="16" type="password" ></input>
				</view>
			</view>
			<view>
				<view class="cu-form-group solid-top">
					<input name="inputNewPassword" :value="form.newpassword1" @input="form.newpassword1=$event.target.value" prop="newpassword1" placeholder="请输入新密码" :maxlength="16" type="password" ></input>
				</view>
			</view>
			<view>
				<view class="cu-form-group solid-top">
					<input name="confirmNewPassword" :value="form.newpassword2" @input="form.newpassword2=$event.target.value" prop="newpassword2"  placeholder="请再次输入新密码" :maxlength="16" type="password" ></input>
				</view>
			</view>
			<view class="padding-sm text-sm text-purple-grey"><text class="cuIcon-info margin-right-xs"></text>提示:修改密码成功后需要重新登录。</view>
		</form>
		<view class="padding">
			<button class="cu-btn block bg-blue margin-tb-sm lg shadow-blur round" @click="submitForm">提交</button>
		</view>
    </view>
</template>

<script>

	const app = getApp();

	import {editObj, bindPhone, getObj} from "@/api/upms/user"
	import service from '@/store/service';//存储相关数据服务util

	export default {
		components:{
		},
        computed: {
		},
        onLoad() {
			let user = service.getUser();
			this.form.username = user.username;
			this.form.avatar = user.avatar;
			this.form.email = user.email;
		},
		data() {
			return {
				globalData:app.globalData,
				chosen: '',
				timerId: null,
				form: {
					username: '',
					password: '',
					newpassword1: '',
					newpassword2: '',
					avatar: '',
					email: '',
				},

			};
		},
		methods: {
			submitForm: function(e){
				var that = this;
				if(this.validate()){
					editObj(this.form).then(response => {
						if (response.data) {
							uni.showToast({
								title: '修改成功，请重新登录'
							})
							service.removeRefreshToken();
							uni.reLaunch({
								url: '/pages/login/login'
							});
						} else {
							uni.showToast({
								icon: 'none',
								title: '修改失败'+response.data
							})
						}
					}).catch(() => {
						uni.showToast({
							icon: 'none',
							title: '修改失败'
						})
					})
				}

			},

			validate(){//验证
				let validate = true;
				let names = [
					{key: 'newpassword2', label:'确认密码'},
					{key: 'newpassword1', label:'新密码'},
					{key: 'password', label:'原密码'},
				];
				names.map(item => {
					if(!this.form[item.key]){
						validate = false;
						uni.showToast({
							icon: 'none',
							title: item.label + '不能为空'
						})
						return;
					}
				});
				if(validate&&this.form.newpassword1.length<6){
					validate = false;
					uni.showToast({
						icon: 'none',
						title: '密码不能小于6位'
					});
					return ;
				}
				if(validate&&this.form.newpassword1!=this.form.newpassword2){
					validate = false;
					uni.showToast({
						icon: 'none',
						title: '两次输入的密码不一致，请重新输入'
					});
					return;
				}
				return validate;
			},
		}
    }
</script>

<style scoped>

</style>
