<template >
    <view>
        <cu-custom :bgColor="globalData.bgColor" :isBack="true"><block slot="content"><text class="text-darkgrey">账户与安全</text></block></cu-custom>
        <view class="cu-list menu sm-border solid-top">
            <view class="cu-item arrow" @click="avatarClick">
                <view class="content">
                    <text class="cuIcon-pic text-darkgreyv"></text>
                    <text class="text-darkgrey">头像</text>
                </view>
                <view class="action">
                    <view class="cu-avatar round df" :style="[{ backgroundImage:'url(' + (form.avatar? form.avatar : '') + ')' }]"></view>
                </view>
            </view>
            <view class="cu-item" >
                <view class="content">
                    <text class="cuIcon-people text-darkgrey"></text>
                    <text class="text-darkgrey">用户名</text>
                </view>
                <view class="action">
                    <text class="text-purple-grey text-df">{{form.username}}</text>
                </view>
            </view>
            <view class="cu-item" >
                <view class="content">
                    <text class="cuIcon-mobile text-darkgrey"></text>
                    <text class="text-darkgrey">手机号码</text>
                </view>
                <view class="action">
                    <text class="text-purple-grey text-df">{{form.phone}}</text>
                </view>
            </view>
            <view class="cu-item " >
                <view class="content">
                    <text class="cuIcon-mail text-darkgrey"></text>
                    <text class="text-darkgrey">邮箱</text>
                </view>
                <view class="action text-right">
                    <input v-if="isEdit" placeholder="请输入邮箱地址" name="email"  :value="form.email"
                           @input="form.email=$event.target.value"></input>
                    <text v-else class="text-purple-grey text-df">{{form.email?form.email:''}}</text>
                </view>
            </view>
        </view>
        <view class="text-right padding">
            <navigator url="reset-password" class="text-blue text-df">修改密码</navigator>
        </view>
    </view>
</template>

<script>

    const app = getApp();
    import service from '@/store/service';//存储相关数据服务util
    import __config from '@/config/env';// 配置文件
    import {editObj, bindPhone, getObj} from "@/api/upms/user"

    export default {
        onLoad() {
            this.form = service.getUser();
        },
        onShow() {
            this.getUserInfo();
        },
        data() {
            return {
                globalData:app.globalData,
                value: '',
                isEdit: false,//是否是编辑状态
                bannerShow: false,
                userInfo: {},
                form:{}
            }
        },

        methods: {
            editClick(){
                this.isEdit = !this.isEdit;
                uni.setNavigationBarTitle({
                    title: '编辑用户信息'
                });
            },
            cancelClick(){
                this.isEdit = !this.isEdit;
                uni.setNavigationBarTitle({
                    title: '账户与安全'
                });
            },
            saveClick(){
                var that = this;

            },
            avatarClick(){
                //选择图片
                var that = this;
                uni.chooseImage({
                    count: 1,
                    success: (res) => {
                        if(res){
                            let filePaths = res.tempFilePaths[0];
                            uni.uploadFile({
                                url: __config.basePath + '/upms/file/upload?fileType=image&dir=user/',
                                filePath: filePaths,
                                name: 'file',
                                header:{
                                    'Authorization' : 'Bearer ' + that.globalData.access_token
                                },
                                success: (result) => {
                                    try{
                                        if(result.statusCode===200){
                                            let resultObject = JSON.parse(result.data);
                                            that.form.avatar = resultObject.link;
                                            that.submitUserInfo();
                                        }else {
                                            uni.showToast({
                                                title: '只能上传jpg/png文件，且不超过500kb',
                                                icon: 'none'
                                            })
                                        }
                                    }catch (e) {
                                        console.log(e)
                                    }
                                },
                                fail: (err) => {
                                    try{
                                        uni.showToast({
                                            title: '上传失败'+err,
                                            icon:'none'
                                        })
                                    }catch (e) {
                                        console.log(e)
                                    }
                                    console.log('upload file err: '+ JSON.stringify(err));
                                }
                            });
                        }
                    }
                })
            },
            submitUserInfo(){
                editObj(this.form).then(response => {
                    service.saveUserInfo(this.form);
                    uni.showToast({
                        title: '修改成功'
                    })
                }).catch(() => {
                    uni.showToast({
                        icon: 'none',
                        title: '修改失败'
                    })
                })
            },
            getUserInfo(){
                var that = this;

            }
        }
    }
</script>

<style>

</style>
