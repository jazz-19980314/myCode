<template>
	<view class="bg-white" style="height: 100vh;">
		<cu-custom :bgColor="globalData.bgColor" :isBack="true"><block slot="content"><text class="text-darkgrey">关于我们</text></block></cu-custom>
		<view class="flex padding justify-center margin-top-20" >
			<image src="../../static/logo.png" mode="aspectFit" class="logoimg"></image>
		</view>
		<view style="bottom: 0;">
			<view class="flex padding justify-center margin-top-20">
				<view class="text-darkgrey">Copyright 2020</view>
			</view>
			<view class="flex padding justify-center margin-top-20" @click="onAPPUpdate">
				<view class="text-blue" >V {{versionName}}</view>
			</view>
		</view>
	</view>
</template>

<script>

	const app = getApp();
	
	// #ifdef APP-PLUS
	import APPUpdate, { getCurrentNo } from "@/public/APPUpdate/index.js";
	// #endif

	export default {
		
		onLoad() {
			// #ifdef APP-PLUS
			getCurrentNo(res => {
				// 进页面获取当前APP版本号（用于页面显示）
				this.versionName = res.versionName;
			});
			// #endif
		
		},
		data() {
			return {
                globalData: app.globalData,
				versionName: '1.0.0'
			}
		},
		methods: {
			onAPPUpdate() {// 检查APP是否有新版本
				// true 没有新版本的时候有提示，默认：false
				APPUpdate(true);
			},
		}
	}
</script>
<style scoped>

	.logoimg {
		width: 300rpx;
		height: 300rpx;
	}

</style>
