<template>
	<view>
		<cu-custom :bgColor="globalData.bgColor" :isBack="true">
			<block slot="content"><text class="text-darkgrey">砍价记录详情</text></block>
		</cu-custom>
		<view>
			<view class="cu-card case">
				<view class="padding bg-white">
					<view class="flex justify-between">
						<view class="padding-bottom-sm">
							<text class="text-darkgrey text-df cuIcon-titles">{{data.shopId}}</text>
						</view>
						<view v-if="data.status==0" class="text-xs cu-tag light round bg-orange">砍价中</view>
						<view v-else-if="data.status==1" class="text-xs cu-tag light round bg-blue">完成砍价</view>
						<view v-else-if="data.status==2" class="text-xs cu-tag light round bg-red">已过期</view>
					</view>
					<view class="cu-list menu-avatar flex justify-between margin-top-xs align-center">
						<view class="cu-avatar head-box" :style="{'background-image':'url('+ (data.userInfo ? data.userInfo.headimgUrl : '')+')'}">
							<text v-if="!data.userInfo" class="cuIcon-peoplefill"></text>
						</view>
						<view class="content flex-sub padding-left  text-sm text-darkgrey">
							<view class="text-darkgrey text-df">用户编号：{{data.userInfo ? data.userInfo.userCode:''}}</view>
							<view class="text-purple-grey text-sm">用户昵称：{{data.userInfo ? data.userInfo.nickName : ''}}</view>
							<view class="text-purple-grey text-sm">商品名称：{{data.bargainInfo.goodsSpu.name}}</view>
						</view>
					</view>
					<view class="text-purple-grey text-sm margin-top-xs">砍价信息：{{data.bargainInfo.name}}</view>
					<view class="text-purple-grey text-sm">开始时间：{{data.validBeginTime}}</view>
					<view class="text-purple-grey text-sm">结束时间：{{data.validEndTime}}</view>
					<view class="text-purple-grey text-sm">砍价底价：¥{{data.bargainPrice}}</view>
					<view class="text-purple-grey text-sm">已砍金额：¥{{data.havBargainAmount}}</view>
					<view class="text-purple-grey text-sm">必须底价购买：{{data.floorBuy==0?'否':'是'}}</view>
					<view class="text-purple-grey text-sm">是否购买：{{data.isBuy==0?'否':'是'}}</view>
					<view class="text-purple-grey text-sm ">创建时间：{{data.createTime}}</view>
				</view>
			</view>
			<view class="cu-list goods-list margin-top-xs" v-if="dataList&&dataList.length>0">
				<view>
					<view class="bg-white padding">
						<text class="text-darkgrey margin-right-xs cuIcon-titles"></text>砍价明细
					</view>
				</view>
				<view class="cu-item radius bg-white margin-bottom-xs " v-for="data in dataList" :key="data.id">
					<view class="cu-list menu-avatar flex justify-between padding-left padding-bottom ">
						<view class="cu-avatar xl" :style="{'background-image':data.headimgUrl?'url('+data.headimgUrl+')':''}"></view>
						<view class="content flex-sub padding-left padding-right text-sm">
							<view class="flex justify-between">
								<view class="text-darkgrey text-df">
									<text class="cuIcon-people margin-right-xs"></text>{{data.nickName}}
								</view>
							</view>
							<view class="text-purple-grey margin-top-xs">砍价金额：¥{{data.cutPrice}}</view>
							<view class="text-purple-grey margin-top-xs">砍价时间：{{data.createTime}}</view>
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	const app = getApp();
	import {
		getObj,
		addObj,
		putObj,
		delObj
	} from '@/api/mall/bargainuser'
	import {
		getPage
	} from '@/api/mall/bargaincut'

	export default {
		onLoad(e) {
			if (e) {
				this.data = JSON.parse(e.data);
				this.getPage();
			}
		},
		data() {
			return {
				globalData: app.globalData,
				CustomBar: this.CustomBar,
				id: null,
				data: {},
				dataList: []
			}
		},
		methods: {
			getData() {
				getObj(this.id).then(response => {
					if (response.data) {
						this.data = response.data;
					}
				});
			},
			getPage() {
				let pageNum = 1; // 页码, 默认从1开始
				let pageSize = 9999; // 页长, 默认每页10条
				let querySearch = '?current=' + pageNum + '&size=' + pageSize + '&descs=create_time&bargainUserId=' + this.data.id;
				getPage(querySearch).then(response => {
					if (response.data) {
						this.dataList = response.data.records;
					}
				});
			},
		}
	}
</script>

<style>
	.img-box {
		width: 200rpx !important;
		height: 200rpx !important;
	}

	.button-bg {
		padding: 20rpx 40rpx 20rpx 40rpx;
	}

	.head-box {
		width: 200rpx;
		height: 200rpx;
	}
</style>
