<template>
    <view>
		<cu-custom :bgColor="globalData.bgColor" :isBack="true"><block slot="content"><text class="text-darkgrey">砍价配置查询</text></block></cu-custom>
        <mescroll-body ref="mescrollRef" @init="mescrollInit" @down="downCallback" @up="upCallback" :down="downOption" :up="upOption">
            <view >
                <view class="cu-list">
                    <view class="cu-item radius bg-white solid-top padding"  v-for="data in dataList" :key="data.id">
                        <view>
                            <view class="flex justify-between">
                                <view class="padding-bottom-sm">
                                    <text class="text-darkgrey text-df cuIcon-titles">{{data.shopId}}</text>
                                </view>
                                <view class="text-xs cu-tag light round" :class="data.enable==1?'bg-blue':'bg-red'">{{data.enable==1?'已启用':'已关闭'}}</view>
                            </view>
                            <view class="cu-list menu-avatar flex justify-between padding-bottom">
                                <view class="cu-avatar img-box" :style="{'background-image':data.picUrl?'url('+data.picUrl+')':''}"></view>
                                <view class="content flex-sub padding-left padding-right text-sm margin-top-sm">
                                    <view class="text-darkgrey text-df text-to-long" >{{data.name}}</view>
                                    <view class="text-purple-grey" >砍价底价：{{data.bargainPrice}}</view>
                                    <view class="text-purple-grey" >必须底价购买：{{data.floorBuy==0?'否':'是'}}</view>
                                </view>
                            </view>
                            <view class="text-purple-grey text-sm" >可砍最低金额：{{data.cutMin}}</view>
                            <view class="text-purple-grey text-sm" >可砍最低金额：{{data.cutMax}}</view>
                            <view class="text-purple-grey text-sm" >排序：{{data.sort}}</view>
                            <view class="text-purple-grey text-sm" >自砍一刀：{{data.selfCut==0?'关闭':'开启'}}</view>
                            <view class="text-purple-grey text-sm" >时间范围：{{data.validBeginTime}}{{' - '}}{{data.validEndTime}}</view>
                            <view class="text-purple-grey text-sm" >发起人数：{{data.launchNum}}</view>
                            <view class="text-purple-grey text-sm" >分享标题：{{data.shareTitle}}</view>
                            <view class="text-purple-grey text-sm" >砍价规则：{{data.cutRule}}</view>
                            <view class="text-purple-grey text-sm text-right">{{data.createTime}}</view>

                        </view>
                        <view v-if="globalData.permissions['mall:bargaininfo:edit']" class="margin-top-sm flex justify-end">
                            <button @click="changeEnable(data)" class="cu-btn round button-bg shadow-blur"  :class="data.enable==1?'bg-red':'bg-green'">{{data.enable==1?'关闭':'启用'}}</button>
                        </view>
                    </view>
                </view>
            </view>
        </mescroll-body>
    </view>
</template>

<script>
	
    // 引入mescroll-mixins.js
    import MescrollMixin from "@/components/mescroll-uni/mescroll-mixins.js";

    const app = getApp();
    import {getPage, getObj, addObj, putObj, delObj} from '@/api/mall/bargaininfo'

    export default {
        mixins: [MescrollMixin], // 使用mixin
        components: {},
		onLoad(e){
		},
        data() {
            return {
                globalData: app.globalData,
                CustomBar: this.CustomBar,
                inputKey:'',
                mescroll: null, // mescroll实例对象 (此行可删,mixins已默认)
                downOption: {// 下拉刷新的配置(可选, 绝大部分情况无需配置)

                },
                // 上拉加载的配置(可选, 绝大部分情况无需配置)
                upOption: {
                    page: {
                        size: 10 // 每页数据的数量,默认10
                    },
                    noMoreSize: 5, // 配置列表的总数量要大于等于5条才显示'-- END --'的提示
                    empty: {
                        tip: '暂无相关数据'
                    }
                },
                // 列表数据
                dataList: []
            }
        },
        methods: {
            changeEnable(row){
                let content = '确定要启用吗?';
                let enable = 1;
                if(row.enable==1){
                    enable = 0;
                    content = '确定要关闭吗?';
                }
                let that = this;
                uni.showModal({
                    title: '提示',
                    content: content,
                    success: function(res) {
                        if (res.confirm) {
                            putObj({
                                id: row.id,
                                enable: enable
                            }).then(data => {
                                uni.showToast({title:"操作成功"})
                                that.mescroll.resetUpScroll();
                            });
                        } else if (res.cancel) {}
                    }
                });

            },
            search (val) {
                this.mescroll.resetUpScroll();
            },
            /*mescroll组件初始化的回调,可获取到mescroll对象 (此处可删,mixins已默认)*/
            mescrollInit(mescroll) {
                this.mescroll = mescroll;
            },
            /*下拉刷新的回调, 有三种处理方式:*/
            downCallback(){
                this.mescroll.resetUpScroll(); // 重置列表为第一页 (自动执行 page.num=1, 再触发upCallback方法 )
                this.mescroll.endSuccess()
            },
            /*上拉加载的回调*/
            upCallback(page) {
                let pageNum = page.num; // 页码, 默认从1开始
                let pageSize = page.size; // 页长, 默认每页10条
                let querySearch = '?current='+pageNum+'&size='+pageSize+'&descs=create_time';
                if(this.inputKey){
                    querySearch = querySearch + '&name='+this.inputKey
                }
                getPage(querySearch).then(response=>{
                    if(response.data){
                        // 接口返回的当前页数据列表 (数组)
                        let curPageData = response.data.records;
                        // 接口返回的当前页数据长度 (如列表有26个数据,当前页返回8个,则curPageLen=8)
                        let curPageLen = curPageData.length;
                        // 接口返回的总数据量(如列表有26个数据,每页10条,共3页; 则totalSize=26)
                        let totalSize = response.data.total;
                        //设置列表数据
                        if(page.num == 1) this.dataList = []; //如果是第一页需手动置空列表
                        this.dataList = this.dataList.concat(curPageData); //追加新数据
                        // 请求成功,隐藏加载状态
                        this.mescroll.endBySize(curPageLen, totalSize);
                        setTimeout(()=>{
                            this.mescroll.endSuccess(curPageLen)
                        },20)

                    }
                });
            }
        }
    }
</script>

<style>
	.img-box{
		width: 200rpx;
		height: 200rpx;
	}
</style>
