<template>
	<view>
		<cu-custom :bgColor="globalData.bgColor" :isBack="true">
			<block slot="content"><text class="text-darkgrey">退款详情</text></block>
		</cu-custom>
		<view>
			<view class="cu-card case">
				<view class="padding-left padding-right padding-top bg-white solid-top">
					<view class="flex justify-between align-center">
						<navigator :url="'../order/detail?id='+orderItemObj.orderId" class="text-darkgrey">
							<text class="text-sm cuIcon-titles">订单编号:{{orderNo}}</text>
						</navigator>
						<view class="text-xs cu-tag light bg-orange round">{{orderItemObj.statusDesc}}</view>
					</view>
				</view>
			</view>
			<!-- 商品 -->
			<view class="case bg-white padding-top-xs padding-left padding-right padding-bottom">
				<view class="flex justify-between align-center">
					<view class="cu-avatar img-box" :style="{'background-image':orderItemObj.picUrl?'url('+orderItemObj.picUrl+')':''}"></view>
					<view class="content flex-sub padding-left padding-right text-sm">
						<view class="text-darkgrey text-to-long">{{orderItemObj.spuName}}</view>
						<view class="text-purple-grey flex justify-between margin-top-xs">
							<text>规格：{{orderItemObj.specInfo?orderItemObj.specInfo:'单规格'}}</text>
							<text>x{{orderItemObj.quantity}}</text>
						</view>
						<view class=" margin-top-xs flex justify-between">
							<view class="text-darkgrey">支付金额：<text class="text-red text-xl text-bold text-price">{{orderItemObj.paymentPrice}}</text></view>
						</view>
					</view>
				</view>
				<view class="text-sm margin-top-xs padding-bottom">
					<view class="text-sm text-purple-grey padding-top-sm margin-bottom-xs">退款流水号：{{orderItemObj.refundTradeNo}}</view>
					<view class="text-sm text-purple-grey margin-bottom-xs">是否退款：<text class="">{{orderItemObj.isRefund == '1' ? '是' : '否'}}</text>
						<text class="text-xs text-purple-grey margin-left-xs">(“是“则代表退款金额已成功到达用户账上)</text></view>
					<view class="text-sm text-purple-grey margin-bottom-xs">退款原因：<text class="">{{orderItemObj.refundReson}}</text></view>
					<view class="text-df text-black">
						<view class=" text-red">订单金额：<text class="text-price text-red margin-right-xs">{{orderItemObj.quantity * orderItemObj.salesPrice}}</text></view>
						<view class=" text-red">运费金额：<text class="text-price text-red margin-right-xs">{{orderItemObj.freightPrice}}</text></view>
						<view class="text-red" v-if="orderItemObj.listOrderRefunds">退款金额：<text class="text-price text-red margin-right-xs">{{orderItemObj.listOrderRefunds[0].refundAmount}}</text></view>
						<view class="text-red">退款积分：<text class="text-price text-red margin-right-xs">{{orderItemObj.paymentPoints}}</text></view>
					</view>
					<view class="text-sm text-purple-grey padding-top-xs">{{orderItemObj.createTime}}</view>
				</view>
				<view v-if="globalData.permissions['mall:orderrefunds:edit']">
					<view class="text-sm flex justify-end" v-if="orderItemObj.status==1">
						<view class="cu-btn round bg-blue shadow-blur margin-right-sm button-bg" @tap="orderRefundsSubmit">同意退款</view>
						<view class="cu-btn round bg-blue shadow-blur margin-right-sm button-bg" @tap="showModal=true">不同意退款</view>
					</view>
					<view class="text-sm flex justify-end" v-else-if="orderItemObj.status==2">
						<view class="cu-btn round bg-blue sm margin-right-sm" @tap="orderRefundsSubmit">等待退货</view>
						<view class="cu-btn round bg-blue sm margin-right-sm" @tap="showModal=true">拒绝退货退款</view>
					</view>
					<view class=" text-sm   solid-top padding-top-sm flex justify-end" v-else-if="orderItemObj.status==21">
						<view class="cu-btn round bg-blue sm margin-right-sm" @tap="orderRefundsSubmit">收到退货同意退款</view>
						<view class="cu-btn round bg-blue sm margin-right-sm" @tap="showModal=true">收到退货拒绝退款</view>
					</view>
				</view>
			</view>
			<!-- 不同意弹框 -->
			<view class="cu-modal" :class="showModal?'show':''">
				<view class="cu-dialog">
					<view class="cu-bar bg-white justify-end">
						<view class="content">拒绝原因</view>
						<view class="action" @tap="showModal=false">
							<text class="cuIcon-close text-red"></text>
						</view>
					</view>
					<view class="padding bg-white">
						<input placeholder="请输入不同意原因" type="text" name="refuseRefundReson" @input="refuseRefundReson=$event.target.value"
						 :value="refuseRefundReson"></input>
					</view>
					<view class="cu-bar bg-white justify-end">
						<view class="action">
							<button class="cu-btn line-green text-green" @tap="showModal=false">取消</button>
							<button class="cu-btn bg-green margin-left" @tap="orderRefundsSubmit">确定</button>
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	const app = getApp();
	import {
		getPage,
		getObj,
		addObj,
		putObj,
		doOrderRefunds
	} from '@/api/mall/orderrefunds'
	import {
		getObj as getOrderItem
	} from '@/api/mall/orderitem'

	export default {
		onLoad(e) {
			if (e) {
				if (e.orderItemId) {
					this.orderItemId = e.orderItemId;
					this.getOrderItem();
				}
				if (e.orderNo) {
					this.orderNo = e.orderNo;
				}
			}
		},
		data() {
			return {
				globalData: app.globalData,
				CustomBar: this.CustomBar,
				id: null,
				orderItemId: null,
				orderItemObj: {},
				orderNo: null,
				data: {
					orderInfo: {}
				},
				showModal: false,
				refuseRefundReson: '', //拒绝原因
				editPriceForm: {
					id: null,
					paymentPrice: 0
				}
			}
		},
		methods: {
			orderRefundsSubmit() {
				let orderRefunds = this.orderItemObj.listOrderRefunds[0];
				if (this.showModal) { // 拒绝
					if (!this.refuseRefundReson) {
						uni.showToast({
							title: "请填写拒绝原因",
							icon: "none"
						})
						return;
					}
					if (this.orderItemObj.status == 1) {
						orderRefunds.status = 12;
					} else if (this.orderItemObj.status == 2) {
						orderRefunds.status = 22;
					} else if (this.orderItemObj.status == 21) {
						orderRefunds.status = 212;
					}
					orderRefunds.refuseRefundReson = this.refuseRefundReson;
				} else {
					if (this.orderItemObj.status == 1) {
						orderRefunds.status = 11;
					} else if (this.orderItemObj.status == 2) {
						orderRefunds.status = 21;
					} else if (this.orderItemObj.status == 21) {
						orderRefunds.status = 211;
					}
				}

				doOrderRefunds(orderRefunds).then(res => {
					this.showModal = false;
					uni.showToast({
						title: "操作成功",
					})
					uni.navigateBack({

					})
				}).catch(() => {
					this.showModal = false
				})
			},
			getData() {
				getObj(this.id).then(response => {
					if (response.data) {
						// this.data = response.data;
					}
				});
			},
			getOrderItem() {
				getOrderItem(this.orderItemId).then(response => {
					if (response.data) {
						this.orderItemObj = response.data;
					}
				});
			}
		}
	}
</script>

<style>
	.img-box {
		width: 200rpx !important;
		height: 200rpx !important;
	}

	.button-bg {
		padding: 20rpx 40rpx 20rpx 40rpx;
	}
</style>
