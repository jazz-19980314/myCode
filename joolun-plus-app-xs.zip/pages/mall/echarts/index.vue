<template>
	<view class="">
		<cu-custom :bgColor="globalData.bgColor" :isBack="true">
			<block slot="content"><text class="text-darkgrey">销量统计</text></block>
		</cu-custom>
		<view class="flex padding align-center justify-between">
			<view class="text-black">
				选择店铺
			</view>
			<picker v-if="shopList.length" @change="PickerChange" :value="index" :range="shopList" range-key="name">
				<view class="flex justify-between">
					<text style="">{{shopList[index].name||'请选择店铺'}}</text>
					<text class="cuIcon-triangledownfill text-xxl text-bold"></text>
				</view>
			</picker>
		</view>
		<scroll-view scroll-x class="bg-blue nav" scroll-with-animation>
			<view class="cu-item" :class="index==TabCur?'text-red':''" v-for="(item,index) in tabList" :key="index" @tap="tabSelect"
			 :data-id="index">
				{{item.title}}
			</view>
		</scroll-view>
		<view class="qiun-columns">
			<view class="qiun-charts">
				<canvas canvas-id="canvasLineA" id="canvasLineA" class="charts" @touchstart="touchLineA"></canvas>
			</view>
		</view>
	</view>
</template>

<script>
	const app = getApp()
	import {
		getPage
	} from '@/api/mall/shopinfo'
	import uCharts from '@/components/u-charts/u-charts.js';
	var _self;
	var canvaLineA = null;
	export default {
		data() {
			return {
				cWidth: '',
				cHeight: '',
				pixelRatio: 1,
				globalData: app.globalData,
				CustomBar: this.CustomBar,
				TabCur: 0,
				shopList: [],
				index: 0,
				tabList: [{
					title: "最近半年",
					type: 1
				}, {
					title: "最近七天",
					type: 0
				}],
				page: {
					num: 1,
					size: -1
				}
			}
		},
		onLoad() {
			this.getShopList(this.page)
			_self = this;
			this.cWidth = uni.upx2px(750);
			this.cHeight = uni.upx2px(500);
			this.getServerData();
		},
		methods: {
			getServerData() {
				uni.request({
					url: 'https://www.ucharts.cn/data.json',
					data: {},
					success: function(res) {
						// console.log(res.data.data)
						let LineA = {
							categories: [],
							series: []
						};
						//这里我后台返回的是数组，所以用等于，如果您后台返回的是单条数据，需要push进去
						LineA.categories = res.data.data.LineA.categories;
						LineA.series = res.data.data.LineA.series;
						_self.showLineA("canvasLineA", LineA);
					},
					fail: () => {
						_self.tips = "网络错误，小程序端请检查合法域名";
					},
				});
			},
			showLineA(canvasId, chartData) {
				canvaLineA = new uCharts({
					$this: _self,
					canvasId: canvasId,
					type: 'line',
					fontSize: 11,
					legend: {
						show: true
					},
					dataLabel: false,
					dataPointShape: true,
					background: '#FFFFFF',
					pixelRatio: _self.pixelRatio,
					categories: chartData.categories,
					series: chartData.series,
					animation: true,
					xAxis: {
						type: 'grid',
						gridColor: '#CCCCCC',
						gridType: 'dash',
						dashLength: 8,
					},
					yAxis: {
						gridType: 'dash',
						gridColor: '#CCCCCC',
						dashLength: 8,
						splitNumber: 5,
						min: 10,
						max: 180,
						format: (val) => {
							return val.toFixed(0) + '元'
						}
					},
					width: _self.cWidth * _self.pixelRatio,
					height: _self.cHeight * _self.pixelRatio,
					extra: {
						line: {
							type: 'straight'
						}
					}
				});
			},
			touchLineA(e) {
				canvaLineA.showToolTip(e, {
					format: function(item, category) {
						return category + ' ' + item.name + ':' + item.data
					}
				});
			},
			PickerChange(e) {
				this.index = e.detail.value
				// this.form.shopId = this.shopList[e.detail.value].id
			},
			tabSelect(e) {
				this.TabCur = e.currentTarget.dataset.id;
				// this.scrollLeft = (e.currentTarget.dataset.id - 1) * 60
			},
			getShopList(page) {
				let pageNum = page.num; // 页码, 默认从1开始
				let pageSize = page.size; // 页长, 默认每页10条
				let querySearch = '?current=' + pageNum + '&size=' + pageSize + '&descs=create_time';
				getPage(querySearch).then(response => {
					if (response.data) {
						let curPageData = response.data.records;
						this.shopList = curPageData
					}
				});
			}
		}
	}
</script>

<style>
	.echarts {
		margin-top: 20px;
		width: 100%;
		height: 300px;
	}

	.qiun-charts {
		width: 750upx;
		height: 500upx;
		background-color: #FFFFFF;
	}

	.charts {
		width: 750upx;
		height: 500upx;
		background-color: #FFFFFF;
	}
</style>
