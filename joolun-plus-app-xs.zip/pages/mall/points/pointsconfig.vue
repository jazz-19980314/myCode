<template>
    <view>
		<cu-custom :bgColor="globalData.bgColor" :isBack="true"><block slot="content"><text class="text-darkgrey">积分配置</text></block></cu-custom>
        <view >
            <form>
                <view class="cu-form-group solid-top">
                    <view class="title text-darkgrey"><text class="text-red">*</text>用户初始积分</view>
                    <input class="text-right" placeholder="用户初始积分" name="initPosts" type="number"
                           @input="form.initPosts=$event.target.value"
                           :value="form.initPosts"></input>
                </view>
                <view class="cu-form-group">
                    <view class="title text-darkgrey"><text class="text-red">*</text>会员初始积分</view>
                    <input class="text-right" placeholder="新会员的初始积分数" name="initVipPosts"  type="number"
                           @input="form.initVipPosts=$event.target.value"
                           :value="form.initVipPosts"></input>
                </view>
                <view class="cu-form-group text-darkgrey">
                    <view class="title"><text class="text-red">*</text>订单满</view>
                    <input class="text-right" placeholder="订单金额（不包含运费）满多少可使用抵扣" name="initVipPosts"  type="number"
                           @input="form.premiseAmount=$event.target.value"
                           :value="form.premiseAmount"></input>
                </view>
                <view class="cu-form-group margin-top-xs text-darkgrey">
                    <view class="title"><text class="text-red">*</text>抵扣比例</view>
                    <input class="text-right" placeholder="抵扣比例" name="defaultDeductScale"  type="number" min="0" max="100"
                           @input="form.defaultDeductScale=$event.target.value"
                           :value="form.defaultDeductScale"></input>
                </view>
                <view class="text-sm text-purple-grey padding-top-xs padding-bottom-xs padding-left padding-right"><text class="cuIcon-info"></text>积分可抵扣商品金额比例（0~100）%，可在不同的商品中设置不同的抵扣比例</view>

                <view class="cu-form-group text-darkgrey">
                    <view class="title"><text class="text-red">*</text>抵扣规则</view>
                    <input class="text-right" placeholder="抵扣规则" name="defaultDeductAmount"  type="number"
                           @input="form.defaultDeductAmount=$event.target.value"
                           :value="form.defaultDeductAmount"></input>
                </view>
                <view class="text-sm text-purple-grey padding-top-xs padding-bottom-xs padding-left padding-right"><text class="cuIcon-info"></text>默认1积分数可抵多少元，可在不同的商品中设置不同的抵扣规则</view>

            </form>

            <view class="padding-xl flex flex-direction" v-if="globalData.permissions['mall:pointsconfig:edit']">
                <button class="cu-btn bg-blue shadow-blur round lg" @tap="submit">提交</button>
            </view>
        </view>
    </view>
</template>

<script>

    const app = getApp();
    import {getPage, getObj, addObj, putObj, delObj, getObj2} from '@/api/mall/pointsconfig'

    export default {
        onLoad(e){
            this.getData();
        },
        data() {
            return {
                globalData: app.globalData,
                CustomBar: this.CustomBar,
                id: null,
                form:{
                    defaultDeductAmount: 0,
                    defaultDeductScale: 0,
                    initPosts: 0,
                    initVipPosts:0,
                    premiseAmount: 0,
                },
                index: 0
            }
        },
        methods: {
            submit(){
                if(this.validate()){
                    if(this.form.defaultDeductScale>100){
                        uni.showToast({
                            icon: 'none',
                            title: '抵扣比例不能大于100'
                        });
                        return;
                    }
                    putObj(this.form).then(response=>{
                        if(response.data){
                            uni.showToast({title:'提交成功'})
                            uni.navigateBack({

                            })
                        }
                    });
                }
            },
            validate(){//验证
                let validate = true;
                let names = [
                    {key: 'defaultDeductAmount', label:'抵扣规则'},
                    {key: 'defaultDeductScale', label:'抵扣比例'},
                    {key: 'premiseAmount', label:'订单金额'},
                    {key: 'initVipPosts', label:'新会员的初始积分数'},
                    {key: 'initPosts', label:'用户初始积分'},
                ];
                names.map(item => {
                    if(!(this.form[item.key]&&this.form[item.key]>=0)){
                        validate = false;
                        uni.showToast({
                            icon: 'none',
                            title: item.label + '不能为空并且大于等于0'
                        });
                        return;
                    }
                });
                return validate;
            },
            getData(){
                getObj2().then(response => {
                    this.form = response.data ? response.data : {}
                })
            }
        }
    }
</script>

<style>
    .cu-form-group .title {
        min-width: calc(4em + 15px);
    }
</style>
