<template>
	<view>
		<cu-custom :bgColor="globalData.bgColor" :isBack="true"><block slot="content"><text class="text-darkgrey">订单发货</text></block></cu-custom>
		<view>
			<form>
				<view class="cu-form-group">
					<view class="title text-darkgrey">订单号</view>
					<input class="text-right" disabled name="orderNo" :value="form.orderNo"></input>
				</view>
				<view class="cu-form-group">
					<view class="title text-darkgrey">收货人</view>
					<input class="text-right" placeholder="收货人名字" name="userName" disabled
						@input="form.orderLogistics.userName=$event.target.value"
						:value="form.orderLogistics.userName"></input>
				</view>
				<view class="cu-form-group">
					<view class="title text-darkgrey">电话号码</view>
					<input class="text-right" placeholder="收货人电话号码" name="telNum" disabled
						@input="form.orderLogistics.telNum=$event.target.value"
						:value="form.orderLogistics.telNum"></input>
				</view>
				<view class="cu-form-group">
					<view class="title text-darkgrey">地址</view>
					<textarea maxlength="-1" placeholder="收货地址"  name="address" disabled
						@input="form.orderLogistics.address=$event.target.value"
						:value="form.orderLogistics.address"></textarea>
				</view>
				<view class="cu-form-group margin-top">
					<view class="title text-darkgrey">快递公司</view>
					<picker @change="pickerChange" :value="index" :range="orderlogistics" :range-key="'label'">
						<view class="picker">
							{{form.logistics?orderlogistics[index].label:'请选择'}}
						</view>
					</picker>
				</view>
				<view class="cu-form-group">
					<view class="title text-darkgrey">快递单号</view>
					<input class="text-right" placeholder="快递单号" name="logisticsNo"
						@input="form.logisticsNo=$event.target.value"
						:value="form.logisticsNo"></input>
					<text class="cuIcon-scan text-grey" @click="scan('pad')"></text>
				</view>
			</form>
			<view class="padding-xl flex flex-direction">
				<button class="cu-btn bg-blue round lg shadow-blur" @tap="submit">提交</button>
			</view>
		</view>
	</view>
</template>

<script>

	const app = getApp();

    import {getPage, getObj, addObj, putObj, delObj, editPrice, orderCancel, takeGoods} from '@/api/mall/orderinfo'
	import api from '@/api/api';
	
	import permision from "@/public/app-plus/permission.js";
	export default {
		components:{
		},
		onLoad(e){
			if(e){
				this.id = e.id;
				this.getOrderlogistics();
				this.getData();
			}
		},
		data() {
			return {
                globalData: app.globalData,
				CustomBar: this.CustomBar,
				id: null,
				orderlogistics:[],//快递公司
				form:{
					logistics: null,
					logisticsNo: '',
					orderLogistics:{}
				},
				index: 0
			}
		},
		methods: {
			submit(){
				if(this.validate()){
					this.form.status = '2',
					putObj(this.form).then(response=>{
					    if(response.data){
							uni.showToast({title:'提交成功'})
							uni.navigateBack({

							})
					    }
					});
				}
			},
			validate(){//验证
				let validate = true;
				let names = [
					{key: 'logisticsNo', label:'快递单号'},
					{key: 'logistics', label:'快递公司'},
				];
				names.map(item => {
					if(!this.form[item.key]){
						validate = false;
						uni.showToast({
							icon: 'none',
							title: item.label + '不能为空'
						})
						return;
					}
				})
				return validate;
			},
			pickerChange(value){
				if(value){
					this.index = value.target.value;
					this.form.logistics = this.orderlogistics[value.target.value].value;
				}
			},
			getOrderlogistics(){
				api.mall.orderlogistics().then(response=>{
				    if(response.data){
				        this.orderlogistics = response.data;
				    }
				});
			},
			getData(){
				getObj(this.id).then(response=>{
				    if(response.data){
				        this.form = response.data;
				    }
				});
			},
			async scan(model = 'pad') {
				// #ifdef APP-PLUS
				let status = await this.checkPermission();
				if (status !== 1) {
					return;
				}
				// #endif
				let that = this;
				uni.scanCode({
					scanType:["qrCode","barCode"],
					onlyFromCamera: true,
					success: (res) => {
						// console.log("res: " + JSON.stringify(res));
						that.form.logisticsNo = res.result;
					},
					fail: (err) => {
						// #ifdef MP
						uni.getSetting({
							success: (res) => {
								let authStatus = res.authSetting['scope.camera'];
								if (!authStatus) {
									uni.showModal({
										title: '授权失败',
										content: '需要使用您的相机，请在设置界面打开相关权限',
										success: (res) => {
											if (res.confirm) {
												uni.openSetting()
											}
										}
									})
								}
							}
						})
						// #endif
					}
				});
			},
			// #ifdef APP-PLUS
			async checkPermission(code) {
				let status = permision.isIOS ? await permision.requestIOS('camera') :
					await permision.requestAndroid('android.permission.CAMERA');
			
				if (status === null || status === 1) {
					status = 1;
				} else {
					uni.showModal({
						content: "需要相机权限",
						confirmText: "设置",
						success: function(res) {
							if (res.confirm) {
								permision.gotoAppSetting();
							}
						}
					})
				}
				return status;
			},
			// #endif
		}
	}
</script>

<style>
	.cu-form-group .title {
		min-width: calc(4em + 15px);
	}

	.cu-form-group input{
		color: #b2b7cd;
		font-size: 28rpx;
	}

	.cu-form-group textarea{
		color: #b2b7cd;
		font-size: 28rpx;
	}

	.cu-form-group picker{
		color: #b2b7cd;
		font-size: 28rpx;
	}
</style>
