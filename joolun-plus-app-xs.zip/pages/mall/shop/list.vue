<template>
	<view>
		<cu-custom :bgColor="globalData.bgColor" :isBack="true">
			<block slot="content">店铺设置</block>
		</cu-custom>
		<view class="search flex bg-white fixed padding-top-sm solid-bottom">
		    <view class="search-content round">
		        <text class="cuIcon-search padding-right-xs margin-left"></text>
		        <input type="text" placeholder="输入店铺全名搜索" v-model="inputKey" confirm-type="search"></input>
		    </view>
		    <view class="action">
		        <button class="cu-btn bg-blue round search-button margin-right-sm" @click="search">搜索</button>
		    </view>
		</view>
		<mescroll-body ref="mescrollRef" @init="mescrollInit" @down="downCallback" @up="upCallback" :down="downOption" :up="upOption">
			<view class="cu-list shop-list">
				<view class="cu-item radius bg-white solid-top" v-for="data in dataList" :key="data.id">
					<view class="cu-list menu-avatar flex justify-between padding align-center">
						<view class="cu-avatar xl" :style="{'background-image':'url('+data.imgUrl+')'}"></view>
						<view class="content flex-sub padding-left text-sm">
							<view class="flex justify-between">
								<view class="text-darkgrey text-to-long text-df text-darkgrey">{{data.name}}</view>
								<view class="margin-bottom-xs">
									<view class="text-xs cu-tag light round" :class="data.enable==1?'bg-cyan':'bg-red'">{{data.enable==1?'启用':'关闭'}}</view>
								</view>
							</view>
							<view class="text-sm text-purple-grey flex justify-between">
								{{data.address}}
							</view>
						</view>
					</view>
				</view>
			</view>
		</mescroll-body>
	</view>
</template>

<script>
	// 引入mescroll-mixins.js
	import MescrollMixin from "@/components/mescroll-uni/mescroll-mixins.js";

	const app = getApp();
	import {
		getPage
	} from '@/api/mall/shopinfo'

	export default {
		mixins: [MescrollMixin], // 使用mixin
		components: {},
		data() {
			return {
				globalData: app.globalData,
				CustomBar: this.CustomBar,
				inputKey: '',
				mescroll: null, // mescroll实例对象 (此行可删,mixins已默认)
				downOption: { // 下拉刷新的配置(可选, 绝大部分情况无需配置)

				},
				// 上拉加载的配置(可选, 绝大部分情况无需配置)
				upOption: {
					page: {
						size: 10 // 每页数据的数量,默认10
					},
					noMoreSize: 5, // 配置列表的总数量要大于等于5条才显示'-- END --'的提示
					empty: {
						tip: '暂无相关数据'
					}
				},
				// 列表数据
				dataList: []
			}
		},
		methods: {
			search(val) {
				this.mescroll.resetUpScroll();
			},
			/*mescroll组件初始化的回调,可获取到mescroll对象 (此处可删,mixins已默认)*/
			mescrollInit(mescroll) {
				this.mescroll = mescroll;
			},
			/*下拉刷新的回调, 有三种处理方式:*/
			downCallback() {
				this.mescroll.resetUpScroll(); // 重置列表为第一页 (自动执行 page.num=1, 再触发upCallback方法 )
				this.mescroll.endSuccess()
			},
			/*上拉加载的回调*/
			upCallback(page) {
				let pageNum = page.num; // 页码, 默认从1开始
				let pageSize = page.size; // 页长, 默认每页10条
				let querySearch = '?current=' + pageNum + '&size=' + pageSize + '&descs=create_time';
				if (this.inputKey) {
					querySearch = querySearch + '&name=' + this.inputKey
				}
				getPage(querySearch).then(response => {
					if (response.data) {
						// 接口返回的当前页数据列表 (数组)
						let curPageData = response.data.records;
						// 接口返回的当前页数据长度 (如列表有26个数据,当前页返回8个,则curPageLen=8)
						let curPageLen = curPageData.length;
						// 接口返回的总数据量(如列表有26个数据,每页10条,共3页; 则totalSize=26)
						let totalSize = response.data.total;
						//设置列表数据
						if (page.num == 1) this.dataList = []; //如果是第一页需手动置空列表
						this.dataList = this.dataList.concat(curPageData); //追加新数据
						// 请求成功,隐藏加载状态
						this.mescroll.endBySize(curPageLen, totalSize);
						setTimeout(() => {
							this.mescroll.endSuccess(curPageLen)
						}, 20)

					}
				});
			}
		}
	}
</script>

<style>
	.search{
		width: 100%;
		padding-bottom: 20rpx;
		position: fixed;
		z-index: 1024;
	}
	
	.search-content{
		background-color: #f5f5f5;
		line-height: 64upx;
		height: 64upx;
		font-size: 24upx;
		color: #333333;
		flex: 1;
		display: flex;
		align-items: center;
		margin: 0 30upx;
	}
	
	.search-content input{
		flex: 1;
		padding-right: 30upx;
		height: 64upx;
		line-height: 64upx;
		font-size: 26upx;
		background-color: transparent;
	}

	.search-button {
		padding: 10rpx 30rpx 10rpx 30rpx;
	}
	
	.shop-list{
		margin-top: 100rpx;
	}
</style>
