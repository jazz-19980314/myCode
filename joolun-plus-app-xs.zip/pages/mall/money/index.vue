<template>
	<view class="" style="background-color: #F5F5F5;">
		<cu-custom :bgColor="globalData.bgColor" :isBack="true">
			<block slot="content"><text class="text-darkgrey">资金结算</text></block>
		</cu-custom>
			<view class="turnover padding-sm">
				<view class="storefront">
					<view class="flex">
						<view class="flex align-center">
							<view class="">
								<view class="text-df text-bold text-white text-left shop-name">可结算金额</view>
							</view>
						</view>
					</view>
					<view class="margin-top-sm text-center flex justify-between align-center">
						<view class="text-price text-xl text-white text-bold">
							<text class="text-sl text-white text-bold">{{PaymentPriceSum | moneyFormat}}</text>
						</view>
						<navigator url="/pages/mall/money/records">
							<button class="cu-btn bg-white text-blue lg">结算记录</button>
						</navigator>
					</view>
					<view class="margin-top-sm text-center flex justify-between align-center" v-if="false">
						<view class="text-white">
							<text class="cuIcon-title"></text><text class="text-white">总结算金额2.00</text>
						</view>
						<view class="text-white">
							<text class="cuIcon-title"></text><text class="text-white">已结算金额2.00</text>
						</view>
					</view>
				</view>
			</view>
			<!-- 资金明细 -->
			<mescroll-body ref="mescrollRef" @init="mescrollInit" @down="downCallback" @up="upCallback" :down="downOption" :up="upOption">
			<view class="main">
				<view style="color: #999999;" class="flex justify-between align-center">
					<view>
						<text class="cuIcon-moneybagfill text-blue text-xl margin-right-sm"></text>
						<text class="text-bold">分润明细</text>
					</view>
					<view>
						<uni-calendar ref="calendar" :range="true" :insert="false" @confirm="confirm" :lunar="true" />
						<text @click="open">时间统计</text><text class="cuIcon-triangledownfill text-xl text-bold"></text>
					</view>
				</view>
				<view class="main_1 radius" style="border-radius: 20px;">
					<!-- <navigator url="/pages/mall/money/details"> -->
						<view class="cu-item radius bg-white solid-top" v-for="(data,index) in dataList" :key="index">
							<view class="cu-list flex justify-between padding align-center">
								<view class="content flex-sub padding-left text-sm">
									<view class="flex justify-between">
										<view class="text-darkgrey text-to-long text-df">{{data.createTime}}</view>
									</view>
									<!-- <view class="text-sm text-purple-grey flex justify-between">
										2020-11-1
									</view> -->
								</view>
								<view class="text-bold text-black text-price">{{data.amount}}</view>
							</view>
						</view>
					<!-- </navigator> -->
				</view>
			</view>
		</mescroll-body>
		<navigator url="/pages/mall/money/confirm">
			<button class="cu-btn bg-blue round lg declre">申请结算</button>
		</navigator>
	</view>
</template>

<script>
	const app = getApp()
	import MescrollMixin from "@/components/mescroll-uni/mescroll-mixins.js";
	import uniCalendar from '@/components/uni-calendar/uni-calendar.vue'
	import {getPage} from '@/api/mall/shopprofit.js'
	import {
		getPage as shopinfo
	} from '@/api/mall/shopinfo'
	export default {
		mixins: [MescrollMixin], // 使用mixin
		data() {
			return {
				globalData: app.globalData,
				CustomBar: this.CustomBar,
				PaymentPriceSum:0,
				dataList:[],
				downOption: {// 下拉刷新的配置(可选, 绝大部分情况无需配置)
				
				},
				// 上拉加载的配置(可选, 绝大部分情况无需配置)
				upOption: {
				    page: {
				        size: 10 // 每页数据的数量,默认10
				    },
				    noMoreSize: 5, // 配置列表的总数量要大于等于5条才显示'-- END --'的提示
				    empty: {
				        tip: '暂无相关数据'
				    }
				},
				startTime:'',
				endTime:'',
			}
		},
		components: {
			uniCalendar
		},
		methods: {
			open() {
				this.$refs.calendar.open();
			},
			confirm(e) {
				if(e.range.after){
					this.startTime = e.range.data[0]
					this.endTime = e.range.data[e.range.data.length-1]
				}else{
					this.startTime = e.fulldate
					this.endTime = e.fulldate
				}
				this.mescroll.resetUpScroll();
			},
			getShopInfo(){
				shopinfo().then(res=>{
					if (res.data) {
						// 接口返回的当前页数据列表 (数组)
						let curPageData = res.data.records;
						console.log(curPageData)
						this.PaymentPriceSum = curPageData[0].wallet
					}
				})
			},
			/*下拉刷新的回调 */
			downCallback(){
			    // this.mescroll.resetUpScroll(); // 重置列表为第一页 (自动执行 page.num=1, 再触发upCallback方法 )
			    this.mescroll.endSuccess()
			},
			/*上拉加载的回调*/
			upCallback(page) {
			    let pageNum = page.num; // 页码, 默认从1开始
			    let pageSize = page.size; // 页长, 默认每页10条
			    let querySearch = '?current='+pageNum+'&size='+pageSize+'&descs=create_time';
			    if(this.endTime && this.startTime){
			        querySearch = querySearch + '&startTime='+this.startTime+ '&endTime='+this.endTime
			    }
			    getPage(querySearch).then(response=>{
			        if(response.data){
			            // 接口返回的当前页数据列表 (数组)
			            let curPageData = response.data.records;
						// console.log(curPageData)
			            // 接口返回的当前页数据长度 (如列表有26个数据,当前页返回8个,则curPageLen=8)
			            let curPageLen = curPageData.length;
			            // 接口返回的总数据量(如列表有26个数据,每页10条,共3页; 则totalSize=26)
			            let totalSize = response.data.total;
			            //设置列表数据
			            if(page.num == 1) this.dataList = []; //如果是第一页需手动置空列表
			            this.dataList = this.dataList.concat(curPageData); //追加新数据
			            // 请求成功,隐藏加载状态
			            this.mescroll.endBySize(curPageLen, totalSize);
			            setTimeout(()=>{
			                this.mescroll.endSuccess(curPageLen)
			            },20)
			        }
			    });
				shopinfo().then(res=>{
					if (res.data) {
						// 接口返回的当前页数据列表 (数组)
						let curPageData = res.data.records;
						// console.log(curPageData)
						this.PaymentPriceSum = curPageData[0].wallet
					}
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.turnover {
		width: 88%;
		height: 300rpx;
		margin: 20rpx auto;
		padding: 20px 30px;
		border-radius: 20rpx;
		position: relative;
		background-image: url(../../../static/public/icon/5.png), -webkit-linear-gradient(45deg, #339eec, #1b7bde);
		background-size: 100% 100%;
		box-shadow: 0px 10px 20px #a5cffe;
	}

	.main {
		width: 88%;
		// height: 300rpx;
		// border-radius: 30px;
		margin: 60rpx auto;
        background: #F5F5F5;
		.main_1{
			width: 100%;
			background: #FFFFFF;
			// border-radius: 30px;
			margin: 20px auto;
		}
	}
	.declre{
		position: fixed;
		bottom: 50px;
		width: 88%;
		left: 50%;
		transform: translateX(-50%);
	}
</style>
