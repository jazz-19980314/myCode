<template>
	<view style="background-color: f5f6f7;">
		<cu-custom :bgColor="globalData.bgColor" :isBack="true">
			<block slot="content"><text class="text-darkgrey">添加银行卡</text></block>
		</cu-custom>
		<mescroll-body ref="mescrollRef" @down="downCallback" @up="upCallback">
			<view class="cu-card padding radius bg-white" style="width: 88%;margin: 30px auto;border-radius: 15px;">
				<view class="main">
					<view class="">
						开户行
					</view>
					<input type="text" value="" placeholder="请输入开户行" v-model="bankName" />
				</view>
				<view class="main">
					<view class="">
						账号
					</view>
					<input type="number" value="" placeholder="请输入银行账号" v-model="bankCard" />
				</view>
				<view class="main">
					<view class="">
						开户名
					</view>
					<input type="text" value="" placeholder="请输入预留开户名" v-model="bankPhone" />
				</view>
				<button class="cu-btn bg-blue round lg" @click="saveBank" style="width: 100%;margin: 30px auto;">保存</button>
			</view>
		</mescroll-body>
	</view>
</template>

<script>
	const app = getApp()
	import MescrollMixin from "@/components/mescroll-uni/mescroll-mixins.js";
	export default {
		mixins: [MescrollMixin], // 使用mixin
		data() {
			return {
				globalData: app.globalData,
				CustomBar: this.CustomBar,
				bankName: '',
				bankCard: '',
				bankPhone: '',
				bankInfo: null
			};
		},
		computed: {
			bankCardRight() {
				return /^([1-9]{1})(\d{14}|\d{18})$/.test(this.bankCard)
			}
		},
		methods: {
			saveBank() {
				if (this.bankName == '' || this.bankCard == '' || this.bankPhone == '') {
					uni.showToast({
						icon: "none",
						title: "请完善页面信息"
					})
				} else {
					if (this.bankCardRight) {
						this.bankInfo.bankName = this.bankName
						this.bankInfo.bankCard = this.bankCard
						this.bankInfo.bankPhone = this.bankPhone
						console.log(this.bankInfo)
						this.$http.putBankInfo(this.bankInfo).then(res => {
							if (res.data.ok) {
								uni.showToast({
									icon: "none",
									title: "保存信息成功"
								})
								uni.navigateBack()
							}
						})
					} else {
						uni.showToast({
							icon: "none",
							title: "请输入正确信息"
						})
					}
				}
			},
			/*下拉刷新的回调 */
			downCallback(mescroll) {
				// this.initData();
				mescroll.resetUpScroll();
			},
			/*上拉加载的回调: mescroll携带page的参数, 其中num:当前页 从1开始, size:每页数据条数,默认10 */
			upCallback(mescroll) {
				mescroll.endBySize(1, 1); //设置列表数据
			},
		}
	}
</script>

<style lang="scss">
	.main {
		width: 100%;
		height: 160rpx;
		padding-top: 40rpx;
		border-bottom: 1px solid rgba(234, 234, 234, 1);
		background-color: #FFFFFF;

		view {
			font-size: 16px;
			font-family: PingFangSC-Medium, PingFang SC;
			font-weight: bold;
			color: rgba(51, 51, 51, 1);
			margin-bottom: 20rpx;
		}

		input {
			font-size: 14px;
			font-family: PingFangSC-Regular, PingFang SC;
			font-weight: 400;
			color: rgba(51, 51, 51, 1);
		}
	}
</style>
