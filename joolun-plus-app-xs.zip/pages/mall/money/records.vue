<template>
	<view>
		<cu-custom :bgColor="globalData.bgColor" :isBack="true">
			<block slot="content"><text class="text-darkgrey">结算记录</text></block>
		</cu-custom>
		<!-- <view class="search flex bg-white fixed padding-top-sm solid-bottom">
		    <view class="search-content round">
		        <text class="cuIcon-search padding-right-xs margin-left"></text>
		        <input type="text" placeholder="输入店铺名搜索" v-model="inputKey" confirm-type="search"></input>
		    </view>
		    <view class="action">
		        <button class="cu-btn bg-blue round search-button margin-right-sm" @click="search">搜索</button>
		    </view>
		</view> -->
		<view style="color: #999999;" class="flex justify-between align-center padding">
			<view>
				<text class="cuIcon-edit text-blue text-xl text-bold margin-right-sm"></text>
				<text class="text-bold">结算记录</text>
			</view>
			<view>
				<uni-calendar ref="calendar" :range="true" :insert="false" @confirm="confirm" :lunar="true" />
				<text @click="open">时间统计</text><text class="cuIcon-triangledownfill text-xl text-bold"></text>
			</view>
		</view>
		<mescroll-body ref="mescrollRef"  @init="mescrollInit" @down="downCallback" @up="upCallback" :down="downOption" :up="upOption">
			<!-- 资金明细 -->
			<view class="main">
				<view class="main_1 cu-list radius">
					<view class="cu-item radius bg-white solid-top" v-for="(data,index) in dataList" :key="index">
						<view class="cu-list flex justify-between padding align-center">
							<view class="content flex-sub padding-left text-sm">
								<view class="flex justify-between">
									<view class="text-darkgrey text-to-long text-df">{{data.createTime}}</view>
								</view>
								<!-- <view class="text-sm text-purple-grey flex justify-between">
									2020-11-1
								</view> -->
							</view>
							<view class="text-bold text-black text-price">{{data.amount}}</view>
						</view>
					</view>
				</view>
			</view>
		</mescroll-body>
	</view>
</template>

<script>
	const app = getApp()
	import MescrollMixin from "@/components/mescroll-uni/mescroll-mixins.js";
	import {getPage} from '@/api/mall/settleaccounts.js'
	import uniCalendar from '@/components/uni-calendar/uni-calendar.vue'
	export default {
		mixins: [MescrollMixin], // 使用mixin
		data() {
			return {
				globalData: app.globalData,
				CustomBar: this.CustomBar,
				dataList:[],
				inputKey:'',
				downOption: {// 下拉刷新的配置(可选, 绝大部分情况无需配置)
				
				},
				// 上拉加载的配置(可选, 绝大部分情况无需配置)
				upOption: {
				    page: {
				        size: 10, // 每页数据的数量,默认10
				    },
				    noMoreSize: 5, // 配置列表的总数量要大于等于5条才显示'-- END --'的提示
				    empty: {
				        tip: '暂无相关数据'
				    }
				},
				startTime:'',
				endTime:'',
			};
		},
		components: {
			uniCalendar
		},
		methods:{
			open() {
				this.$refs.calendar.open();
			},
			confirm(e) {
				// console.log(e)
				if(e.range.after){
					this.startTime = e.range.data[0]
					this.endTime = e.range.data[e.range.data.length-1]
				}else{
					this.startTime = e.fulldate
					this.endTime = e.fulldate
				}
				console.log(this.startTime,this.endTime)
				this.mescroll.resetUpScroll();
			},
			/*mescroll组件初始化的回调,可获取到mescroll对象 (此处可删,mixins已默认)*/
			mescrollInit(mescroll) {
			    this.mescroll = mescroll;
			},
			/*下拉刷新的回调, 有三种处理方式:*/
			downCallback(){
			    this.mescroll.resetUpScroll(); // 重置列表为第一页 (自动执行 page.num=1, 再触发upCallback方法 )
			    this.mescroll.endSuccess()
			},
			/*上拉加载的回调*/
			upCallback(page) {
				// console.log(page)
			    let pageNum = page.num; // 页码, 默认从1开始
			    let pageSize = page.size; // 页长, 默认每页10条
			    let querySearch = '?current='+pageNum+'&size='+pageSize+'&descs=create_time';
			    if(this.endTime && this.startTime){
			        querySearch = querySearch + '&startTime='+this.startTime+ '&endTime='+this.endTime
			    }
				// console.log(querySearch)
			    getPage(querySearch).then(response=>{
			        if(response.data){
			            // 接口返回的当前页数据列表 (数组)
			            let curPageData = response.data.records;
			            // 接口返回的当前页数据长度 (如列表有26个数据,当前页返回8个,则curPageLen=8)
			            let curPageLen = curPageData.length;
			            // 接口返回的总数据量(如列表有26个数据,每页10条,共3页; 则totalSize=26)
			            let totalSize = response.data.total;
			            //设置列表数据
			            if(page.num == 1) this.dataList = []; //如果是第一页需手动置空列表
			            this.dataList = this.dataList.concat(curPageData); //追加新数据
			            // 请求成功,隐藏加载状态
			            this.mescroll.endBySize(curPageLen, totalSize);
			            setTimeout(()=>{
			                this.mescroll.endSuccess(curPageLen)
			            },20)
			        }
			    });
			}
		}
	}
</script>

<style lang="scss">
.search{
		width: 100%;
		padding-bottom: 20rpx;
		position: fixed;
		z-index: 1024;
	}
	
	.search-content{
		background-color: #f5f5f5;
		line-height: 64upx;
		height: 64upx;
		font-size: 24upx;
		color: #333333;
		flex: 1;
		display: flex;
		align-items: center;
		margin: 0 30upx;
	}
	
	.search-content input{
		flex: 1;
		padding-right: 30upx;
		height: 64upx;
		line-height: 64upx;
		font-size: 26upx;
		background-color: transparent;
	}

	.user-list{
		margin-top: 100rpx;
	}

	.cu-tag{
		margin: 20rpx 10rpx 0 -5rpx !important;
	}

    .text-to-long{
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 2;
        overflow: hidden;
    }
</style>
