<template>
	<view style="background-color: #F5F5F5;">
		<cu-custom :bgColor="globalData.bgColor" :isBack="true">
			<block slot="content"><text class="text-darkgrey">结算页面</text></block>
		</cu-custom>
		<!-- <mescroll-body ref="mescrollRef" @down="downCallback" @up="upCallback"> -->
		<view class="cu-card bg-blue text-white " style="width: 100%;height: 350upx;padding: 30px 30px 20px 30px;">
			<view class="margin-bottom">
				可结算金额（元）
			</view>
			<view class="">
				<text class="text-price text-bold text-xxl">{{PaymentPriceSum | moneyFormat}}</text>
			</view>
		</view>
		<view class="cu-card text-left radius bg-white inputMoney" style="">
			<!-- <view class="bg-gray flex justify-between padding align-center" style="height: 130upx;width: 100%;">
					<text class="text-bold text-xl">
						到账银行卡
					</text>
					<navigator url="/pages/mall/money/cards">
						<view class="">
							<text class="text-blue">选择/添加</text>
						</view>
					</navigator>
				</view> -->
			<view class="main text-black">
				<view class="">
					开户行
				</view>
				<input type="text" value="" placeholder="请输入开户行" v-model="form.bankName" />
			</view>
			<view class="main text-black">
				<view class="">
					账号
				</view>
				<input type="number" value="" placeholder="请输入银行账号" v-model="form.bankCode" />
			</view>
			<view class="main">
				<view class="text-black">
					选择店铺
				</view>
				<picker v-if="shopList.length" @change="PickerChange" :value="index" :range="shopList" range-key="name">
					<view class="flex justify-between">
						<text style="">{{shopList[index].name||'请选择店铺'}}</text>
						<text class="cuIcon-triangledownfill text-xxl text-bold"></text>
					</view>
				</picker>
			</view>
			<view class="margin-top text-left main" style="border-bottom: none;">
				<view class="text-bold text-black">结算金额</view>
				<view class="flex align-center solid-bottom padding-bottom-xs justify-around">
					<text class="text-xl">￥</text>
					<input class="text-xxl" type="number" value="" v-model="form.amount" style="font-size: 18px;" />
					<text style="width: 100px;" class="text-blue" @click="declareAll">全部结算</text>
				</view>
				<view class="text-gray text-left margin-top-sm" style="font-size: 12px;">(最少提现1元)</view>
			</view>
			<view class="main text-black">
				<view class="">
					备注
				</view>
				<input type="number" value="" placeholder="请输入备注" v-model="form.remark" />
			</view>
			<view class="main" style="border-bottom: none;">
				<button class="cu-btn bg-blue round lg" style="width: 100%;margin: 30px auto;" @click="declreNow">申请结算</button>
			</view>
		</view>
		<view class="notice text-gray" v-if="false">
			<view class="margin-bottom-xs">提示说明：</view>
			<view class="margin-bottom-xs">1.文案提示</view>
			<view class="margin-bottom-xs">2.文案提示</view>
			<view class="margin-bottom-xs">3.文案提示</view>
		</view>
		<!-- </mescroll-body> -->
	</view>
</template>

<script>
	const app = getApp()
	// import MescrollMixin from "@/components/mescroll-uni/mescroll-mixins.js";
	import {
		getPage
	} from '@/api/mall/shopinfo'
	import {
		addObj
	} from '@/api/mall/settleaccounts'
	export default {
		// mixins: [MescrollMixin], // 使用mixin
		data() {
			return {
				globalData: app.globalData,
				CustomBar: this.CustomBar,
				dataList: [1, 2],
				index: 0,
				shopList: [],
				PaymentPriceSum:0,
				form: {
					bankName: '',
					bankCode: '',
					amount: 0,
					shopId: '',
					remark: ''
				},
				page: {
					num: 1,
					size: 10
				}
			};
		},
		computed: {
			bankCardRight() {
				return /^[1-9]\d{9,29}$/.test(this.form.bankCode)
			}
		},
		mounted() {
			this.getShopList(this.page)
		},
		methods: {
			declareAll(){
				this.form.amount = this.PaymentPriceSum
			},
			PickerChange(e) {
				this.index = e.detail.value
				this.form.shopId = this.shopList[e.detail.value].id
			},
			declreNow() {
				if (this.form.bankName == '' || this.form.bankCode == '' || this.form.amount == '') {
					uni.showToast({
						icon: "none",
						title: "请完善页面信息"
					})
				} else {
					if (this.bankCardRight) {
						// console.log(this.form)
						addObj(this.form).then(res => {
							console.log(res.data)
							if (res.data) {
								uni.showToast({
									icon: "none",
									title: "提现成功！请耐心等待"
								})
								uni.navigateBack()
							}
						})
					} else {
						uni.showToast({
							icon: "none",
							title: "请输入正确银行卡号"
						})
					}
				}
			},
			getShopList(page) {
				let pageNum = page.num; // 页码, 默认从1开始
				let pageSize = page.size; // 页长, 默认每页10条
				let querySearch = '?current=' + pageNum + '&size=' + pageSize + '&descs=create_time';
				getPage(querySearch).then(response => {
					if (response.data) {
						// 接口返回的当前页数据列表 (数组)
						let curPageData = response.data.records;
						this.shopList = curPageData
						this.form.shopId = curPageData[0].id
						this.PaymentPriceSum = curPageData[0].wallet
						// console.log(curPageData)
					}
				});
			}
			/*下拉刷新的回调 */
			// downCallback(mescroll) {
			// 	// this.initData();
			// 	mescroll.resetUpScroll();
			// },
			// /*上拉加载的回调: mescroll携带page的参数, 其中num:当前页 从1开始, size:每页数据条数,默认10 */
			// upCallback(mescroll) {
			// 	mescroll.endBySize(1, 1); //设置列表数据
			// },
		}
	}
</script>

<style lang="scss" scoped>
	.inputMoney {
		width: 88%;
		margin: 30px auto;
		border-radius: 15px;
		position: fixed;
		top: 320upx;
		left: 50%;
		transform: translateX(-50%);
	}

	.notice {
		width: 88%;
		margin: 30px auto;
		border-radius: 15px;
		position: fixed;
		bottom: 1500upx;
		left: 50%;
		transform: translateX(-50%);
	}

	.main {
		width: 88%;
		margin: 10px auto;
		// height: 160rpx;
		// padding-top: 40rpx;
		border-bottom: 1px solid rgba(234, 234, 234, 1);
		background-color: #FFFFFF;

		view {
			font-size: 16px;
			font-family: PingFangSC-Medium, PingFang SC;
			font-weight: bold;
			// color: rgba(51, 51, 51, 1);
			margin-bottom: 20rpx;
		}

		input {
			font-size: 14px;
			font-family: PingFangSC-Regular, PingFang SC;
			font-weight: 400;
			color: rgba(51, 51, 51, 1);
		}
	}
</style>
