<template>
	<view style="background-color: f5f6f7;">
		<cu-custom :bgColor="globalData.bgColor" :isBack="true">
			<block slot="content"><text class="text-darkgrey">资金明细</text></block>
		</cu-custom>
		<mescroll-body ref="mescrollRef" @down="downCallback" @up="upCallback">
			<!-- 资金明细 -->
			<view class="cu-card padding text-center radius bg-white" style="width: 88%;margin: 30px auto;border-radius: 15px;">
				<view class="text-bold text-xl margin-bottom-xs">标题辩题白内停</view>
				<view class="text-bold text-xxl text-price margin-bottom">1000.00</view>
				<view class="flex justify-between align-center text-gray margin-top">
					<text>交易日期</text>
					<text>2020-11-1</text>
				</view>
				<view class="flex justify-between align-center text-gray margin-top">
					<text>交易金额</text>
					<text class="text-price">1000.00</text>
				</view>
				<view class="flex justify-between align-center text-gray margin-top">
					<text>其他信息</text>
					<text>2020-11-1</text>
				</view>
			</view>
		</mescroll-body>
	</view>
</template>

<script>
	const app = getApp()
	import MescrollMixin from "@/components/mescroll-uni/mescroll-mixins.js";
	export default {
		mixins: [MescrollMixin], // 使用mixin
		data() {
			return {
				globalData: app.globalData,
				CustomBar: this.CustomBar,
				dataList:[1,2]
			};
		},
		methods:{
			/*下拉刷新的回调 */
			downCallback(mescroll) {
				// this.initData();
				mescroll.resetUpScroll();
			},
			/*上拉加载的回调: mescroll携带page的参数, 其中num:当前页 从1开始, size:每页数据条数,默认10 */
			upCallback(mescroll) {
				mescroll.endBySize(1, 1); //设置列表数据
			},
		}
	}
</script>

<style lang="scss">

</style>
