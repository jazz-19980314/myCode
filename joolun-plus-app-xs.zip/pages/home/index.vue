<template>
	<view class="bg-white">
		<cu-custom :bgColor="globalData.bgColor" :isBack="false">
			<block slot="content"><text class="text-darkgrey">首页</text></block>
		</cu-custom>
		<mescroll-body ref="mescrollRef" @down="downCallback" @up="upCallback">
			<view class="turnover padding-sm">
				<view class="storefront">
					<view class="flex justify-between align-center">
						<view class="flex align-center">
							<view class="cu-avatar round flex head-bg" :style="'background-image:url('+this.userInfo.avatar+')'"></view>
							<view class="margin-left-sm">
								<view class="text-df text-white text-left shop-name">{{shopInfo.detail}}</view>
								<view class="text-sm text-white text-left">收藏数：{{shopInfo.collectCount}}</view>
							</view>
						</view>
						<navigator class="cu-btn round bg-white text-sm sm" url="shop-home">店铺管理</navigator>
					</view>
					<view class="margin-top-sm text-center">
						<view class="text-price text-xl text-white text-bold">
							<text class="text-sl text-white text-bold">{{todayPaymentPriceSum | moneyFormat}}</text>
						</view>
						<text class="text-df text-white">今日营业额</text>
					</view>
				</view>
			</view>

			<view class="flex justify-center margin-top-xl">
				<navigator class="bg-1" url="../mall/order/list?status=1">
					<view class="flex align-center margin-left margin-top-sm">
						<image src="../../static/public/icon/logistics.png" class="icon"></image>
						<view class="text-white text-sm margin-left-xs">待发货</view>
					</view>
					<view class="text-white text-center quantity">{{showCount1}}</view>
				</navigator>
				<navigator class="bg-2 margin-left" url="../mall/order/list?status=0">
					<view class="flex align-center margin-left margin-top-sm">
						<image src="../../static/public/icon/payment.png" class="icon"></image>
						<view class="text-white text-sm margin-left-xs">待付款</view>
					</view>
					<view class="text-white text-center quantity">{{showCount2}}</view>
				</navigator>
			</view>
			<view class="flex justify-center margin-top">
				<navigator class="bg-3" url="../mall/order/list?status=2">
					<view class="flex align-center margin-left margin-top-sm">
						<image src="../../static/public/icon/the-goods.png" class="icon"></image>
						<view class="text-white text-sm margin-left-xs">待收货</view>
					</view>
					<view class="text-white text-center quantity">{{showCount3}}</view>
				</navigator>
				<navigator class="bg-4 margin-left" url="../mall/order/list?status=4">
					<view class="flex align-center margin-left margin-top-sm">
						<image src="../../static/public/icon/evaluation.png" class="icon"></image>
						<view class="text-white text-sm margin-left-xs">待评论</view>
					</view>
					<view class="text-white text-center quantity">{{showCount4}}</view>
				</navigator>
			</view>

			<view class="flex justify-between margin-top-xl padding-left padding-right">
				<view class="text-darkgrey margin-left-sm">店铺数据</view>
				<navigator class="text-purple-grey margin-right-sm" url="shop-home">查看所有></navigator>
			</view>
			<view class="margin-xs margin-top-sm">
				<navigator url="../mall/goodsspu/list" class="cu-item bg-white flex radius padding-sm module-bg align-center">
					<view class="cu-item s">
						<image class="shop-icon" src="../../static/public/icon/icon-8.png"></image>
					</view>
					<view class="flex-sub margin-left-sm">
						<view class="text-darkgrey flex justify-between">
							<view>商品总量</view>
						</view>
						<view class="text-purple-grey margin-top-xs text-sm">所有的商品</view>
					</view>
					<view class="margin-right text-darkgrey text-bold">{{goodsspuCount}}</view>
				</navigator>
				<navigator url="../mall/order/list" class="cu-item bg-white flex radius padding-sm margin-top-sm module-bg align-center">
					<view class="round">
						<image class="shop-icon" src="../../static/public/icon/icon-9.png"></image>
					</view>
					<view class="flex-sub margin-left-sm">
						<view class="text-darkgrey flex justify-between">
							<view>订单总量</view>
						</view>
						<view class="text-purple-grey margin-top-xs text-sm">所有已支付订单</view>
					</view>
					<view class="margin-right text-darkgrey text-bold">{{orderinfoCount}}</view>
				</navigator>
				<navigator url="../mall/echarts/index" class="cu-item bg-white flex radius padding-sm margin-top-sm module-bg align-center">
					<view class="round">
						<text class="cuIcon-order text-gray" style="font-size: 28px;font-weight: 100;"></text>
					</view>
					<!-- <view class="round">
						<image class="shop-icon" src="../../static/public/icon/icon-11.png"></image>
					</view> -->
					<view class="flex-sub margin-left-sm">
						<view class="text-darkgrey flex justify-between">
							<view>销量统计</view>
						</view>
						<view class="text-purple-grey margin-top-xs text-sm">商城的销售统计数据</view>
					</view>
					<!-- <view class="margin-right text-darkgrey text-bold">{{orderinfoCount}}</view> -->
				</navigator>
			</view>
		</mescroll-body>
	</view>
</template>

<script>
	import service from "../../store/service";
	// 引入mescroll-mixins.js
	import MescrollMixin from "@/components/mescroll-uni/mescroll-mixins.js";

	const app = getApp();

	import {
		getCount as getOrderInfoCount,
		getPaymentpriceSum
	} from '@/api/mall/orderinfo'
	import {
		getCount as getUserInfoCount
	} from '@/api/mall/userinfo'
	import {
		getCount as getGoodsSpuCount
	} from '@/api/mall/goodsspu'
	import {
		getObj as getObjByShop
	} from '@/api/mall/shopinfo.js'

	export default {
		mixins: [MescrollMixin], // 使用mixin
		data() {
			return {
				globalData: app.globalData,
				CustomBar: this.CustomBar,
				todayPaymentPriceSum: 0, //营业额
				goodsspuCount: 0,
				userinfoCount: 0,
				orderinfoCount: 0,
				showCount1: 0,
				showCount2: 0,
				showCount3: 0,
				showCount4: 0,
				shopCollectCount: 0, //店铺收藏数
				userInfo: {},
				shopInfo: {},
			};
		},
		onLoad() {
			this.userInfo = service.getUser();
			service.saveLogInfo("-----进入到首页-----")
		},
		onShow() {},
		methods: {
			initData() {
				service.saveLogInfo("-----首页刷新数据开始-----")
				if (this.globalData.access_token && this.userInfo != null) {
					this.getCount();
					this.getPaymentpriceSum();
				}
				service.saveLogInfo("-----首页刷新数据完成-----")
			},
			getPaymentpriceSum() {
				service.saveLogInfo("-----调用getPaymentpriceSum-----")
				let query = {
					beginTime: this.$moment().format('YYYY-MM-DD 00:00:00'),
					endTime: this.$moment().add(1, 'days').format('YYYY-MM-DD 00:00:00'),
					isPay: 1
				}
				if (this.userInfo.shopId) {
					query.shopId = this.userInfo.shopId;
				}
				getPaymentpriceSum(query).then(response => {
					if (response.data) {
						this.todayPaymentPriceSum = response.data;
					} else {
						this.todayPaymentPriceSum = 0;
					}
				})
			},
			getCount() {
				service.saveLogInfo("-----调用getGoodsSpuCount-----")
				getGoodsSpuCount().then(response => {
					if (response.data) {
						this.goodsspuCount = response.data;
					} else {
						this.goodsspuCount = 0;
					}
				})
				// getUserInfoCount().then(response=>{
				// 	if(response.data){
				// 		this.userinfoCount = response.data;
				// 	}
				// })
				getOrderInfoCount().then(response => {
					if (response.data) {
						this.orderinfoCount = response.data;
					} else {
						this.orderinfoCount = 0;
					}
				})
				getOrderInfoCount({
					status: '1'
				}).then(response => {
					if (response.data) {
						this.showCount1 = response.data;
					} else {
						this.showCount1 = 0;
					}
				})
				getOrderInfoCount({
					status: '0'
				}).then(response => {
					if (response.data) {
						this.showCount2 = response.data;
					} else {
						this.showCount2 = 0;
					}
				})
				getOrderInfoCount({
					status: '2'
				}).then(response => {
					if (response.data) {
						this.showCount3 = response.data;
					} else {
						this.showCount3 = 0;
					}
				})
				getOrderInfoCount({
					status: '3',
					appraisesStatus: '0'
				}).then(response => {
					if (response.data) {
						this.showCount4 = response.data;
					} else {
						this.showCount4 = 0;
					}
				})
				service.saveLogInfo("----- 调用getOrderInfoCount3 -----")
				if (this.userInfo.shopId) {
					getObjByShop(this.userInfo.shopId).then(response => {
						if (response.data) {
							this.shopInfo = response.data;
						}
					})
				}
			},
			/*下拉刷新的回调 */
			downCallback(mescroll) {
				this.initData();
				mescroll.resetUpScroll();
			},
			/*上拉加载的回调: mescroll携带page的参数, 其中num:当前页 从1开始, size:每页数据条数,默认10 */
			upCallback(mescroll) {
				mescroll.endBySize(1, 1); //设置列表数据
			},
		}
	}
</script>

<style>
	.turnover {
		width: 88%;
		height: 300rpx;
		margin: 20rpx auto;
		border-radius: 20rpx;
		position: relative;
		background-image: url(../../static/public/icon/5.png), -webkit-linear-gradient(45deg, #339eec, #1b7bde);
		background-size: 100% 100%;
		box-shadow: 0px 10px 20px #a5cffe;
	}

	.icon {
		width: 52rpx;
		height: 52rpx;
	}

	.bg-1 {
		width: 43%;
		height: 180rpx;
		border-radius: 20rpx;
		background-image: url(../../static/public/icon/1.png), -webkit-linear-gradient(45deg, #ec1355, #ff8088);
		background-size: 100% 100%;
		color: #ffffff;
		box-shadow: 0px 10px 20px #ebbdc9;
	}

	.bg-2 {
		width: 43%;
		height: 180rpx;
		border-radius: 20rpx;
		background-image: url(../../static/public/icon/2.png), -webkit-linear-gradient(45deg, #a168fe, #753ff1);
		background-size: 100% 100%;
		color: #ffffff;
		box-shadow: 0px 10px 20px #dfbaec;
	}

	.bg-3 {
		width: 43%;
		height: 180rpx;
		border-radius: 20rpx;
		background-image: url(../../static/public/icon/3.png), -webkit-linear-gradient(45deg, #634fe8, #69c5ff);
		background-size: 100% 100%;
		color: #ffffff;
		box-shadow: 0px 10px 20px #babbec;
	}

	.bg-4 {
		width: 43%;
		height: 180rpx;
		border-radius: 20rpx;
		background-image: url(../../static/public/icon/4.png), -webkit-linear-gradient(45deg, #ffce1d, #f8a74f);
		background-size: 100% 100%;
		color: #ffffff;
		box-shadow: 0px 10px 20px #ebddbf;
	}
	
	.quantity{
		font-size: 68rpx;
	}

	.module-bg {
		height: 120rpx;
		box-shadow: 0px 2px 10px #e8e8f3;
	}

	.shop-icon {
		width: 50rpx;
		height: 50rpx;
	}
</style>
