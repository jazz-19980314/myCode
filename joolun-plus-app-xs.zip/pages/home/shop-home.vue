<template>
	<view>
		<cu-custom :bgColor="globalData.bgColor" :isBack="true"><block slot="content"><text class="text-darkgrey">店铺管理</text></block></cu-custom>
		<!-- <view class=" bg-gray text-sm padding-sm text-grey">
			<text class="cuIcon-info margin-right-xs "></text>目前只提供基本数据操作，编辑数据请在电脑端操作。
		</view> -->
		<view class="padding-top-xs bg-white ">
			<view v-for="(item,index) in menuList" :key="index">
				<!-- 菜单名 -->
				<view v-if="meunPermissions.indexOf(item.menuName)!=-1" class="cu-bar bg-white" style="min-height: auto;">
					<view class="action">
						<text class="cuIcon-titles" :class="item.textColor"></text>{{item.menuName}}
					</view>
				</view>
				<!-- 菜单内容 -->
				<view class="cu-list grid no-border col-4 gw-menu-item" >
					<view class="cu-item gw-menu-item"  v-for="(menu,index) in item.menus" :key="index" v-if="meunPermissions.indexOf(menu.title)!=-1">
						<navigator :url="'/pages/' + menu.url " >
							<image :src="menu.icon" style="margin-top: 0;width: 60upx;height: 60upx;"></image>
							<text style="margin-top: 0;">{{menu.title}}</text>
						</navigator>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>

	const app = getApp();
	import {GetMenu} from '@/api/upms/menu'

	export default {
		onLoad(){
			// 初始化菜单
			this.GetMenu();
		},
		data() {
			return {
                globalData: app.globalData,
				CustomBar: this.CustomBar,
				meunPermissions: [],
				menuList: [
					{
						menuName: '店铺管理',
						textColor:'text-darkgrey',
						menus:[
							{
								title: '店铺设置',
								url: 'mall/shop/list',
								color: 'cyan',
								icon: '/static/public/icon/service-store.png',
							},
							{
								title: '商城用户',
								url: 'mall/userInfo/list',
								color: 'cyan',
								icon: '/static/public/icon/service-user.png',
							},
							{
								title: '收益详情',
								url: 'mall/money/index',
								color: 'cyan',
								icon: '/static/public/icon/shopfit.png',
							},
							{
								title: '提现详情',
								url: 'mall/money/records',
								color: 'cyan',
								icon: '/static/public/icon/settle.png',
							},
						]
					},
					{
						menuName: '商品管理',
						textColor:'text-darkgrey',
						menus:[
							{
								title: '全部商品',
								url: 'mall/goodsspu/list',
								color: 'cyan',
								icon: '/static/public/icon/service-allgoods.png',
							},
							// {
							// 	title: '规格管理',
							// 	url: 'mall/shop/list',
							// 	color: 'cyan',
							// 	cuIcon: 'newsfill',
							// },
							// {
							// 	title: '商品类目',
							// 	url: 'mall/shop/list',
							// 	color: 'cyan',
							// 	cuIcon: 'newsfill',
							// },
							{
								title: '商品评价',
								url: 'mall/goodsappraises/list',
								color: 'cyan',
								icon: '/static/public/icon/service-evaluation.png',
							},

						]
					},
					{
						menuName: '订单管理',
						textColor:'text-darkgrey',
						menus:[
							{
								title: '全部订单',
								url: 'mall/order/list',
								color: 'cyan',
								icon: '/static/public/icon/service-all-order.png',
							},
							{
								title: '退款单',
								url: 'mall/orderrefunds/list',
								color: 'cyan',
								icon: '/static/public/icon/service-refund.png',
							},
						]
					},
					{
						menuName: '积分管理',
						textColor:'text-darkgrey',
						menus:[
							{
								title: '积分设置',
								url: 'mall/points/pointsconfig',
								color: 'cyan',
								icon: '/static/public/icon/service-integral.png',
							},
							{
								title: '积分明细',
								url: 'mall/points/pointsrecord',
								color: 'cyan',
								icon: '/static/public/icon/service-integral-detail.png',
							},
						]
					},
					{
						menuName: '电子券管理',
						textColor:'text-darkgrey',
						menus:[
							{
								title: '电子券制作',
								url: 'mall/coupon/couponinfo',
								color: 'cyan',
								icon: '/static/public/icon/service-coupons.png',
							},
							{
								title: '领券记录',
								url: 'mall/coupon/couponuser',
								color: 'cyan',
								icon: '/static/public/icon/service-coupons-draw.png',
							},
						]
					},
					{
						menuName: '砍价管理',
						textColor:'text-darkgrey',
						menus:[
							{
								title: '砍价配置',
								url: 'mall/bargain/bargaininfo',
								color: 'cyan',
								icon: '/static/public/icon/service-bargain.png',
							},
							{
								title: '砍价记录',
								url: 'mall/bargain/bargainuser',
								color: 'cyan',
								icon: '/static/public/icon/service-bargain-detail.png',
							},
						]
					},
					{
						menuName: '拼团管理',
						textColor:'text-darkgrey',
						menus:[
							{
								title: '拼团配置',
								url: 'mall/groupon/grouponinfo',
								color: 'cyan',
								icon: '/static/public/icon/service-group-detail.png',
							},
							{
								title: '拼团记录',
								url: 'mall/groupon/grouponuser',
								color: 'cyan',
								icon: '/static/public/icon/service-group.png',
							},
						]
					},
					{
						menuName: '秒杀管理',
						textColor:'text-darkgrey',
						menus:[
							{
								title: '秒杀商品',
								url: 'mall/seckill/seckillinfo',
								color: 'cyan',
								icon: '/static/public/icon/service-seckill.png',
							},
							{
								title: '秒杀会场',
								url: 'mall/seckill/seckillhall',
								color: 'cyan',
								icon: '/static/public/icon/service-seckill-venue.png',
							},
						]
					},
					// {
					// 	menuName: '商城设置',
					// 	textColor:'text-blue',
					// 	menus:[
					// 		{
					// 			title: '运费模板',
					// 			url: 'mall/shop/list',
					// 			color: 'cyan',
					// 			cuIcon: 'newsfill',
					// 		},
					// 		{
					// 			title: '保障服务管理',
					// 			url: 'mall/shop/list',
					// 			color: 'cyan',
					// 			cuIcon: 'newsfill',
					// 		},
					// 		{
					// 			title: '素材库',
					// 			url: 'mall/shop/list',
					// 			color: 'cyan',
					// 			cuIcon: 'newsfill',
					// 		},
					// 	]
					// }
				]
			};
		},
		methods:{
			GetMenu(){//获取系统菜单
				GetMenu().then((res) => {
					const data = res.data;
					data.forEach(ele => {//设置菜单是否显示
						if(ele.path=='/mall'){//商城模块
						    // console.log(ele.children)
							this.childMenuQuery(ele.children);
						}
					});
				})
			},
			childMenuQuery(childs){
				if(childs && childs.length>0){
					childs.forEach(child=>{//所有菜单
						this.meunPermissions.push(child.name);
						this.childMenuQuery(child.children);
					})
				}
			}

		}
	}
</script>

<style>
</style>
