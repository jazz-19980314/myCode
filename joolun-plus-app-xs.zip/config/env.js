/**
 * Copyright (C) 2018-2019
 * All rights reserved, Designed By www.joolun.com
 * 注意：
 * 本软件为www.joolun.com开发研制，未经购买不得使用
 * 购买后可获得全部源代码（禁止转卖、分享、上传到码云、github等开源平台）
 * 一经发现盗用、分享等行为，将追究法律责任，后果自负
 */
export default {
  //服务器地址，即后台访问地址；本地开发填http://localhost:8082即可，如果要用真机调试要把localhost换成局域网ip，手机和电脑要处于同一局域网中
  // basePath: 'http://192.168.0.114:9999',
  basePath: 'https://fresh.fdai.com.cn',
  //前端密码密钥，必须16位，和nacos配置文件base-gateway-dev.yml中的security.encode.key对应
  securityKey : '1234567891234567',
  // 版本更新地址：取的是服务器的一个json文件，App启动时会自动请求该文件然后根据返回的内容判断是否需要更新，json格式请查看 /public/APPUpdate/APPUpdate.md 说明
  appUpdateUrl: 'https://demo1.joolun.com/AppVersion.json',
  switchDemon: false,//是否开启演示模式,演示模式下只能进行查看操作，不能进行修改操作
  showPrivacyPolicy: true,//是否显示 隐私政策、用户协议 相关功能。目前所有app上架到应用宝，苹果等各个商店平台需要隐私政策信息。因为上架手续繁琐，如有需要请查看文档进行修改。
  privacyPolicyUrl:'https://fresh.fdai.com.cn/policy.html',//隐私政策网络地址
  protocolUrl:'https://fresh.fdai.com.cn/user.html',//用户协议网络地址
}
