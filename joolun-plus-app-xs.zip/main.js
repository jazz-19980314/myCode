import Vue from 'vue'
import App from './App'

import cuCustom from './public/colorui/components/cu-custom.vue'
Vue.component('cu-custom',cuCustom)

// 下拉刷新组件 文档地址：http://www.mescroll.com/uni.html
// 在main.js注册全局组件
import MescrollBody from "@/components/mescroll-uni/mescroll-body.vue"
import MescrollUni from "@/components/mescroll-uni/mescroll-uni.vue"
//时间插件
import moment from './public/moment/moment.js';
Vue.prototype.$moment = moment;//赋值使用
Vue.component('mescroll-body', MescrollBody)
Vue.component('mescroll-uni', MescrollUni)



Vue.filter('moneyFormat', function(val) {
    if(val){
        val = val.toString().replace(/\$|\,/g,'');
    }
    if(isNaN(val)) {
        val = "0";
    }
    let sign = (val == (val = Math.abs(val)));
    val = Math.floor(val*100+0.50000000001);
    let cents = val%100;
    val = Math.floor(val/100).toString();
    if(cents<10) {
        cents = "0" + cents
    }
    for (var i = 0; i < Math.floor((val.length-(1+i))/3); i++) {
        val = val.substring(0,val.length-(4*i+3))+',' + val.substring(val.length-(4*i+3));
    }
    return (((sign)?'':'-') + val + '.' + cents);
});

Vue.config.productionTip = false

App.mpType = 'app'

const app = new Vue({
    ...App
})
app.$mount()





